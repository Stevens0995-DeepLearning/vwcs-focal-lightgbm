"""Portable, standard-library-only metric replay; does not fit or alter models."""
from pathlib import Path
import argparse, csv, json, math, platform, sys

ROOT = Path(__file__).resolve().parent

def rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def ranking(y, score):
    order = sorted(range(len(y)), key=lambda i: -score[i])
    p = sum(y); n = len(y) - p
    if not p or not n:
        raise ValueError('Both outcome classes are required')
    tp = fp = previous_tp = previous_fp = ap = auc = 0.0
    j = 0
    while j < len(order):
        end = j + 1
        while end < len(order) and score[order[end]] == score[order[j]]:
            end += 1
        tp += sum(y[order[k]] for k in range(j, end))
        fp = end - tp
        ap += (tp - previous_tp) * tp / end / p
        auc += (fp - previous_fp) * (tp + previous_tp) * 0.5 / (p*n)
        previous_tp, previous_fp = tp, fp
        j = end
    return ap, auc

def flag(v):
    return str(v).strip().lower() in ('true','1','1.0')

def calibration_diagnostic(records, probability):
    """Joint intercept/slope diagnostic, not a new calibration of model outputs.

    Matches revision10_calibration.py: clipped logit, slope penalty 1e-6,
    Newton updates with backtracking, step tolerance 1e-10.
    """
    ordered=sorted(records,key=lambda r:int(r['sample_id']))
    y=[int(r['y_true']) for r in ordered]
    q=[float(r[probability]) for r in ordered]
    x=[math.log(min(1-1e-6,max(1e-6,v))/(1-min(1-1e-6,max(1e-6,v)))) for v in q]
    a,b=0.0,1.0
    def sigmoid(z):return 1/(1+math.exp(-max(-700,min(700,z))))
    def objective(a,b):
        return sum(max(a+b*t,0)+math.log1p(math.exp(-abs(a+b*t)))-v*(a+b*t) for t,v in zip(x,y))+.5e-6*b*b
    for iteration in range(100):
        p=[sigmoid(a+b*t) for t in x]
        g0=sum(s-v for s,v in zip(p,y));g1=sum(t*(s-v) for t,s,v in zip(x,p,y))+1e-6*b
        h00=sum(s*(1-s) for s in p);h01=sum(t*s*(1-s) for t,s in zip(x,p));h11=sum(t*t*s*(1-s) for t,s in zip(x,p))+1e-6
        det=h00*h11-h01*h01
        da=(g0*h11-g1*h01)/det;db=(h00*g1-h01*g0)/det
        rate=1.0;value=objective(a,b)
        while objective(a-rate*da,b-rate*db)>value+1e-10:
            rate*=.5
            if rate<=1e-8:raise ArithmeticError('Diagnostic line search failed')
        a-=rate*da;b-=rate*db
        if max(abs(rate*da),abs(rate*db))<1e-10:break
    return dict(brier=sum((s-v)**2 for s,v in zip(q,y))/len(y),intercept=a,slope=b)

def compute(records, ycol, scorecol, qcol=None, decisioncol=None, highcol=None):
    y = [int(float(r[ycol])) for r in records]
    score = [float(r[scorecol]) for r in records]
    if any(not math.isfinite(v) for v in score):
        raise ValueError('Non-finite ranking score')
    ap, auc = ranking(y, score)
    if decisioncol:
        pred = [flag(r[decisioncol]) for r in records]
    else:
        pred = [float(r[qcol]) >= 0.2 for r in records]
    tp = sum(a and b for a,b in zip(y,pred)); fp = sum(not a and b for a,b in zip(y,pred))
    fn = sum(y)-tp; tn = len(y)-sum(y)-fp
    out = dict(n=len(y), positive=sum(y), AP=ap, ROC_AUC=auc,
               Recall=tp/(tp+fn), Precision=tp/(tp+fp) if tp+fp else 0.0,
               FPR=fp/(fp+tn), F2=5*tp/(5*tp+4*fn+fp), TP=tp,FN=fn,FP=fp,TN=tn,
               alerts=tp+fp)
    if qcol:
        q=[float(r[qcol]) for r in records]
        assert all(0<=v<=1 for v in q)
        out['Brier']=sum((a-b)**2 for a,b in zip(y,q))/len(y)
    if highcol:
        hi=[flag(r[highcol]) for r in records]
        out['high_TP']=sum(a and b and h for a,b,h in zip(y,pred,hi))
        out['high_FN']=sum(a and not b and h for a,b,h in zip(y,pred,hi))
    return out

ALIASES={'AP':['pr_auc','AP'],'ROC_AUC':['roc_auc','ROC-AUC','ROC_AUC'],
 'Brier':['brier','Brier'],'Recall':['recall','Recall'], 'Precision':['precision','Precision','precision_at_k'],
 'FPR':['fpr','FPR'], 'F2':['f2','F2'], 'TP':['tp','TP'],'FN':['fn','FN'],'FP':['fp','FP'],'TN':['tn','TN'],
 'alerts':['alerts','k'], 'high_TP':['high_tp','high_TP','high_V_tp'], 'high_FN':['high_fn','high_FN','high_V_fn']}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'replay_output')
    args=parser.parse_args(); args.output_dir.mkdir(parents=True,exist_ok=True)
    specs=json.loads((ROOT/'metric_replay_manifest.json').read_text(encoding='utf-8'))
    output=[];checks=[];cache={};failures=[];aligned_labels=None
    for spec in specs:
        path=ROOT/spec['predictions']
        if path not in cache: cache[path]=rows(path)
        r=cache[path]
        high_col=spec.get('high')
        if spec['panel'] in {'temporal','temporal_extend'}:
            cutoff=json.loads((ROOT/'revision/temporal/protocol.json').read_text(encoding='utf-8'))['train_v_q75']
            for rec in r:rec['_replay_high_V']=str(int(float(rec['V_i'])>=cutoff))
            high_col='_replay_high_V'
        ids=[x[spec['id_col']] for x in r]
        if len(ids)!=len(set(ids)): raise AssertionError('Duplicate sample_id: '+spec['name'])
        if spec['panel'] not in {'temporal','temporal_extend'}:
            labels={x[spec['id_col']]:int(float(x[spec['label']])) for x in r}
            if aligned_labels is None:aligned_labels=labels
            if labels!=aligned_labels:raise AssertionError('Benchmark sample/label misalignment: '+spec['name'])
        result=compute(r,spec['label'],spec['score'],spec.get('probability'),spec.get('decision'),high_col)
        result={'panel':spec['panel'],'model':spec['name'],**result}
        output.append(result)
        expect_path=ROOT/spec['expected_file']
        if expect_path not in cache:cache[expect_path]=rows(expect_path)
        candidates=[z for z in cache[expect_path] if z[spec['expected_id_col']]==spec['expected_id']]
        if len(candidates)!=1: raise AssertionError('Ambiguous expected row '+spec['name'])
        for key,aliases in ALIASES.items():
            if key not in result:continue
            original=next((a for a in aliases if a in candidates[0]),None)
            if original is None:continue
            expected=float(candidates[0][original]); delta=abs(result[key]-expected)
            ok=delta<=1e-10
            checks.append(dict(panel=spec['panel'],model=spec['name'],metric=key,
                archived=expected,recomputed=result[key],absolute_error=delta,passed=ok))
            if not ok:failures.append(checks[-1])
    def save(name,data):
        fields=list(dict.fromkeys(k for row in data for k in row))
        with (args.output_dir/name).open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(data)
    save('recomputed_metrics.csv',output);save('metric_verification.csv',checks)
    # Table S13 is sourced from the revision-10 nine-model diagnostic, not the
    # older three-model CSV used by a previous figure.
    diagnostic_rows=[]
    expected_diag=rows(ROOT/'revision/calibration/Table_S13_Calibration.csv')
    for expected in expected_diag:
        key=expected['model_key'];records=rows(ROOT/f'historical/{key}/test_predictions.csv')
        d=calibration_diagnostic(records,'y_prob_calibrated')
        diagnostic_rows.append(dict(model=key,output='final',**d))
        for metric,value in d.items():
            error=abs(value-float(expected[metric]));ok=error<=1e-8
            c=dict(panel='calibration_diagnostic',model=key,metric=metric,archived=float(expected[metric]),recomputed=value,absolute_error=error,passed=ok)
            checks.append(c)
            if not ok:failures.append(c)
    before_after=json.loads((ROOT/'revision/calibration/calibration_results.json').read_text(encoding='utf-8'))['before_after']
    records=rows(ROOT/'historical/focal_lgbm/test_predictions.csv')
    for expected in before_after:
        col='y_prob_raw' if expected['output']=='Before Platt' else 'y_prob_calibrated'
        d=calibration_diagnostic(records,col)
        diagnostic_rows.append(dict(model='focal_lgbm',output=expected['output'],**d))
        for metric,value in d.items():
            error=abs(value-float(expected[metric]));ok=error<=1e-8
            c=dict(panel='calibration_diagnostic',model=expected['output'],metric=metric,archived=float(expected[metric]),recomputed=value,absolute_error=error,passed=ok)
            checks.append(c)
            if not ok:failures.append(c)
    save('calibration_diagnostics.csv',diagnostic_rows);save('metric_verification.csv',checks)
    summary=dict(models=len(output),panels=sorted({x['panel'] for x in output}),checks=len(checks),
                 failures=len(failures),max_absolute_error=max(x['absolute_error'] for x in checks),
                 threshold=0.2,temporal_rule='archived top-5% alerts; no probability calibration assumed',
                 AP='noninterpolated average precision with tied-score groups',
                 ROC_AUC='trapezoidal ROC area with tied-score groups',
                 python=sys.version,platform=platform.platform(),no_training=True,
                 benchmark_sample_alignment='same 1,470 sample_ids and outcome labels across all benchmark panels',
                 calibration_diagnostic_rows=len(diagnostic_rows),calibration_tolerance=1e-8)
    (args.output_dir/'verification_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    for r in output:print(f"{r['panel']:15s} {r['model']:28s} AP={r['AP']:.9f} TP={r['TP']} FP={r['FP']} FN={r['FN']} TN={r['TN']}")
    if failures:raise SystemExit('Replay found mismatches; inspect metric_verification.csv')

if __name__=='__main__':main()
