import os
import json
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    average_precision_score, recall_score, precision_score,
    fbeta_score, confusion_matrix, roc_auc_score, brier_score_loss
)
from sklearn.linear_model import LogisticRegression
from datetime import datetime
from scipy.special import expit
import shap
from evaluation_utils import (
    append_best_threshold_output,
)

def prepare_data(file_path):
    """读取真实宽表/实验表，并转换LightGBM所需的数据类型。"""
    print(f"正在读取实验数据并准备特征空间: {file_path}")

    df = pd.read_csv(file_path, low_memory=False)

    # ================= 1. 提取标签 =================
    # 数据准备阶段已经按固定罚款阈值生成Target_Penalty。
    if 'Target_Penalty' not in df.columns:
        raise ValueError("数据集中未找到 'Target_Penalty' 列，请确保读取的是生成后的半合成数据集！")

    y = df['Target_Penalty']
    pos_ratio = y.mean()
    print(f"[标签分布] 正类 (Target=1) 占比: {pos_ratio:.2%}")

    # ================= 2. 提取特征 =================
    X = df.drop(columns=['Target_Penalty'])

    # 自动识别所有非数值字段并转换为 LightGBM 原生 category 类型。
    # 新版 pandas 可能将文本列读取为 `str` 扩展类型，而不再是传统
    # object；因此不能只硬编码三个分类字段，也不能只判断 object。
    categorical_cols = [
        col
        for col in X.columns
        if not pd.api.types.is_numeric_dtype(X[col].dtype)
        and not pd.api.types.is_bool_dtype(X[col].dtype)
    ]
    for col in categorical_cols:
        X[col] = X[col].astype('category')

    # 将数值特征转换为 float32 以加速底层树模型的分裂计算
    numeric_cols = X.select_dtypes(include=[np.number]).columns
    X[numeric_cols] = X[numeric_cols].astype('float32')

    bad_dtype_cols = [
        col
        for col in X.columns
        if not (
            pd.api.types.is_numeric_dtype(X[col].dtype)
            or pd.api.types.is_bool_dtype(X[col].dtype)
            or isinstance(X[col].dtype, pd.CategoricalDtype)
        )
    ]
    if bad_dtype_cols:
        raise TypeError(
            "仍存在LightGBM不支持的数据类型: "
            + ", ".join(
                f"{col}={X[col].dtype}" for col in bad_dtype_cols
            )
        )

    print(
        f"[特征工程] 成功加载 {X.shape[1]} 个特征；"
        f"其中分类特征 {len(categorical_cols)} 个。"
    )

    return X, y


# ================== Focal Loss 算法优化区 ==================
def focal_loss_custom(alpha=0.90, gamma=0.50, hessian_mode='bce_proxy'):
    """Stable Focal objective for LightGBM.

    ``bce_proxy`` keeps the established positive BCE Hessian.  The
    ``focal_weighted`` candidate additionally applies the focal modulation to
    the Hessian and is compared only on the tuning split.  Neither variant is
    combined with SMOTE, ``scale_pos_weight`` or ``is_unbalance``.
    """
    if hessian_mode not in {'bce_proxy', 'focal_weighted'}:
        raise ValueError(f"Unsupported hessian_mode: {hessian_mode}")

    def focal_loss_objective(y_true, y_pred):
        p = expit(y_pred)
        p = np.clip(p, 1e-6, 1 - 1e-6)

        # 1. 保持精准的一阶梯度 (Gradient) - 决定优化的方向
        grad_pos = -alpha * (1 - p) ** gamma * (1 - p - gamma * p * np.log(p))
        grad_neg = (1 - alpha) * p ** gamma * (p - gamma * (1 - p) * np.log(1 - p))
        grad = np.where(y_true == 1, grad_pos, grad_neg)

        # 2. 【核心修复】：摒弃精确但致命的二阶梯度！
        # 强制使用原生 Binary Cross Entropy 的 Hessian 代理 (p * (1 - p))
        # 这样既能享受 Focal Loss 处理极度不平衡的收益，又能保证底层 C++ 树分裂的绝对稳定
        hess = p * (1 - p)
        if hessian_mode == 'focal_weighted':
            alpha_t = np.where(y_true == 1, alpha, 1 - alpha)
            p_t = np.where(y_true == 1, p, 1 - p)
            focal_weight = alpha_t * (1 - p_t) ** gamma
            hess = focal_weight * hess

        # 3. 强行设定下限兜底，防止分母趋于 0 导致权重爆炸
        hess = np.maximum(hess, 1e-5)

        return grad, hess

    return focal_loss_objective


def focal_pr_auc_eval(y_true, raw_scores):
    """PR-AUC metric matched to the raw margins of a custom objective."""
    probabilities = expit(np.asarray(raw_scores, dtype=float))
    score = average_precision_score(y_true, probabilities)
    return 'focal_pr_auc', score, True


# ==========================================================


class FocalLossLGBM(lgb.LGBMClassifier):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def predict_proba(self, X, **kwargs):
        if not hasattr(self, 'booster_'):
            raise ValueError("模型尚未训练")

        raw_scores = self.booster_.predict(X, raw_score=True)
        probs = expit(raw_scores)

        return np.vstack((1.0 - probs, probs)).T


# ==========================================================


def evaluate_and_log(
    model_name,
    y_test,
    y_probs,
    thresholds,
    log_file,
    ranking_probs=None,
):
    """计算多维度指标并写入日志。

    ranking_probs 用于 PR-AUC/ROC-AUC 等排序指标；y_probs 用于 Brier、
    阈值分类和混淆矩阵。校准模型可借此将底层排序能力与校准后的
    决策概率分开评估。
    """
    results = []
    if ranking_probs is None:
        ranking_probs = y_probs
    pr_auc = average_precision_score(y_test, ranking_probs)
    roc_auc = roc_auc_score(y_test, ranking_probs)
    brier = brier_score_loss(y_test, y_probs)

    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"\n{'=' * 60}\n")
        f.write(f"模型: {model_name}\n")
        f.write(f"【全局概率评估指标 (阈值无关)】\n")
        f.write(f"  - PR-AUC     (核心识别能力)    : {pr_auc:.4f}\n")
        f.write(f"  - ROC-AUC    (行业基准对齐)    : {roc_auc:.4f}\n")
        f.write(f"  - Brier Score(概率校准误差，越低越好): {brier:.4f}\n")
        if ranking_probs is not y_probs:
            f.write("  - 说明: PR-AUC/ROC-AUC 基于校准前连续概率排序；Brier 与阈值指标基于校准后概率。\n")
        f.write(f"{'-' * 60}\n")
        f.write(f"【不同行政监管阈值下的治理效能评估】\n")
        f.write(
            f"{'阈值':<8} | {'Recall(安全)':<12} | {'Precision(效率)':<15} | {'FPR(行政冗余)':<14} | {'F-beta(综合)':<12}\n")
        f.write(f"{'-' * 75}\n")

        for t in thresholds:
            y_pred = (y_probs >= t).astype(int)
            recall = recall_score(y_test, y_pred, zero_division=0)
            precision = precision_score(y_test, y_pred, zero_division=0)
            fbeta = fbeta_score(y_test, y_pred, beta=2, zero_division=0)
            tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0

            f.write(f"{t:<10.2f} | {recall:<14.4f} | {precision:<17.4f} | {fpr:<16.4f} | {fbeta:<14.4f}\n")
            results.append({'Model': model_name, 'Threshold': t, 'Recall': recall, 'Precision': precision, 'FPR': fpr,
                            'F-beta': fbeta})

    results.append(
        append_best_threshold_output(
            model_name,
            y_test,
            y_probs,
            log_file,
            best_threshold=0.2,
        )
    )
    print(f"[{model_name}] 评估完成: ROC-AUC={roc_auc:.4f}, PR-AUC={pr_auc:.4f}, Brier={brier:.4f}")
    return results


def run_shap_analysis(
    model,
    X_eval,
    artifact_dir,
    model_name="Best_Model",
):
    """提取标准化SHAP绘图数据，不在模型文件中直接生成图片。"""
    print(f"\n--- 开始导出 SHAP 绘图数据 ({model_name}) ---")
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_eval)

    shap_values_pos = shap_values[1] if isinstance(shap_values, list) else shap_values
    os.makedirs(artifact_dir, exist_ok=True)
    feature_names = [str(column) for column in X_eval.columns]
    sample_ids = X_eval.index.astype(str).to_numpy()
    np.savez_compressed(
        os.path.join(artifact_dir, "shap_values.npz"),
        shap_values=np.asarray(shap_values_pos, dtype=np.float32),
        sample_id=sample_ids,
        feature_names=np.asarray(feature_names, dtype=str),
    )
    pd.DataFrame(
        np.asarray(shap_values_pos),
        index=sample_ids,
        columns=feature_names,
    ).rename_axis("sample_id").reset_index().to_csv(
        os.path.join(artifact_dir, "shap_values.csv"),
        index=False,
        encoding="utf-8-sig",
    )
    X_eval.copy().set_axis(sample_ids, axis=0).rename_axis(
        "sample_id"
    ).reset_index().to_csv(
        os.path.join(artifact_dir, "shap_feature_values.csv"),
        index=False,
        encoding="utf-8-sig",
    )
    with open(
        os.path.join(artifact_dir, "shap_feature_names.json"),
        "w",
        encoding="utf-8",
    ) as stream:
        json.dump(feature_names, stream, ensure_ascii=False, indent=2)
    print("--- SHAP 绘图数据导出完成 ---\n")


def build_threshold_metrics(y_true, probabilities, thresholds):
    """生成阈值曲线、工作量权衡和决策分析所需的长表。"""
    y_true = np.asarray(y_true, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    rows = []
    for threshold in thresholds:
        y_pred = (probabilities >= threshold).astype(int)
        tn, fp, fn, tp = confusion_matrix(
            y_true,
            y_pred,
            labels=[0, 1],
        ).ravel()
        n_samples = len(y_true)
        threshold_odds = threshold / (1.0 - threshold)
        rows.append(
            {
                "threshold": float(threshold),
                "recall": recall_score(y_true, y_pred, zero_division=0),
                "precision": precision_score(y_true, y_pred, zero_division=0),
                "fpr": fp / (fp + tn) if fp + tn else 0.0,
                "f2": fbeta_score(y_true, y_pred, beta=2, zero_division=0),
                "tn": int(tn),
                "fp": int(fp),
                "fn": int(fn),
                "tp": int(tp),
                "alerts_per_1000": 1000.0 * (tp + fp) / n_samples,
                "false_positives_per_1000": 1000.0 * fp / n_samples,
                "false_negatives_per_1000": 1000.0 * fn / n_samples,
                "net_benefit": tp / n_samples - fp / n_samples * threshold_odds,
            }
        )
    return pd.DataFrame(rows)


def export_sci_model_artifacts(
    artifact_dir,
    data_file,
    X,
    y,
    X_train,
    y_train,
    X_tune,
    y_tune,
    X_cal,
    y_cal,
    X_test,
    y_test,
    raw_scores_cal,
    raw_scores_test,
    y_probs_cal_raw,
    y_probs_cal_calibrated,
    y_probs_test_raw,
    y_probs_test_calibrated,
    selected_parameters,
):
    """输出后续九模型合并与 Figure 1–7 所需的标准化数据。"""
    os.makedirs(artifact_dir, exist_ok=True)
    locked_threshold = 0.20

    test_predictions = pd.DataFrame(
        {
            "sample_id": X_test.index.astype(str),
            "model_key": "focal_lgbm",
            "split": "test",
            "y_true": np.asarray(y_test, dtype=int),
            "raw_margin": np.asarray(raw_scores_test, dtype=float),
            "y_prob_raw": np.asarray(y_probs_test_raw, dtype=float),
            "y_prob_calibrated": np.asarray(
                y_probs_test_calibrated,
                dtype=float,
            ),
        }
    )
    test_predictions["y_pred_locked_0_20"] = (
        test_predictions["y_prob_calibrated"] >= locked_threshold
    ).astype(int)
    test_predictions.to_csv(
        os.path.join(artifact_dir, "test_predictions.csv"),
        index=False,
        encoding="utf-8-sig",
    )

    validation_predictions = pd.DataFrame(
        {
            "sample_id": X_cal.index.astype(str),
            "model_key": "focal_lgbm",
            "split": "calibration",
            "y_true": np.asarray(y_cal, dtype=int),
            "raw_margin": np.asarray(raw_scores_cal, dtype=float),
            "y_prob_raw": np.asarray(y_probs_cal_raw, dtype=float),
            "y_prob_calibrated": np.asarray(
                y_probs_cal_calibrated,
                dtype=float,
            ),
        }
    )
    validation_predictions["y_pred_locked_0_20"] = (
        validation_predictions["y_prob_calibrated"] >= locked_threshold
    ).astype(int)
    validation_predictions.to_csv(
        os.path.join(artifact_dir, "validation_predictions.csv"),
        index=False,
        encoding="utf-8-sig",
    )

    threshold_grid = np.round(np.arange(0.01, 1.00, 0.01), 2)
    validation_threshold_metrics = build_threshold_metrics(
        y_cal,
        y_probs_cal_calibrated,
        threshold_grid,
    )
    validation_threshold_metrics["split"] = "calibration"
    validation_threshold_metrics["locked_threshold"] = locked_threshold
    validation_threshold_metrics.to_csv(
        os.path.join(artifact_dir, "threshold_metrics_validation.csv"),
        index=False,
        encoding="utf-8-sig",
    )
    test_threshold_metrics = build_threshold_metrics(
        y_test,
        y_probs_test_calibrated,
        threshold_grid,
    )
    test_threshold_metrics["split"] = "test"
    test_threshold_metrics["locked_threshold"] = locked_threshold
    test_threshold_metrics.to_csv(
        os.path.join(artifact_dir, "threshold_metrics_test.csv"),
        index=False,
        encoding="utf-8-sig",
    )

    split_objects = {
        "train": (X_train, y_train),
        "tune": (X_tune, y_tune),
        "calibration": (X_cal, y_cal),
        "test": (X_test, y_test),
    }
    split_metadata = {
        name: {
            "n": int(len(y_split)),
            "positive": int(np.asarray(y_split).sum()),
            "negative": int(len(y_split) - np.asarray(y_split).sum()),
            "prevalence": float(np.asarray(y_split).mean()),
        }
        for name, (_, y_split) in split_objects.items()
    }
    categorical_features = [
        str(column)
        for column in X.columns
        if isinstance(X[column].dtype, pd.CategoricalDtype)
    ]
    metadata = {
        "schema_version": "1.0",
        "model_key": "focal_lgbm",
        "model_name": "LightGBM + Focal Loss",
        "data_file": os.path.abspath(data_file) if data_file else None,
        "label_column": "Target_Penalty",
        "label_rule": "Fine Amount > 170734.80",
        "sample_id_rule": "zero-based original CSV row index",
        "total_samples": int(len(y)),
        "positive_samples": int(np.asarray(y).sum()),
        "prevalence": float(np.asarray(y).mean()),
        "feature_count": int(X.shape[1]),
        "categorical_feature_count": int(len(categorical_features)),
        "categorical_features": categorical_features,
        "split_strategy": {
            "test": "stratified 10%, random_state=42",
            "development": "remaining 90%",
            "train": "77.78% of development, stratified, random_state=42",
            "validation_pool": "22.22% of development",
            "tune_calibration": "validation pool split 50/50, stratified, random_state=43",
        },
        "splits": split_metadata,
        "preprocessing": {
            "numeric": "converted to float32",
            "categorical": "pandas category for native LightGBM handling",
            "imputation": "none in model script",
            "resampling": "none",
            "smote": False,
        },
        "model_selection": "alpha/gamma/Hessian and best iteration selected on tune PR-AUC",
        "final_fit": "train+tune only",
        "calibration": "Platt/Sigmoid fitted on calibration split only",
        "test_usage": "locked final evaluation only",
        "threshold_policy": "prespecified locked threshold",
        "locked_threshold": locked_threshold,
        "selected_parameters": selected_parameters,
        "figure_inputs": {
            "figure_1": ["experiment_metadata.json"],
            "figure_2": ["test_predictions.csv:y_true,y_prob_raw"],
            "figure_3": ["test_predictions.csv:y_true,y_prob_calibrated"],
            "figure_4": ["validation_predictions.csv", "threshold_metrics_validation.csv"],
            "figure_5": ["test_predictions.csv:y_true,y_prob_raw,y_prob_calibrated"],
            "figure_6": ["shap_values.npz", "shap_values.csv", "shap_feature_values.csv", "shap_feature_names.json"],
            "figure_7": ["test_predictions.csv", "threshold_metrics_test.csv"],
        },
    }
    with open(
        os.path.join(artifact_dir, "experiment_metadata.json"),
        "w",
        encoding="utf-8",
    ) as stream:
        json.dump(metadata, stream, ensure_ascii=False, indent=2)

    manifest = {
        "model_key": "focal_lgbm",
        "artifact_dir": os.path.abspath(artifact_dir),
        "files": {
            "metadata": "experiment_metadata.json",
            "test_predictions": "test_predictions.csv",
            "validation_predictions": "validation_predictions.csv",
            "validation_threshold_metrics": "threshold_metrics_validation.csv",
            "test_threshold_metrics": "threshold_metrics_test.csv",
            "shap_values_binary": "shap_values.npz",
            "shap_values_table": "shap_values.csv",
            "shap_feature_values": "shap_feature_values.csv",
            "shap_feature_names": "shap_feature_names.json",
        },
    }
    with open(
        os.path.join(artifact_dir, "artifact_manifest.json"),
        "w",
        encoding="utf-8",
    ) as stream:
        json.dump(manifest, stream, ensure_ascii=False, indent=2)

    print(f"[SCI绘图数据] 标准化结果包已保存: {artifact_dir}")


def run_experiment(X, y, log_dir, data_file=None):
    """仅运行 LightGBM + Focal Loss 主力模型。"""
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"experiment_log_{timestamp}_lightGBM_FocalLoss.txt")
    artifact_dir = os.path.join(
        log_dir,
        "sci_model_outputs",
        "focal_lgbm",
        timestamp,
    )

    X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.1, random_state=42, stratify=y)
    X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.2222, random_state=42,
                                                      stratify=y_temp)
    X_tune, X_cal, y_tune, y_cal = train_test_split(
        X_val,
        y_val,
        test_size=0.5,
        random_state=43,
        stratify=y_val,
    )

    with open(log_file, 'w', encoding='utf-8') as f:
        f.write(f"Nursing Home LightGBM + Focal Loss实验报告 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"目标定义: 极度不平衡模型 (罚款金额 > $170,734.80, Target=1)\n")
        f.write(
            f"划分比例: 训练集 {X_train.shape[0]}, "
            f"调参集 {X_tune.shape[0]}, 校准集 {X_cal.shape[0]}, "
            f"测试集 {X_test.shape[0]}\n"
        )
        f.write(
            "Focal约束: 不使用SMOTE、scale_pos_weight或is_unbalance；"
            "alpha/gamma/Hessian仅由调参集PR-AUC选择。\n"
        )

    thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]

    # ================= Focal Loss 调参与训练 =================
    # alpha/gamma 仅在 tuning 子集上选择；calibration 子集不参与调参，
    # 测试集不参与模型选择。
    # Low-gamma search: this dataset contains both weak positives and hard
    # negatives, so large gamma values can over-focus on simulation noise.
    alpha_grid = [0.85, 0.90, 0.95]
    gamma_grid = [0.25, 0.50, 0.75, 1.00]
    hessian_modes = ['bce_proxy', 'focal_weighted']
    best_focal_model = None
    best_tuning_pr_auc = -np.inf
    best_alpha = None
    best_gamma = None
    best_hessian_mode = None

    print("\n--- 在独立调参集上搜索 Focal Loss alpha/gamma ---")
    for hessian_mode in hessian_modes:
        for alpha in alpha_grid:
            for gamma in gamma_grid:
                candidate_model = FocalLossLGBM(
                    n_estimators=1000,
                    learning_rate=0.025,
                    num_leaves=15,
                    max_depth=5,
                    min_child_samples=30,
                    subsample=0.85,
                    subsample_freq=1,
                    colsample_bytree=0.80,
                    reg_alpha=0.0,
                    reg_lambda=1.0,
                    metric='None',
                    random_state=42,
                    n_jobs=-1,
                    verbose=-1,
                    objective=focal_loss_custom(
                        alpha=alpha,
                        gamma=gamma,
                        hessian_mode=hessian_mode,
                    ),
                )
                candidate_model.fit(
                    X_train,
                    y_train,
                    eval_set=[(X_tune, y_tune)],
                    eval_metric=focal_pr_auc_eval,
                    callbacks=[
                        lgb.early_stopping(
                            stopping_rounds=100,
                            first_metric_only=True,
                            verbose=False,
                        )
                    ],
                )
                tuning_probs = candidate_model.predict_proba(X_tune)[:, 1]
                tuning_pr_auc = average_precision_score(
                    y_tune,
                    tuning_probs,
                )
                candidate_best_iteration = getattr(
                    candidate_model,
                    'best_iteration_',
                    None,
                )
                print(
                    f"hessian={hessian_mode}, alpha={alpha:.2f}, "
                    f"gamma={gamma:.2f}, tuning PR-AUC={tuning_pr_auc:.4f}, "
                    f"best_iteration={candidate_best_iteration}"
                )

                # focal_weighted 作为目标函数敏感性消融保留在CSV中。
                # 主模型固定使用数值稳定、Hessian始终为正的BCE代理；
                # 避免因单个调参集上极小的随机优势切换二阶近似定义。
                if (
                    hessian_mode == 'bce_proxy'
                    and tuning_pr_auc > best_tuning_pr_auc
                ):
                    best_tuning_pr_auc = tuning_pr_auc
                    best_focal_model = candidate_model
                    best_alpha = alpha
                    best_gamma = gamma
                    best_hessian_mode = hessian_mode

    if best_focal_model is None:
        raise RuntimeError("Focal Loss 调参失败，未得到可用模型。")

    with open(log_file, 'a', encoding='utf-8') as f:
        selected_best_iteration = getattr(
            best_focal_model,
            'best_iteration_',
            None,
        )
        if not selected_best_iteration or selected_best_iteration <= 0:
            selected_best_iteration = 1000
        f.write(
            "\nFocal Loss 调参结果: "
            f"hessian={best_hessian_mode}, alpha={best_alpha:.2f}, "
            f"gamma={best_gamma:.2f}, "
            f"tuning PR-AUC={best_tuning_pr_auc:.4f}, "
            f"best_iteration={selected_best_iteration}\n"
        )
        f.write(
            "选择规则: focal_weighted仅作为Hessian敏感性消融；"
            "主模型固定从数值稳定的bce_proxy候选中按调参集PR-AUC选择。\n"
        )

    # 参数和迭代次数锁定后，把训练集与调参集合并重新训练。
    # 校准集和测试集均不参与这一步：X_cal只学习概率映射，X_test只评估。
    X_final_train = pd.concat([X_train, X_tune], axis=0)
    y_final_train = pd.concat([y_train, y_tune], axis=0)
    final_focal_model = FocalLossLGBM(
        n_estimators=int(selected_best_iteration),
        learning_rate=0.025,
        num_leaves=15,
        max_depth=5,
        min_child_samples=30,
        subsample=0.85,
        subsample_freq=1,
        colsample_bytree=0.80,
        reg_alpha=0.0,
        reg_lambda=1.0,
        metric='None',
        random_state=42,
        n_jobs=-1,
        verbose=-1,
        objective=focal_loss_custom(
            alpha=best_alpha,
            gamma=best_gamma,
            hessian_mode=best_hessian_mode,
        ),
    )
    print(
        "\n--- 参数已锁定：合并训练集与调参集重新训练最终Focal模型 "
        f"(n={len(y_final_train)}, iterations={selected_best_iteration}) ---"
    )
    final_focal_model.fit(X_final_train, y_final_train)

    with open(log_file, 'a', encoding='utf-8') as f:
        f.write("\n最终Focal模型重新训练:\n")
        f.write(
            f"  - 训练数据: train+tuning={len(y_final_train)}条；"
            f"阳性率={y_final_train.mean():.4%}\n"
        )
        f.write(
            f"  - 锁定参数: alpha={best_alpha:.2f}, "
            f"gamma={best_gamma:.2f}, hessian={best_hessian_mode}, "
            f"n_estimators={int(selected_best_iteration)}\n"
        )
        f.write("  - calibration和test未参与最终模型拟合。\n")

    # Raw Focal 连续概率负责排序指标；独立 calibration 子集用于学习
    # 连续的 Platt/Sigmoid 映射。所有模型固定使用阈值 0.20。
    print(
        "\n--- 使用独立校准集执行 Platt/Sigmoid 概率校准；"
        "固定评价阈值为 0.20 ---"
    )
    raw_scores_cal = final_focal_model.booster_.predict(
        X_cal,
        raw_score=True,
    )
    raw_scores_test = final_focal_model.booster_.predict(
        X_test,
        raw_score=True,
    )
    platt_calibrator = LogisticRegression(
        C=1e6,
        solver='lbfgs',
        max_iter=2000,
        random_state=42,
    )
    platt_calibrator.fit(
        np.asarray(raw_scores_cal).reshape(-1, 1),
        y_cal,
    )
    y_probs_test_calibrated = platt_calibrator.predict_proba(
        np.asarray(raw_scores_test).reshape(-1, 1)
    )[:, 1]

    y_probs_test_raw = final_focal_model.predict_proba(X_test)[:, 1]
    y_probs_cal_raw = expit(np.asarray(raw_scores_cal, dtype=float))
    y_probs_cal_calibrated = platt_calibrator.predict_proba(
        np.asarray(raw_scores_cal).reshape(-1, 1)
    )[:, 1]

    with open(log_file, 'a', encoding='utf-8') as f:
        f.write("\nPlatt/Sigmoid独立校准诊断:\n")
        f.write(
            f"  - coefficient={platt_calibrator.coef_[0, 0]:.6f}, "
            f"intercept={platt_calibrator.intercept_[0]:.6f}\n"
        )
        f.write(
            "  - calibration Brier: "
            f"raw={brier_score_loss(y_cal, y_probs_cal_raw):.6f}, "
            f"mapped_probability={brier_score_loss(y_cal, y_probs_cal_calibrated):.6f}\n"
        )
        f.write(
            "  - test Brier: "
            f"raw={brier_score_loss(y_test, y_probs_test_raw):.6f}, "
            f"mapped_probability={brier_score_loss(y_test, y_probs_test_calibrated):.6f}\n"
        )

    evaluate_and_log(
        "LightGBM + Focal Loss",
        y_test,
        y_probs_test_calibrated,
        thresholds,
        log_file,
        ranking_probs=y_probs_test_raw,
    )

    export_sci_model_artifacts(
        artifact_dir=artifact_dir,
        data_file=data_file,
        X=X,
        y=y,
        X_train=X_train,
        y_train=y_train,
        X_tune=X_tune,
        y_tune=y_tune,
        X_cal=X_cal,
        y_cal=y_cal,
        X_test=X_test,
        y_test=y_test,
        raw_scores_cal=raw_scores_cal,
        raw_scores_test=raw_scores_test,
        y_probs_cal_raw=y_probs_cal_raw,
        y_probs_cal_calibrated=y_probs_cal_calibrated,
        y_probs_test_raw=y_probs_test_raw,
        y_probs_test_calibrated=y_probs_test_calibrated,
        selected_parameters={
            "alpha": float(best_alpha),
            "gamma": float(best_gamma),
            "hessian_mode": str(best_hessian_mode),
            "n_estimators": int(selected_best_iteration),
        },
    )

    run_shap_analysis(
        final_focal_model,
        X_test,
        artifact_dir,
        model_name="Focal_Loss_Tree_Model",
    )

    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"\nSCI绘图数据包: {artifact_dir}\n")


def main():
    print("--- 启动研究项目：LightGBM + Focal Loss (含 Platt/Sigmoid 概率校准) ---")

    data_file = r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据\NH_ProviderInfo_Combine.csv"
    log_dir = r"C:\ASQ备考\博士论文\西藏项目\Main coding\logs"

    if not os.path.exists(data_file):
        print(f"错误：找不到文件 -> {data_file}")
        return

    X, y = prepare_data(data_file)
    run_experiment(X, y, log_dir, data_file=data_file)
    print("--- Focal Loss实验结束，请前往 logs 文件夹查看报告 ---")


SCI_MODEL_KEY = "focal_lgbm"


def run_sci_pipeline():
    """运行统一、防泄漏的九模型SCI流水线中的主力Focal-LightGBM分支。"""
    from sci_unified_pipeline import run_single_model

    return run_single_model(SCI_MODEL_KEY)


if __name__ == "__main__":
    import sys as _sys

    if "--sci" in _sys.argv:
        run_sci_pipeline()
    else:
        main()
