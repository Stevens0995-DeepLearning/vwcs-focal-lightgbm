"""Fixed eight-cell paired comparison; prospective windows as in validate_vi_cms_time.
Usage: python extend_vi_temporal.py [--out NEW_DIRECTORY]
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from scipy.special import expit
from sklearn.metrics import average_precision_score,roc_auc_score
from ablation_models import FOCAL,FOCAL_BASE_KWARGS
B=Path(__file__).resolve().parent
src=B/'logs/Revision2_Vi_CMS_time_20261110'
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=B/'logs/Revision2_Vi_temporal_extension')
out=parser.parse_args().out;out.mkdir(parents=True,exist_ok=False)
protocol=json.loads((src/'protocol.json').read_text(encoding='utf8'))
assert protocol['policy']['chosen']=='upper100' and protocol['policy']['primary_budget']==.05
cc='CMS Certification Number (CCN)';hf='Total Amount of Fines in Dollars'
names=['State','Ownership Type','Provider Type','Reported Total Nurse Staffing Hours per Resident per Day','Rating Cycle 1 Total Number of Health Deficiencies']
def load(tag,year):
    d=pd.read_csv(src/(tag+'.csv'),dtype={cc:str})
    file=next(Path(s) for s in protocol['files_sha256'] if s.endswith(f'ProviderInfo_May{year}.csv'))
    assert hashlib.sha256(file.read_bytes()).hexdigest()==protocol['files_sha256'][str(file)]
    raw=pd.read_csv(file,usecols=[cc,hf,'Processing Date'],dtype={cc:str})
    assert pd.to_datetime(raw['Processing Date']).max()<=pd.Timestamp(protocol['cohorts'][year-2024]['origin'])
    v=pd.to_numeric(raw[hf],errors='coerce');assert not (v.dropna()<0).any()
    history=raw.assign(log_prior_fines=np.log1p(v)).set_index(cc)['log_prior_fines']
    assert history.index.is_unique and set(d[cc])==set(history.index)
    d['log_prior_fines']=d[cc].map(history);return d
tr=load('train',2024);te=load('validation',2025)
y=tr.y.to_numpy();truth=te.y.to_numpy();v=tr.V_i.to_numpy()
cut=protocol['train_v_q75'];hp=(te.V_i.to_numpy()>=cut)&(truth==1);k=int(np.ceil(.05*len(te)))
legacy=FOCAL['focal_loss_custom'](.9,.25,'bce_proxy');rows=[];scores={}
pred=te[[cc,'y','V_i','log_prior_fines']].copy()
for design,extra in {'base':[],'vi':['V_i'],'history':['log_prior_fines'],'both':['V_i','log_prior_fines']}.items():
    columns=names+extra;xt=tr[columns].copy();xe=te[columns].copy()
    for col in columns:
        if col in names[:3]:
            xt[col]=xt[col].astype('category');xe[col]=pd.Categorical(xe[col],categories=xt[col].cat.categories)
        else:xt[col]=xt[col].astype('float32');xe[col]=xe[col].astype('float32')
    for arm,beta in [('uniform',0.),('upper100',1.)]:
        key=design+'_'+arm;m=1+beta*np.maximum(v-cut,0)/(1-cut);w=np.where(y==1,.9*m/m[y==1].mean(),.1)
        assert np.isclose(w[y==1].sum(),.9*y.sum())
        def objective(labels,margin):
            assert np.array_equal(labels,y);p=np.clip(expit(margin),1e-6,1-1e-6)
            return legacy(labels,margin)[0]*w/np.where(y==1,.9,.1),np.maximum(w*p*(1-p),1e-5)
        model=FOCAL['FocalLossLGBM'](**{**FOCAL_BASE_KWARGS,'objective':objective,'n_estimators':300,'n_jobs':2})
        model.fit(xt,y);s=model.booster_.predict(xe,raw_score=True,num_threads=2)
        if design=='base':assert np.allclose(s,te[arm+'_margin'],atol=1e-7,rtol=0)
        o=np.lexsort((np.arange(len(s)),-s));keep=np.zeros(len(s),bool);keep[o[:k]]=True
        pred[key+'_margin']=s;pred[key+'_alert']=keep
        tp=int(truth[keep].sum());ht=int(hp[keep].sum())
        rows.append(dict(config=key,K=k,TP=tp,FP=k-tp,FN=int(truth.sum()-tp),high_TP=ht,high_FN=int(hp.sum()-ht),AP=average_precision_score(truth,s),ROC_AUC=roc_auc_score(truth,s),precision=tp/k))
        scores[key]=(o,np.r_[np.flatnonzero(np.diff(s[o])),len(s)-1])
res=pd.DataFrame(rows);res.to_csv(out/'metrics.csv',index=False);pred.to_csv(out/'paired_predictions.csv',index=False)
comparisons=[(d+'_upper100','base_upper100') for d in ['vi','history','both']]+[(d+'_upper100',d+'_uniform') for d in ['base','vi','history','both']]
def calc(n,o,ends):
    c=n[o];tot=c.cumsum();tp=(truth[o]*c).cumsum()[ends];den=tot[ends]
    ap=(np.diff(np.r_[0,tp])*tp/np.maximum(den,1)).sum()/tp[-1]
    kept=np.minimum(c,np.maximum(k-(tot-c),0))
    return np.array([ap,(kept@hp[o])/(n@hp),(kept@truth[o])/(n@truth)])
def deltas(n):
    stats={key:calc(n,*pair) for key,pair in scores.items()}
    return np.array([stats[a]-stats[b] for a,b in comparisons])
n=len(te);point=deltas(np.ones(n,dtype=int));rng=np.random.default_rng(42);boot=[]
for _ in range(2000):
    cnt=np.bincount(rng.integers(0,n,n),minlength=n)
    if cnt@hp:boot.append(deltas(cnt))
lo,hi=np.quantile(boot,[.025,.975],axis=0)
ci=pd.DataFrame([dict(model=a,reference=b,metric=name,delta=point[i,j],lower=lo[i,j],upper=hi[i,j]) for i,(a,b) in enumerate(comparisons) for j,name in enumerate(['AP','high_recall','recall'])]);ci.to_csv(out/'paired_differences.csv',index=False)
print(res.to_string(index=False));print(ci.to_string(index=False))
