"""Revision 6: nine archived runs and a matched three-model benchmark."""
from pathlib import Path
import hashlib,json,platform,sys,importlib.metadata as md
import numpy as np,pandas as pd,lightgbm as lgb
from sklearn.preprocessing import StandardScaler,OneHotEncoder
from sklearn.metrics import average_precision_score,brier_score_loss
from sklearn.linear_model import LogisticRegression
from scipy.special import expit
from imblearn.over_sampling import SMOTE
from ablation_data import load_data_and_splits,split_manifest,DEFAULT_DATA
from ablation_models import FOCAL,FOCAL_BASE_KWARGS
from run_ablation import score_predictions
base=Path(__file__).resolve().parent
o=base/'logs/Revision6_Baseline_Protocol';o.mkdir(exist_ok=True)
r=base/'logs/Revision2_Vi_20261110'
meta=json.loads((r/'protocol.json').read_text('utf8'))
assert hashlib.sha256(DEFAULT_DATA.read_bytes()).hexdigest()==meta['dataset_sha256'][str(DEFAULT_DATA)]
X,y,S=load_data_and_splits();assert split_manifest(S)==meta['splits']
tr,tu,ca,te=[S[k][0].index for k in ('train','tune','calibration','test')];rf=np.r_[tr,tu]
v=pd.read_csv(r/'vulnerability_auxiliary.csv',float_precision='round_trip').set_index('sample_id')
assert v.index.equals(y.index) and np.array_equal(v.y_true,y)
archive=[];indices=[];source=base/'logs/sci_model_outputs'
for m in sorted(source.glob('*/*/experiment_metadata.json')):
    a=json.loads(m.read_text('utf8'));key=a['model_key'];run=m.parent.name
    if key=='lgbm_unbalance' or run=='20260802_190331':continue
    u=pd.read_csv(m.parent/'test_predictions.csv').set_index('sample_id');assert u.index.is_unique
    overlap=len(set(u.index)&set(te));assert np.array_equal(y.loc[u.index],u.y_true)
    met=score_predictions(u.y_true,u.y_prob_raw,u.y_prob_calibrated)
    indices.append(dict(model=key,overlap=overlap,n=len(u),run=run,**met))
    common=key in ('lgbm_baseline','focal_lgbm')
    prep='Native categorical; numeric float; no artificial noise' if common else ('Five-bin coarsening; Gaussian noise (0.3 SD); one-hot; standardize' if key in ('lr','svm') else 'Decile zigzag + noise; one-hot; standardize')
    if key=='random_forest':prep='Decile zigzag without added noise; one-hot; standardize'
    params=a.get('selected_parameters',a.get('model_parameters',{}))
    if key=='focal_lgbm':params={**FOCAL_BASE_KWARGS,**params}
    archive.append(dict(model=a['model_name'],run=run,features=a['feature_count'],partitions='; '.join(k+':'+str(t['n']) for k,t in a['splits'].items()),preprocessing=prep,search=('3 alpha x 4 gamma x 2 curvature settings in script; primary selection restricted to BCE proxy; tune AP' if key=='focal_lgbm' else 'Fixed tree config; tune early stopping' if key=='lgbm_baseline' else 'Single fixed configuration in archived script; no external search documented'),settings=json.dumps(params,ensure_ascii=False),weights_sampling=a.get('resampling') or 'Focal; no resampling',final_fit=a.get('final_fit','Training only in script'),calibration=a['calibration'],source=str(m)))
assert len(archive)==9
pd.DataFrame(archive).to_csv(o/'Table_S8_config.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(indices).to_csv(o/'archive_scores.csv',index=False)
cats=X.select_dtypes('category').columns.tolist();nums=X.columns.difference(cats,sort=False)
assert len(nums)==13 and len(cats)==3
med=X.loc[tr,nums].median();assert med.notna().all()
scale=StandardScaler().fit(X.loc[tr,nums].fillna(med))
cat=X[cats].astype(object).fillna('__missing__')
enc=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(cat.loc[tr])
Z=pd.DataFrame(np.column_stack([scale.transform(X[nums].fillna(med)),enc.transform(cat)]).astype('float32'),index=y.index)
common={**FOCAL_BASE_KWARGS,'metric':'None','n_jobs':2,'verbosity':-1,'random_state':42,'boost_from_average':False}
legacy=FOCAL['focal_loss_custom'](.9,.25,'bce_proxy')
def fitarm(arm,idx,leaves,depth,n,ev):
    train=Z.loc[idx];labels=y.loc[idx].to_numpy()
    if arm=='SMOTE-LightGBM':train,labels=SMOTE(sampling_strategy=1.,k_neighbors=5,random_state=42).fit_resample(train,labels)
    def obj(lab,z):
        assert np.array_equal(lab,labels)
        w=np.where(lab==1,.9*(1+v.loc[idx,'V_i'].to_numpy()),.1);p=np.clip(expit(z),1e-6,1-1e-6)
        return legacy(lab,z)[0]*w/np.where(lab==1,.9,.1),np.maximum(w*p*(1-p),1e-5)
    model=lgb.LGBMClassifier(**{**common,'num_leaves':leaves,'max_depth':depth,'n_estimators':n,'objective':obj if arm.startswith('VWCS') else 'binary'})
    kws=dict(eval_set=[(Z.loc[tu],y.loc[tu])],eval_metric=lambda yy,ss:('AP',average_precision_score(yy,ss),True),callbacks=[lgb.early_stopping(100,first_metric_only=True,verbose=False)]) if ev else {}
    model.fit(train,labels,**kws)
    return model
grid=[(7,3),(15,5),(31,6)]
arms=['LightGBM','SMOTE-LightGBM','VWCS-Focal-LightGBM']
trials=[];res=[];pred=pd.DataFrame({'y_true':y.loc[te],'high_V':v.loc[te,'high_V']})
for arm in arms:
    for leaves,depth in grid:
        model=fitarm(arm,tr,leaves,depth,1000,True)
        trials.append(dict(model=arm,leaves=leaves,depth=depth,round=model.best_iteration_,tune_AP=model.best_score_['valid_0']['AP']))
    best=max(trials[-3:],key=lambda c:c['tune_AP'])
    model=fitarm(arm,rf,best['leaves'],best['depth'],best['round'],False)
    def margin(idx):return model.booster_.predict(Z.loc[idx],raw_score=True,num_threads=2)
    cal=LogisticRegression(C=1e6,solver='lbfgs',max_iter=2000,random_state=42).fit(margin(ca)[:,None],y.loc[ca])
    z=margin(te);p=expit(z);q=cal.predict_proba(z[:,None])[:,1];dec=q>=.20
    pred[arm+'_raw']=p;pred[arm+'_cal']=q
    res.append(dict(**best,Brier_raw=brier_score_loss(y.loc[te],p),**score_predictions(y.loc[te],p,q),high_TP=int((dec & pred.high_V.eq(1) & pred.y_true.eq(1)).sum())))
    print(res[-1],flush=True)
pd.DataFrame(res).to_csv(o/'Table_S9_matched.csv',index=False);pd.DataFrame(trials).to_csv(o/'tuning_grid.csv',index=False);pred.to_csv(o/'paired_predictions.csv',index_label='sample_id')
prot=dict(versions={k:md.version(k) for k in ['numpy','pandas','scipy','scikit-learn','imbalanced-learn','lightgbm']},python=sys.version,cpu=platform.processor(),os=platform.platform(),data_sha256=meta['dataset_sha256'],splits=split_manifest(S),columns=list(X.columns),encoding_dim=Z.shape[1],n_neighbors=5,synthetic_train=int(len(tr)-2*y.loc[tr].sum()),synthetic_refit=int(len(rf)-2*y.loc[rf].sum()),common_parameters=common,grid=grid,threshold=.2,threads=2)
(o/'protocol.json').write_text(json.dumps(prot,indent=2,default=str,ensure_ascii=False),encoding='utf8')
