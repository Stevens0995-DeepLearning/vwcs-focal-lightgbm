import os
import re

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    confusion_matrix,
    fbeta_score,
    precision_score,
    recall_score,
)


def platt_calibrate_probabilities(
    y_calibration,
    calibration_probabilities,
    evaluation_probabilities,
):
    """使用独立校准集拟合 Platt/Sigmoid 映射。

    输入概率先转换为 logit，再拟合一维 Logistic Regression。返回校准后
    的评估概率和拟合完成的校准器；原始概率应继续用于 PR-AUC/ROC-AUC。
    """
    epsilon = 1e-6
    calibration_probabilities = np.clip(
        np.asarray(calibration_probabilities, dtype="float64"),
        epsilon,
        1.0 - epsilon,
    )
    evaluation_probabilities = np.clip(
        np.asarray(evaluation_probabilities, dtype="float64"),
        epsilon,
        1.0 - epsilon,
    )
    calibration_logits = np.log(
        calibration_probabilities / (1.0 - calibration_probabilities)
    ).reshape(-1, 1)
    evaluation_logits = np.log(
        evaluation_probabilities / (1.0 - evaluation_probabilities)
    ).reshape(-1, 1)

    calibrator = LogisticRegression(
        C=1e6,
        solver="lbfgs",
        max_iter=1000,
        random_state=42,
    )
    calibrator.fit(calibration_logits, y_calibration)
    calibrated_probabilities = calibrator.predict_proba(
        evaluation_logits
    )[:, 1]
    return calibrated_probabilities, calibrator


def append_best_threshold_output(
    model_name,
    y_true,
    probabilities,
    log_file,
    best_threshold=0.2,
):
    """在完整阈值表末尾追加一行“最佳阈值”结果并返回结构化记录。"""
    predictions = (
        np.asarray(probabilities) >= float(best_threshold)
    ).astype(int)
    recall = recall_score(
        y_true,
        predictions,
        zero_division=0,
    )
    precision = precision_score(
        y_true,
        predictions,
        zero_division=0,
    )
    fbeta = fbeta_score(
        y_true,
        predictions,
        beta=2,
        zero_division=0,
    )
    tn, fp, fn, tp = confusion_matrix(
        y_true,
        predictions,
        labels=[0, 1],
    ).ravel()
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

    label = f"最佳阈值({best_threshold:.2f})"
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"{'-' * 75}\n")
        f.write(
            f"{label:<14} | {recall:<14.4f} | "
            f"{precision:<17.4f} | {fpr:<16.4f} | "
            f"{fbeta:<14.4f}\n"
        )

    return {
        "Model": model_name,
        "Result_Type": "最佳阈值",
        "Threshold": float(best_threshold),
        "Recall": recall,
        "Precision": precision,
        "FPR": fpr,
        "F-beta": fbeta,
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp),
    }


def save_confusion_matrix_outputs(
    model_name,
    y_test,
    y_probs,
    thresholds,
    log_file,
    plot_threshold=0.2,
):
    """保存各阈值的混淆矩阵数据，并绘制指定阈值的混淆矩阵。"""
    output_dir = os.path.dirname(os.path.abspath(log_file))
    os.makedirs(output_dir, exist_ok=True)

    rows = []
    for threshold in thresholds:
        y_pred = (np.asarray(y_probs) >= threshold).astype(int)
        tn, fp, fn, tp = confusion_matrix(
            y_test,
            y_pred,
            labels=[0, 1],
        ).ravel()

        rows.append(
            {
                "Model": model_name,
                "Threshold": float(threshold),
                "TN": int(tn),
                "FP": int(fp),
                "FN": int(fn),
                "TP": int(tp),
                "Test_Samples": int(len(y_test)),
            }
        )

    if not rows:
        raise ValueError("thresholds 不能为空，至少需要提供一个分类阈值。")

    safe_model_name = re.sub(r'[<>:"/\\|?*]+', "_", model_name).strip(" .")
    if not safe_model_name:
        safe_model_name = "model"

    results_df = pd.DataFrame(rows)
    csv_path = os.path.join(
        output_dir,
        f"confusion_matrix_data_{safe_model_name}.csv",
    )
    results_df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    selected_index = (
        results_df["Threshold"] - float(plot_threshold)
    ).abs().idxmin()
    selected = results_df.loc[selected_index]
    selected_threshold = float(selected["Threshold"])

    matrix = np.array(
        [
            [selected["TN"], selected["FP"]],
            [selected["FN"], selected["TP"]],
        ],
        dtype=int,
    )

    fig, ax = plt.subplots(figsize=(6, 5))
    image = ax.imshow(matrix, interpolation="nearest", cmap="Blues")
    fig.colorbar(image, ax=ax)
    ax.set(
        xticks=[0, 1],
        yticks=[0, 1],
        xticklabels=["Predicted 0", "Predicted 1"],
        yticklabels=["Actual 0", "Actual 1"],
        xlabel="Predicted label",
        ylabel="Actual label",
        title=(
            f"{model_name}\n"
            f"Confusion Matrix (threshold={selected_threshold:.2f})"
        ),
    )

    cutoff = matrix.max() / 2 if matrix.size else 0
    for row in range(2):
        for column in range(2):
            ax.text(
                column,
                row,
                f"{matrix[row, column]:,}",
                ha="center",
                va="center",
                color="white" if matrix[row, column] > cutoff else "black",
            )

    fig.tight_layout()
    png_path = os.path.join(
        output_dir,
        (
            f"confusion_matrix_{safe_model_name}"
            f"_threshold_{selected_threshold:.2f}.png"
        ),
    )
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.close(fig)

    print(f"混淆矩阵数据已保存: {csv_path}")
    print(f"混淆矩阵图已保存: {png_path}")
    return results_df
