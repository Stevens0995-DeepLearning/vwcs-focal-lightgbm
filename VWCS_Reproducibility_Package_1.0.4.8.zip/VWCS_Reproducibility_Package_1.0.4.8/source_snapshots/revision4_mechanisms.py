"""Capacity-matched revision experiment. Does not reconstruct missing server parameters."""
import argparse, hashlib,json
from pathlib import Path
import lightgbm as lgb
import numpy as np,pandas as pd
from scipy.special import expit
from sklearn.metrics import average_precision_score
from ablation_data import DEFAULT_DATA,load_data_and_splits,split_manifest
from ablation_models import FOCAL,FOCAL_BASE_KWARGS,focal_eval
from run_ablation import MAX_ROUNDS,platt_predict,score_predictions
b=Path(__file__).resolve().parent;r=b/'logs/Revision2_Vi_20261110'
pa=argparse.ArgumentParser();pa.add_argument('--out',type=Path,default=b/'logs/Revision4_Mechanisms');out=pa.parse_args().out;out.mkdir(parents=True,exist_ok=False)
p=json.loads((r/'protocol.json').read_text(encoding='utf8'))
assert hashlib.sha256(DEFAULT_DATA.read_bytes()).hexdigest()==p['dataset_sha256'][str(DEFAULT_DATA)]
X,y,splits=load_data_and_splits();assert split_manifest(splits)==p['splits']
a=pd.read_csv(r/'vulnerability_auxiliary.csv',float_precision='round_trip',dtype={'ccn':str}).set_index('sample_id')
assert a.index.equals(y.index) and np.array_equal(a.y_true,y)
tr=splits['train'][0].index; xt,yt=splits['tune'];xc,yc=splits['calibration'];xe,ye=splits['test'];rf=np.r_[tr,xt.index];v=a.V_i.to_numpy()
old=pd.read_csv(r/'paired_predictions.csv',float_precision='round_trip').set_index('sample_id').loc[xe.index]
pred=a.loc[xe.index,['y_true','ccn','high_V']].copy();hp=pred.high_V.eq(1)&ye.eq(1);assert hp.sum()==38
rows=[]; masses=[]
for arm in ['M0','M1','M2','M3','M4','M5']:
    def model(idx,n):
        labels=y.loc[idx].to_numpy(); pos=labels==1; w=np.where(pos,.9,.1)
        if arm in ('M0','M2'): w=np.full(len(idx),w.mean())
        if arm=='M4': w[pos]*=1+v[idx][pos]
        if arm=='M5': w[pos]*=1+v[idx][pos].mean()
        masses.append([arm,len(idx),w.sum(),w[pos].sum()])
        kw={**FOCAL_BASE_KWARGS,'n_estimators':int(n),'n_jobs':2}
        if arm=='M0':return lgb.LGBMClassifier(**kw,objective='binary',boost_from_average=False),w
        legacy=FOCAL['focal_loss_custom'](.9,.0 if arm=='M1' else .25,'bce_proxy')
        def objective(lab,raw):
            assert np.array_equal(lab,labels)
            q=np.clip(expit(raw),1e-6,1-1e-6)
            return legacy(lab,raw)[0]*w/np.where(pos,.9,.1),np.maximum(w*q*(1-q),1e-5)
        return FOCAL['FocalLossLGBM'](**kw,objective=objective),None
    m,w=model(tr,MAX_ROUNDS)
    metric=(lambda truth,prob:('ap',average_precision_score(truth,prob),True)) if arm=='M0' else focal_eval()
    m.fit(X.loc[tr],y.loc[tr],sample_weight=w,eval_set=[(xt,yt)],eval_metric=metric,callbacks=[lgb.early_stopping(100,first_metric_only=True,verbose=False)])
    it=int(m.best_iteration_ or MAX_ROUNDS);f,w=model(rf,it);f.fit(X.loc[rf],y.loc[rf],sample_weight=w)
    raw,q,_=platt_predict(f,xc,yc,xe)
    if arm in ['M3','M4','M5']:
        key={'M3':'A','M4':'B','M5':'C'}[arm]
        assert np.allclose(q,old[key+'_calibrated'],rtol=0,atol=1e-9) and np.allclose(raw,old[key+'_raw_probability'],rtol=0,atol=1e-9)
    dec=q>=.2;pred[arm+'_raw']=raw;pred[arm+'_q']=q
    rows.append(dict(arm=arm,iteration=it,**score_predictions(ye,raw,q),high_tp=int((hp&dec).sum()),high_fn=int((hp&~dec).sum())))
    print(arm,it,rows[-1]['pr_auc'],flush=True)
res=pd.DataFrame(rows);res.to_csv(out/'metrics.csv',index=False);pred.to_csv(out/'predictions.csv');pd.DataFrame(masses,columns=['arm','n','weight_mass','positive_weight_mass']).to_csv(out/'weight_audit.csv',index=False)
# Bootstrap all contrasts with shared stratified sample counts; AP accounts for tied scores.
t=ye.to_numpy();pos=np.flatnonzero(t);neg=np.flatnonzero(1-t)
orders={};flags={};arms=res.arm.tolist()
for arm in arms:
    score=pred[arm+'_raw'].to_numpy();o=np.argsort(-score,kind='stable');orders[arm]=(o,np.r_[np.flatnonzero(np.diff(score[o])),len(o)-1]);flags[arm]=pred[arm+'_q'].ge(.2).to_numpy()
def stats(count):
    ret={}
    for a in arms:
        o,ends=orders[a];tot=count[o].cumsum()[ends];tp=(count[o]*t[o]).cumsum()[ends]
        ap=np.sum(np.diff(np.r_[0,tp])*tp/np.maximum(tot,1))/tp[-1]; dec=flags[a]
        ret[a]=np.array([ap,5*(count*t*dec).sum()/(4*(count@t)+count@dec)])
    return ret
pairs=[('M1','M0'),('M2','M0'),('M3','M1'),('M3','M2'),('M4','M3'),('M4','M5')]
def delta(c):
    s=stats(c);return [s[a]-s[b] for a,b in pairs]
point=delta(np.ones(len(t),int));rng=np.random.default_rng(20261110);sim=[]
for _ in range(2000):
    c=np.bincount(np.r_[rng.choice(pos,len(pos)),rng.choice(neg,len(neg))],minlength=len(t));sim.append(delta(c))
lo,hi=np.quantile(sim,[.025,.975],axis=0)
ci=pd.DataFrame([[a,b,k,point[i][j],lo[i,j],hi[i,j]] for i,(a,b) in enumerate(pairs) for j,k in enumerate(['AP','F2'])],columns=['arm','ref','metric','delta','lo','hi']);ci.to_csv(out/'paired_ci.csv',index=False)
print(res.to_string(index=False));print(ci.to_string(index=False))
