"""Model factories for the controlled 2x2 experiment and external baselines.

No legacy model file is edited.  The focal gradient, Hessian, classifier
wrapper, and published estimator settings are read directly from their source
ASTs; if their structure changes, this module fails instead of guessing.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass

import lightgbm as lgb
import numpy as np
from imblearn.over_sampling import SMOTE
from scipy.special import expit
from sklearn.metrics import average_precision_score

from ablation_data import (
    BASELINE_SOURCE,
    FOCAL_SOURCE,
    PROJECT_DIR,
    load_unchanged_function,
)


SMOTE_SOURCE = PROJECT_DIR / "SMOTE + LightGBM.py"
ALPHA_SYMMETRIC = 0.50
ALPHA_ASYMMETRIC = 0.90  # selected in the existing Focal model log
GAMMA_SELECTED = 0.25   # selected in the existing Focal model log
GAMMA_GRID = (0.0, 0.25, 0.5, 0.75, 1.0, 2.0, 5.0)


@dataclass(frozen=True)
class Arm:
    key: str
    label: str
    alpha: float
    gamma: float


FACTORIAL_ARMS = (
    Arm("symmetric_gamma0", "Symmetric, gamma=0", ALPHA_SYMMETRIC, 0.0),
    Arm("asymmetric_gamma0", "Asymmetric, gamma=0", ALPHA_ASYMMETRIC, 0.0),
    Arm("symmetric_focal", "Focal only, symmetric", ALPHA_SYMMETRIC, GAMMA_SELECTED),
    Arm("asymmetric_focal", "Asymmetric + Focal", ALPHA_ASYMMETRIC, GAMMA_SELECTED),
)


def _model_call_kwargs(path, assignment_name: str, constructor_name: str) -> dict:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    found = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if not any(isinstance(t, ast.Name) and t.id == assignment_name for t in node.targets):
            continue
        call = node.value
        if not isinstance(call, ast.Call) or not isinstance(call.func, ast.Name):
            continue
        if call.func.id != constructor_name:
            continue
        found.append(call)
    if len(found) != 1:
        raise RuntimeError(
            f"Expected one {assignment_name}={constructor_name}(...) in {path}"
        )
    result = {}
    for keyword in found[0].keywords:
        if keyword.arg == "objective":
            continue  # injected from the unchanged focal objective below
        try:
            result[keyword.arg] = ast.literal_eval(keyword.value)
        except (ValueError, TypeError, SyntaxError):
            if keyword.arg == "n_estimators":
                continue  # final-refit code reads the tuned iteration count
            raise RuntimeError(f"Nonliteral setting {keyword.arg} in {path}")
    return result


def focal_source_components():
    tree = ast.parse(FOCAL_SOURCE.read_text(encoding="utf-8"), filename=str(FOCAL_SOURCE))
    names = {"focal_loss_custom", "focal_pr_auc_eval", "FocalLossLGBM"}
    selected = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names
    ]
    if {node.name for node in selected} != names:
        raise RuntimeError("The Focal source definitions have changed")
    module = ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[]))
    scope = {"np": np, "lgb": lgb, "expit": expit,
             "average_precision_score": average_precision_score}
    exec(compile(module, str(FOCAL_SOURCE), "exec"), scope)
    return scope


FOCAL = focal_source_components()
FOCAL_BASE_KWARGS = _model_call_kwargs(
    FOCAL_SOURCE, "candidate_model", "FocalLossLGBM"
)
SMOTE_BASE_KWARGS = _model_call_kwargs(
    SMOTE_SOURCE, "lgb_model", "LGBMClassifier"
)


def make_focal_model(alpha: float, gamma: float, n_estimators: int):
    kwargs = dict(FOCAL_BASE_KWARGS)
    kwargs["n_estimators"] = int(n_estimators)
    kwargs["objective"] = FOCAL["focal_loss_custom"](
        alpha=alpha, gamma=gamma, hessian_mode="bce_proxy"
    )
    return FOCAL["FocalLossLGBM"](**kwargs)


def focal_eval():
    return FOCAL["focal_pr_auc_eval"]


def make_legacy_baseline():
    factory = load_unchanged_function(
        BASELINE_SOURCE, "build_baseline_model", {"lgb": lgb}
    )
    return factory()


def make_smote_baseline():
    return lgb.LGBMClassifier(**SMOTE_BASE_KWARGS)


def make_smote_sampler():
    # The original SMOTE script uses exactly this sampler on its training set.
    return SMOTE(random_state=42)
