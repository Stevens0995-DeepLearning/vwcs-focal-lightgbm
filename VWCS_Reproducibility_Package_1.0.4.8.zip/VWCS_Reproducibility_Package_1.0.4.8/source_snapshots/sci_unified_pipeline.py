"""Leakage-safe unified experiment and SCI figure pipeline.

This module is the manuscript-facing entry point for the eight comparison
models and the LightGBM + focal-loss primary model.  It deliberately keeps
model fitting, calibration, threshold locking, test evaluation and plotting in
one reproducible pipeline so that all models use exactly the same samples.

Examples
--------
Run all nine models and build every figure::

    python sci_unified_pipeline.py --all --bootstrap 2000

Run one model from its legacy script adapter::

    python sci_unified_pipeline.py --model lr

Rebuild figures from already saved predictions::

    python sci_unified_pipeline.py --figures-only --bootstrap 2000

The default 0.20 threshold is pre-specified and locked.  To select the
threshold by validation-set F2 instead, use ``--threshold-policy validation-f2``.
The latter may select a value other than 0.20 and the figures will report the
actual selected value.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import sys
import time
import warnings
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_DATA_FILE = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Combine.csv"
)
DEFAULT_OUTPUT_DIR = PROJECT_DIR / "sci_outputs"
TARGET_COLUMN = "Target_Penalty"
PRIMARY_MODEL_KEY = "focal_lgbm"
VANILLA_MODEL_KEY = "vanilla_lgbm"
DEFAULT_LOCKED_THRESHOLD = 0.20
RANDOM_SEED = 42


MODEL_LABELS = {
    "lr": "Logistic Regression",
    "random_forest": "Random Forest",
    "smote_lgbm": "SMOTE + LightGBM",
    "easy_ensemble": "EasyEnsemble",
    "xgboost": "XGBoost",
    "lgbm_unbalance": "LightGBM calibrated",
    "catboost": "CatBoost",
    "vanilla_lgbm": "Vanilla LightGBM",
    "focal_lgbm": "LightGBM + Focal Loss",
}

MODEL_ORDER = list(MODEL_LABELS)
SUBGROUP_COLUMNS = ["State", "Ownership Type", "Provider Type"]


@dataclass
class SplitData:
    X_train: pd.DataFrame
    y_train: pd.Series
    X_tune: pd.DataFrame
    y_tune: pd.Series
    X_calibration: pd.DataFrame
    y_calibration: pd.Series
    X_threshold: pd.DataFrame
    y_threshold: pd.Series
    X_test: pd.DataFrame
    y_test: pd.Series
    manifest: pd.DataFrame


class PlattCalibrator:
    """Platt calibration fitted only on the independent calibration split."""

    def __init__(self, random_state: int = RANDOM_SEED):
        self.random_state = random_state
        self.model = None

    @staticmethod
    def _logit(probabilities: Iterable[float]) -> np.ndarray:
        p = np.clip(np.asarray(probabilities, dtype=float), 1e-6, 1 - 1e-6)
        return np.log(p / (1 - p)).reshape(-1, 1)

    def fit(self, probabilities: Iterable[float], y_true: Iterable[int]):
        from sklearn.linear_model import LogisticRegression

        self.model = LogisticRegression(
            C=1e6,
            solver="lbfgs",
            max_iter=2000,
            random_state=self.random_state,
        )
        self.model.fit(self._logit(probabilities), np.asarray(y_true))
        return self

    def predict(self, probabilities: Iterable[float]) -> np.ndarray:
        if self.model is None:
            raise RuntimeError("PlattCalibrator must be fitted before predict().")
        return self.model.predict_proba(self._logit(probabilities))[:, 1]


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def ensure_output_dirs(output_dir: Path) -> dict[str, Path]:
    paths = {
        "root": output_dir,
        "predictions": output_dir / "predictions",
        "metrics": output_dir / "metrics",
        "figures": output_dir / "figures",
        "models": output_dir / "models",
        "shap": output_dir / "shap",
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def load_source_data(data_file: Path) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame]:
    if not data_file.exists():
        raise FileNotFoundError(f"Data file not found: {data_file}")
    frame = pd.read_csv(data_file)
    if TARGET_COLUMN not in frame.columns:
        raise ValueError(f"Missing target column: {TARGET_COLUMN}")

    y = frame[TARGET_COLUMN].astype(int)
    if set(y.dropna().unique()) - {0, 1}:
        raise ValueError(f"{TARGET_COLUMN} must be binary (0/1).")

    X = frame.drop(columns=[TARGET_COLUMN]).copy()
    X.index = pd.Index(np.arange(len(X)), name="sample_id")
    y.index = X.index
    raw = X.copy()
    return X, y, raw


def create_or_load_split_manifest(
    y: pd.Series,
    data_file: Path,
    output_dir: Path,
    random_state: int = RANDOM_SEED,
    force_regenerate: bool = False,
) -> pd.DataFrame:
    """Create fixed 60/10/10/10/10 train/tune/calibration/threshold/test splits.

    The outer test set is never used for preprocessing, tuning, calibration or
    threshold selection.  The manifest is reused by every model.
    """

    from sklearn.model_selection import train_test_split

    manifest_path = output_dir / "split_manifest.csv"
    metadata_path = output_dir / "split_manifest_metadata.json"
    current_hash = file_sha256(data_file)

    if manifest_path.exists() and metadata_path.exists() and not force_regenerate:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        manifest = pd.read_csv(manifest_path)
        if metadata.get("data_sha256") != current_hash:
            raise RuntimeError(
                "Existing split manifest belongs to a different data file. "
                "Use --regenerate-split only after deciding to invalidate all "
                "previous predictions."
            )
        if len(manifest) != len(y):
            raise RuntimeError("Split manifest row count does not match data.")
        expected = y.loc[manifest["sample_id"].to_numpy()].to_numpy()
        if not np.array_equal(expected, manifest["y_true"].to_numpy()):
            raise RuntimeError("Split manifest labels do not match source data.")
        return manifest

    all_ids = y.index.to_numpy()
    train_ids, remainder_ids = train_test_split(
        all_ids,
        test_size=0.40,
        random_state=random_state,
        stratify=y.loc[all_ids],
    )
    tune_ids, holdout_ids = train_test_split(
        remainder_ids,
        test_size=0.75,
        random_state=random_state + 1,
        stratify=y.loc[remainder_ids],
    )
    calibration_ids, threshold_and_test_ids = train_test_split(
        holdout_ids,
        test_size=2 / 3,
        random_state=random_state + 2,
        stratify=y.loc[holdout_ids],
    )
    threshold_ids, test_ids = train_test_split(
        threshold_and_test_ids,
        test_size=0.50,
        random_state=random_state + 3,
        stratify=y.loc[threshold_and_test_ids],
    )

    split_map: dict[int, str] = {}
    for split_name, ids in (
        ("train", train_ids),
        ("tune", tune_ids),
        ("calibration", calibration_ids),
        ("threshold", threshold_ids),
        ("test", test_ids),
    ):
        split_map.update({int(sample_id): split_name for sample_id in ids})

    manifest = pd.DataFrame(
        {
            "sample_id": all_ids.astype(int),
            "split": [split_map[int(sample_id)] for sample_id in all_ids],
            "y_true": y.loc[all_ids].to_numpy(dtype=int),
        }
    ).sort_values("sample_id")
    manifest.to_csv(manifest_path, index=False, encoding="utf-8-sig")

    split_summary = (
        manifest.groupby("split")["y_true"]
        .agg(n="size", positives="sum", prevalence="mean")
        .reset_index()
        .to_dict(orient="records")
    )
    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "data_file": str(data_file),
        "data_sha256": current_hash,
        "random_state": random_state,
        "split_policy": "60% train, 10% tune, 10% calibration, "
        "10% threshold selection, 10% locked test",
        "split_summary": split_summary,
    }
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return manifest


def split_from_manifest(
    X: pd.DataFrame,
    y: pd.Series,
    manifest: pd.DataFrame,
) -> SplitData:
    ids = {
        split: manifest.loc[manifest["split"] == split, "sample_id"].to_numpy()
        for split in ("train", "tune", "calibration", "threshold", "test")
    }
    return SplitData(
        X_train=X.loc[ids["train"]].copy(),
        y_train=y.loc[ids["train"]].copy(),
        X_tune=X.loc[ids["tune"]].copy(),
        y_tune=y.loc[ids["tune"]].copy(),
        X_calibration=X.loc[ids["calibration"]].copy(),
        y_calibration=y.loc[ids["calibration"]].copy(),
        X_threshold=X.loc[ids["threshold"]].copy(),
        y_threshold=y.loc[ids["threshold"]].copy(),
        X_test=X.loc[ids["test"]].copy(),
        y_test=y.loc[ids["test"]].copy(),
        manifest=manifest,
    )


def make_preprocessor(X_train: pd.DataFrame):
    """Build a preprocessing transformer fitted on training data only."""

    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler

    numeric_columns = X_train.select_dtypes(include=[np.number]).columns.tolist()
    categorical_columns = [
        column for column in X_train.columns if column not in numeric_columns
    ]

    numeric_pipeline = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    try:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:  # scikit-learn < 1.2
        encoder = OneHotEncoder(handle_unknown="ignore", sparse=False)
    categorical_pipeline = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", encoder),
        ]
    )

    transformers = []
    if numeric_columns:
        transformers.append(("numeric", numeric_pipeline, numeric_columns))
    if categorical_columns:
        transformers.append(
            ("categorical", categorical_pipeline, categorical_columns)
        )
    preprocessor = ColumnTransformer(
        transformers=transformers,
        remainder="drop",
        verbose_feature_names_out=False,
    )
    return preprocessor


def transform_splits(split_data: SplitData):
    preprocessor = make_preprocessor(split_data.X_train)
    preprocessor.fit(split_data.X_train)
    feature_names = preprocessor.get_feature_names_out().astype(str)

    def transform(frame: pd.DataFrame) -> pd.DataFrame:
        values = preprocessor.transform(frame)
        if hasattr(values, "toarray"):
            values = values.toarray()
        return pd.DataFrame(
            values,
            index=frame.index,
            columns=feature_names,
            dtype=float,
        )

    transformed = {
        "train": transform(split_data.X_train),
        "tune": transform(split_data.X_tune),
        "calibration": transform(split_data.X_calibration),
        "threshold": transform(split_data.X_threshold),
        "test": transform(split_data.X_test),
    }
    return preprocessor, transformed


def focal_loss_custom(alpha: float = 0.85, gamma: float = 2.0):
    """Focal gradient with a BCE-proxy Hessian for stable tree splitting."""

    from scipy.special import expit

    def focal_loss_objective(y_true, y_pred):
        p = np.clip(expit(y_pred), 1e-6, 1 - 1e-6)
        grad_pos = -alpha * (1 - p) ** gamma * (
            1 - p - gamma * p * np.log(p)
        )
        grad_neg = (1 - alpha) * p**gamma * (
            p - gamma * (1 - p) * np.log(1 - p)
        )
        grad = np.where(np.asarray(y_true) == 1, grad_pos, grad_neg)
        hess = np.maximum(p * (1 - p), 1e-5)
        return grad, hess

    return focal_loss_objective


def make_focal_classifier(alpha: float, gamma: float, random_state: int):
    import lightgbm as lgb

    return lgb.LGBMClassifier(
        n_estimators=1500,
        learning_rate=0.02,
        num_leaves=15,
        max_depth=5,
        min_child_samples=30,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_lambda=1.0,
        random_state=random_state,
        n_jobs=-1,
        verbose=-1,
        objective=focal_loss_custom(alpha=alpha, gamma=gamma),
    )


def make_model(model_key: str, y_train: pd.Series, random_state: int):
    if model_key == "lr":
        from sklearn.linear_model import LogisticRegression

        return LogisticRegression(
            solver="lbfgs",
            max_iter=2000,
            random_state=random_state,
        )
    if model_key == "random_forest":
        from sklearn.ensemble import RandomForestClassifier

        return RandomForestClassifier(
            n_estimators=50,
            max_depth=3,
            max_features="log2",
            min_samples_leaf=50,
            random_state=random_state,
            n_jobs=-1,
        )
    if model_key == "easy_ensemble":
        from imblearn.ensemble import EasyEnsembleClassifier

        return EasyEnsembleClassifier(
            n_estimators=10,
            random_state=random_state,
            n_jobs=-1,
        )
    if model_key == "xgboost":
        import xgboost as xgb

        positive = int(np.sum(y_train == 1))
        negative = int(np.sum(y_train == 0))
        return xgb.XGBClassifier(
            n_estimators=100,
            max_depth=4,
            learning_rate=0.05,
            scale_pos_weight=negative / max(positive, 1),
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=random_state,
            eval_metric="logloss",
            n_jobs=-1,
        )
    if model_key == "lgbm_unbalance":
        from lightgbm import LGBMClassifier

        return LGBMClassifier(
            n_estimators=100,
            max_depth=4,
            learning_rate=0.05,
            is_unbalance=True,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=random_state,
            verbosity=-1,
            n_jobs=-1,
        )
    if model_key == "catboost":
        from catboost import CatBoostClassifier

        return CatBoostClassifier(
            iterations=100,
            depth=4,
            learning_rate=0.05,
            auto_class_weights="Balanced",
            loss_function="Logloss",
            random_seed=random_state,
            verbose=False,
            thread_count=-1,
        )
    if model_key in {"smote_lgbm", "vanilla_lgbm"}:
        from lightgbm import LGBMClassifier

        return LGBMClassifier(
            objective="binary",
            n_estimators=100,
            learning_rate=0.05,
            num_leaves=31,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=random_state,
            verbosity=-1,
            n_jobs=-1,
        )
    raise KeyError(f"Unknown model key: {model_key}")


def predict_raw_probability(model, X: pd.DataFrame) -> np.ndarray:
    from scipy.special import expit

    objective = None
    if hasattr(model, "get_params"):
        objective = model.get_params(deep=False).get("objective")
    if callable(objective) and hasattr(model, "booster_"):
        margins = model.booster_.predict(X, raw_score=True)
        return np.clip(expit(np.asarray(margins, dtype=float)), 1e-8, 1 - 1e-8)

    probabilities = np.asarray(model.predict_proba(X))
    if probabilities.ndim == 2 and probabilities.shape[1] >= 2:
        p = probabilities[:, 1]
    else:
        p = probabilities.reshape(-1)
    # Custom LightGBM objectives can expose raw margins through predict_proba.
    if np.nanmin(p) < 0 or np.nanmax(p) > 1:
        p = expit(p)
    return np.clip(p.astype(float), 1e-8, 1 - 1e-8)


def fit_model(
    model_key: str,
    transformed: dict[str, pd.DataFrame],
    split_data: SplitData,
    random_state: int,
    tuning_dir: Path,
):
    from sklearn.metrics import average_precision_score

    if model_key == PRIMARY_MODEL_KEY:
        import lightgbm as lgb

        rows = []
        best_model = None
        best_score = -np.inf
        best_alpha = None
        best_gamma = None
        for alpha in (0.65, 0.75, 0.85, 0.90):
            for gamma in (0.5, 1.0, 1.5, 2.0):
                model = make_focal_classifier(alpha, gamma, random_state)
                model.fit(
                    transformed["train"],
                    split_data.y_train,
                    eval_set=[(transformed["tune"], split_data.y_tune)],
                    eval_metric="average_precision",
                    callbacks=[
                        lgb.early_stopping(
                            stopping_rounds=100,
                            first_metric_only=True,
                            verbose=False,
                        )
                    ],
                )
                tune_probability = predict_raw_probability(
                    model, transformed["tune"]
                )
                score = average_precision_score(
                    split_data.y_tune, tune_probability
                )
                rows.append(
                    {
                        "alpha": alpha,
                        "gamma": gamma,
                        "tuning_PR_AUC": score,
                        "best_iteration": getattr(
                            model, "best_iteration_", np.nan
                        ),
                    }
                )
                if score > best_score:
                    best_score = score
                    best_model = model
                    best_alpha = alpha
                    best_gamma = gamma
        pd.DataFrame(rows).to_csv(
            tuning_dir / "focal_alpha_gamma_tuning.csv",
            index=False,
            encoding="utf-8-sig",
        )
        metadata = {
            "alpha": best_alpha,
            "gamma": best_gamma,
            "tuning_PR_AUC": best_score,
            "best_iteration": getattr(best_model, "best_iteration_", None),
            "objective_description": (
                "focal-loss gradient with BCE-proxy Hessian"
            ),
        }
        return best_model, metadata

    model = make_model(model_key, split_data.y_train, random_state)
    if model_key == "smote_lgbm":
        from imblearn.over_sampling import SMOTE

        sampler = SMOTE(random_state=random_state)
        X_fit, y_fit = sampler.fit_resample(
            transformed["train"], split_data.y_train
        )
        model.fit(X_fit, y_fit)
        return model, {
            "resampling": "SMOTE fitted on transformed training split only",
            "n_train_after_resampling": int(len(y_fit)),
        }

    model.fit(transformed["train"], split_data.y_train)
    return model, {}


def threshold_metrics(
    y_true: Iterable[int],
    probabilities: Iterable[float],
    thresholds: Iterable[float],
) -> pd.DataFrame:
    from sklearn.metrics import (
        accuracy_score,
        balanced_accuracy_score,
        confusion_matrix,
        fbeta_score,
        matthews_corrcoef,
        precision_score,
        recall_score,
    )

    y = np.asarray(y_true, dtype=int)
    p = np.asarray(probabilities, dtype=float)
    rows: list[dict[str, Any]] = []
    for threshold in sorted(set(float(value) for value in thresholds)):
        prediction = (p >= threshold).astype(int)
        tn, fp, fn, tp = confusion_matrix(
            y, prediction, labels=[0, 1]
        ).ravel()
        recall = recall_score(y, prediction, zero_division=0)
        precision = precision_score(y, prediction, zero_division=0)
        specificity = tn / (tn + fp) if tn + fp else np.nan
        npv = tn / (tn + fn) if tn + fn else np.nan
        fpr = fp / (fp + tn) if fp + tn else np.nan
        rows.append(
            {
                "threshold": threshold,
                "TP": int(tp),
                "FP": int(fp),
                "TN": int(tn),
                "FN": int(fn),
                "recall": recall,
                "precision": precision,
                "specificity": specificity,
                "NPV": npv,
                "FPR": fpr,
                "F2": fbeta_score(
                    y, prediction, beta=2, zero_division=0
                ),
                "accuracy": accuracy_score(y, prediction),
                "balanced_accuracy": balanced_accuracy_score(y, prediction),
                "MCC": matthews_corrcoef(y, prediction),
                "flagged_per_1000": 1000 * (tp + fp) / len(y),
                "false_alarms_per_1000": 1000 * fp / len(y),
                "missed_positives_per_1000": 1000 * fn / len(y),
                "net_benefit": (
                    tp / len(y)
                    - fp / len(y) * threshold / max(1 - threshold, 1e-12)
                ),
            }
        )
    return pd.DataFrame(rows)


def select_threshold_by_f2(
    y_true: Iterable[int],
    probabilities: Iterable[float],
    candidates: Iterable[float],
) -> tuple[float, pd.DataFrame]:
    table = threshold_metrics(y_true, probabilities, candidates)
    best_f2 = table["F2"].max()
    tied = table.loc[np.isclose(table["F2"], best_f2, atol=1e-12)]
    selected = float(tied["threshold"].min())
    return selected, table


def calibration_statistics(
    y_true: Iterable[int], probabilities: Iterable[float]
) -> tuple[float, float]:
    from sklearn.linear_model import LogisticRegression

    y = np.asarray(y_true, dtype=int)
    p = np.clip(np.asarray(probabilities, dtype=float), 1e-6, 1 - 1e-6)
    logits = np.log(p / (1 - p)).reshape(-1, 1)
    model = LogisticRegression(
        C=1e6,
        solver="lbfgs",
        max_iter=2000,
        random_state=RANDOM_SEED,
    )
    model.fit(logits, y)
    return float(model.intercept_[0]), float(model.coef_[0, 0])


def global_metrics(
    y_true: Iterable[int],
    raw_probability: Iterable[float],
    calibrated_probability: Iterable[float],
    locked_threshold: float,
) -> dict[str, float]:
    from sklearn.metrics import (
        average_precision_score,
        brier_score_loss,
        roc_auc_score,
    )

    y = np.asarray(y_true, dtype=int)
    raw = np.asarray(raw_probability, dtype=float)
    calibrated = np.asarray(calibrated_probability, dtype=float)
    intercept, slope = calibration_statistics(y, calibrated)
    locked = threshold_metrics(y, calibrated, [locked_threshold]).iloc[0]
    return {
        "PR_AUC": average_precision_score(y, raw),
        "ROC_AUC": roc_auc_score(y, raw),
        "Brier": brier_score_loss(y, calibrated),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        **{
            key: float(locked[key])
            for key in (
                "recall",
                "precision",
                "specificity",
                "NPV",
                "FPR",
                "F2",
                "accuracy",
                "balanced_accuracy",
                "MCC",
                "flagged_per_1000",
                "false_alarms_per_1000",
                "missed_positives_per_1000",
                "net_benefit",
            )
        },
        **{key: int(locked[key]) for key in ("TP", "FP", "TN", "FN")},
    }


def save_prediction_frame(
    model_key: str,
    split_name: str,
    X_raw: pd.DataFrame,
    y_true: pd.Series,
    raw_probability: np.ndarray,
    calibrated_probability: np.ndarray,
    locked_threshold: float,
    output_path: Path,
) -> pd.DataFrame:
    frame = pd.DataFrame(
        {
            "sample_id": y_true.index.astype(int),
            "split": split_name,
            "model_key": model_key,
            "model": MODEL_LABELS[model_key],
            "y_true": y_true.to_numpy(dtype=int),
            "y_prob_raw": np.asarray(raw_probability, dtype=float),
            "y_prob_calibrated": np.asarray(
                calibrated_probability, dtype=float
            ),
            "locked_threshold": float(locked_threshold),
        }
    )
    frame["y_pred"] = (
        frame["y_prob_calibrated"] >= frame["locked_threshold"]
    ).astype(int)
    for column in SUBGROUP_COLUMNS:
        if column in X_raw.columns:
            frame[f"subgroup__{column}"] = (
                X_raw.loc[y_true.index, column]
                .astype("string")
                .fillna("<Missing>")
                .to_numpy()
            )
    frame.to_csv(output_path, index=False, encoding="utf-8-sig")
    return frame


def save_curve_tables(
    model_key: str,
    prediction_frame: pd.DataFrame,
    metrics_dir: Path,
) -> None:
    from sklearn.calibration import calibration_curve
    from sklearn.metrics import precision_recall_curve, roc_curve

    y = prediction_frame["y_true"].to_numpy()
    raw = prediction_frame["y_prob_raw"].to_numpy()
    calibrated = prediction_frame["y_prob_calibrated"].to_numpy()

    precision, recall, pr_threshold = precision_recall_curve(y, raw)
    pd.DataFrame(
        {
            "model_key": model_key,
            "recall": recall,
            "precision": precision,
            "threshold": np.append(pr_threshold, np.nan),
        }
    ).to_csv(
        metrics_dir / f"pr_curve_{model_key}.csv",
        index=False,
        encoding="utf-8-sig",
    )

    fpr, tpr, roc_threshold = roc_curve(y, raw)
    pd.DataFrame(
        {
            "model_key": model_key,
            "FPR": fpr,
            "TPR": tpr,
            "threshold": roc_threshold,
        }
    ).to_csv(
        metrics_dir / f"roc_curve_{model_key}.csv",
        index=False,
        encoding="utf-8-sig",
    )

    observed, predicted = calibration_curve(
        y, calibrated, n_bins=8, strategy="quantile"
    )
    bins = pd.qcut(
        calibrated,
        q=min(8, len(np.unique(calibrated))),
        labels=False,
        duplicates="drop",
    )
    counts = pd.Series(bins).value_counts().sort_index().to_numpy()
    length = min(len(observed), len(predicted), len(counts))
    pd.DataFrame(
        {
            "model_key": model_key,
            "bin_id": np.arange(length),
            "n_samples": counts[:length],
            "mean_predicted_probability": predicted[:length],
            "observed_positive_rate": observed[:length],
        }
    ).to_csv(
        metrics_dir / f"calibration_bins_{model_key}.csv",
        index=False,
        encoding="utf-8-sig",
    )


def save_shap_outputs(
    model: Any,
    X_test: pd.DataFrame,
    output_dirs: dict[str, Path],
    n_bootstrap: int = 500,
) -> None:
    """Save primary-model SHAP summary, dependence and stability outputs."""

    try:
        import matplotlib.pyplot as plt
        import shap
    except ImportError as error:
        warnings.warn(f"SHAP output skipped: {error}")
        return

    explain_model = getattr(model, "booster_", model)
    explainer = shap.TreeExplainer(explain_model)
    values = explainer.shap_values(X_test)
    if isinstance(values, list):
        values = values[1]
    values = np.asarray(values)
    if values.ndim == 3:
        values = values[:, :, 1]
    if values.shape[0] != len(X_test):
        raise RuntimeError("Unexpected SHAP value shape.")

    np.savez_compressed(
        output_dirs["shap"] / "shap_values_primary.npz",
        shap_values=values,
        X=X_test.to_numpy(),
        feature_names=X_test.columns.to_numpy(dtype=str),
        sample_id=X_test.index.to_numpy(dtype=int),
    )
    importance = pd.DataFrame(
        {
            "feature": X_test.columns,
            "mean_abs_shap": np.abs(values).mean(axis=0),
        }
    ).sort_values("mean_abs_shap", ascending=False)
    importance.to_csv(
        output_dirs["shap"] / "shap_feature_importance_primary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    plt.figure(figsize=(11, 7))
    shap.summary_plot(values, X_test, show=False, max_display=20)
    plt.title("Figure 6a. SHAP summary — primary model")
    save_figure(plt.gcf(), output_dirs["figures"] / "Figure6a_SHAP_summary")
    plt.close()

    top_features = importance["feature"].head(3).tolist()
    for position, feature in enumerate(top_features, start=1):
        plt.figure(figsize=(7, 5))
        shap.dependence_plot(feature, values, X_test, show=False)
        plt.title(f"Figure 6{chr(97 + position)}. SHAP dependence: {feature}")
        save_figure(
            plt.gcf(),
            output_dirs["figures"]
            / f"Figure6{chr(97 + position)}_SHAP_dependence_{position}",
        )
        plt.close()

    rng = np.random.default_rng(RANDOM_SEED)
    stability_rows = []
    for bootstrap_id in range(n_bootstrap):
        index = rng.integers(0, len(X_test), size=len(X_test))
        boot_importance = np.abs(values[index]).mean(axis=0)
        order = np.argsort(-boot_importance)
        rank = np.empty(len(order), dtype=int)
        rank[order] = np.arange(1, len(order) + 1)
        for feature_index, feature in enumerate(X_test.columns):
            stability_rows.append(
                {
                    "bootstrap_id": bootstrap_id,
                    "feature": feature,
                    "mean_abs_shap": boot_importance[feature_index],
                    "rank": int(rank[feature_index]),
                    "in_top_10": int(rank[feature_index] <= 10),
                }
            )
    stability = pd.DataFrame(stability_rows)
    stability.to_csv(
        output_dirs["shap"] / "shap_stability_bootstrap.csv",
        index=False,
        encoding="utf-8-sig",
    )
    summary = (
        stability.groupby("feature")
        .agg(
            mean_rank=("rank", "mean"),
            rank_sd=("rank", "std"),
            top10_frequency=("in_top_10", "mean"),
            mean_abs_shap=("mean_abs_shap", "mean"),
        )
        .sort_values("mean_rank")
        .reset_index()
    )
    summary.to_csv(
        output_dirs["shap"] / "shap_stability_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )


def run_single_model(
    model_key: str,
    data_file: Path | str = DEFAULT_DATA_FILE,
    output_dir: Path | str = DEFAULT_OUTPUT_DIR,
    locked_threshold: float = DEFAULT_LOCKED_THRESHOLD,
    threshold_policy: str = "prespecified",
    regenerate_split: bool = False,
    random_state: int = RANDOM_SEED,
) -> dict[str, Any]:
    """Run one model using the shared leakage-safe split and output contract."""

    if model_key not in MODEL_LABELS:
        raise KeyError(f"Unknown model key: {model_key}")
    data_file = Path(data_file)
    output_dir = Path(output_dir)
    dirs = ensure_output_dirs(output_dir)
    X, y, raw_X = load_source_data(data_file)
    manifest = create_or_load_split_manifest(
        y,
        data_file,
        output_dir,
        random_state=random_state,
        force_regenerate=regenerate_split,
    )
    split_data = split_from_manifest(X, y, manifest)
    preprocessor, transformed = transform_splits(split_data)

    started = time.perf_counter()
    model, model_metadata = fit_model(
        model_key,
        transformed,
        split_data,
        random_state,
        dirs["metrics"],
    )
    training_seconds = time.perf_counter() - started

    raw_probabilities = {
        split: predict_raw_probability(model, transformed[split])
        for split in ("calibration", "threshold", "test")
    }
    calibrator = PlattCalibrator(random_state=random_state).fit(
        raw_probabilities["calibration"],
        split_data.y_calibration,
    )
    calibrated_probabilities = {
        split: calibrator.predict(raw_probabilities[split])
        for split in raw_probabilities
    }

    dense_thresholds = np.unique(
        np.concatenate(
            [np.linspace(0.01, 0.99, 99), np.asarray([locked_threshold])]
        )
    )
    validation_best, validation_table = select_threshold_by_f2(
        split_data.y_threshold,
        calibrated_probabilities["threshold"],
        dense_thresholds,
    )
    if threshold_policy == "validation-f2":
        selected_threshold = validation_best
    elif threshold_policy == "prespecified":
        selected_threshold = float(locked_threshold)
    else:
        raise ValueError(
            "threshold_policy must be 'prespecified' or 'validation-f2'."
        )

    validation_table.insert(0, "model_key", model_key)
    validation_table["selected"] = np.isclose(
        validation_table["threshold"], selected_threshold
    )
    validation_table["threshold_policy"] = threshold_policy
    validation_table.to_csv(
        dirs["metrics"] / f"threshold_metrics_validation_{model_key}.csv",
        index=False,
        encoding="utf-8-sig",
    )

    split_lookup = {
        "calibration": (split_data.X_calibration, split_data.y_calibration),
        "threshold": (split_data.X_threshold, split_data.y_threshold),
        "test": (split_data.X_test, split_data.y_test),
    }
    prediction_frames = {}
    for split_name, (X_split_raw, y_split) in split_lookup.items():
        prediction_frames[split_name] = save_prediction_frame(
            model_key,
            split_name,
            X_split_raw,
            y_split,
            raw_probabilities[split_name],
            calibrated_probabilities[split_name],
            selected_threshold,
            dirs["predictions"] / f"{model_key}_{split_name}.csv",
        )

    test_thresholds = np.unique(
        np.concatenate([np.linspace(0.01, 0.99, 99), [selected_threshold]])
    )
    test_table = threshold_metrics(
        split_data.y_test,
        calibrated_probabilities["test"],
        test_thresholds,
    )
    test_table.insert(0, "model_key", model_key)
    test_table["locked_threshold"] = selected_threshold
    test_table.to_csv(
        dirs["metrics"] / f"threshold_metrics_test_{model_key}.csv",
        index=False,
        encoding="utf-8-sig",
    )
    save_curve_tables(
        model_key, prediction_frames["test"], dirs["metrics"]
    )

    metrics = global_metrics(
        split_data.y_test,
        raw_probabilities["test"],
        calibrated_probabilities["test"],
        selected_threshold,
    )
    metrics.update(
        {
            "model_key": model_key,
            "model": MODEL_LABELS[model_key],
            "locked_threshold": selected_threshold,
            "validation_best_F2_threshold": validation_best,
            "threshold_policy": threshold_policy,
            "training_seconds": training_seconds,
        }
    )
    pd.DataFrame([metrics]).to_csv(
        dirs["metrics"] / f"global_metrics_{model_key}.csv",
        index=False,
        encoding="utf-8-sig",
    )

    run_metadata = {
        **metrics,
        **model_metadata,
        "data_file": str(data_file),
        "data_sha256": file_sha256(data_file),
        "python": sys.version,
        "platform": platform.platform(),
        "random_state": random_state,
        "preprocessing": (
            "ColumnTransformer fitted on training split only: median imputation "
            "+ standardization for numeric features; most-frequent imputation "
            "+ one-hot encoding for categorical features."
        ),
        "calibration": "Platt/sigmoid fitted on calibration split only",
        "test_policy": "locked test evaluated once after threshold locking",
        "created_utc": datetime.now(timezone.utc).isoformat(),
    }
    (dirs["models"] / f"{model_key}_run_metadata.json").write_text(
        json.dumps(run_metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    if model_key == PRIMARY_MODEL_KEY:
        save_shap_outputs(model, transformed["test"], dirs)

    print(
        f"[SCI] {MODEL_LABELS[model_key]} complete: "
        f"PR-AUC={metrics['PR_AUC']:.4f}, "
        f"Brier={metrics['Brier']:.4f}, "
        f"F2={metrics['F2']:.4f}, "
        f"locked threshold={selected_threshold:.2f}"
    )
    return run_metadata


def load_all_test_predictions(output_dir: Path) -> pd.DataFrame:
    prediction_dir = output_dir / "predictions"
    missing = [
        model_key
        for model_key in MODEL_ORDER
        if not (prediction_dir / f"{model_key}_test.csv").exists()
    ]
    if missing:
        raise FileNotFoundError(
            "Missing model predictions: "
            + ", ".join(missing)
            + ". Run --all or run each legacy script with --sci."
        )
    frames = [
        pd.read_csv(prediction_dir / f"{model_key}_test.csv")
        for model_key in MODEL_ORDER
    ]
    combined = pd.concat(frames, ignore_index=True)
    counts = combined.groupby("model_key")["sample_id"].nunique()
    if counts.nunique() != 1:
        raise RuntimeError("Models do not contain the same number of test IDs.")
    truth = combined.pivot(
        index="sample_id", columns="model_key", values="y_true"
    )
    if not truth.nunique(axis=1).eq(1).all():
        raise RuntimeError("y_true differs across model prediction files.")
    return combined


def paired_stratified_bootstrap(
    combined: pd.DataFrame,
    n_bootstrap: int,
    random_state: int = RANDOM_SEED,
) -> pd.DataFrame:
    from sklearn.metrics import (
        average_precision_score,
        brier_score_loss,
        fbeta_score,
    )

    pivot_raw = combined.pivot(
        index="sample_id", columns="model_key", values="y_prob_raw"
    )[MODEL_ORDER]
    pivot_cal = combined.pivot(
        index="sample_id", columns="model_key", values="y_prob_calibrated"
    )[MODEL_ORDER]
    truth = (
        combined.drop_duplicates("sample_id")
        .set_index("sample_id")
        .loc[pivot_raw.index, "y_true"]
        .astype(int)
    )
    thresholds = (
        combined.groupby("model_key")["locked_threshold"]
        .first()
        .reindex(MODEL_ORDER)
    )
    positive_index = np.flatnonzero(truth.to_numpy() == 1)
    negative_index = np.flatnonzero(truth.to_numpy() == 0)
    rng = np.random.default_rng(random_state)

    rows = []
    for bootstrap_id in range(n_bootstrap):
        sampled = np.concatenate(
            [
                rng.choice(
                    positive_index, size=len(positive_index), replace=True
                ),
                rng.choice(
                    negative_index, size=len(negative_index), replace=True
                ),
            ]
        )
        rng.shuffle(sampled)
        y_boot = truth.to_numpy()[sampled]
        for model_key in MODEL_ORDER:
            raw_boot = pivot_raw[model_key].to_numpy()[sampled]
            cal_boot = pivot_cal[model_key].to_numpy()[sampled]
            pred_boot = (cal_boot >= thresholds[model_key]).astype(int)
            rows.extend(
                [
                    {
                        "bootstrap_id": bootstrap_id,
                        "model_key": model_key,
                        "metric": "PR_AUC",
                        "value": average_precision_score(y_boot, raw_boot),
                    },
                    {
                        "bootstrap_id": bootstrap_id,
                        "model_key": model_key,
                        "metric": "Brier",
                        "value": brier_score_loss(y_boot, cal_boot),
                    },
                    {
                        "bootstrap_id": bootstrap_id,
                        "model_key": model_key,
                        "metric": "F2",
                        "value": fbeta_score(
                            y_boot, pred_boot, beta=2, zero_division=0
                        ),
                    },
                ]
            )
    return pd.DataFrame(rows)


def summarize_bootstrap(
    bootstrap: pd.DataFrame, point_metrics: pd.DataFrame
) -> pd.DataFrame:
    point_long = point_metrics.melt(
        id_vars=["model_key"],
        value_vars=["PR_AUC", "Brier", "F2"],
        var_name="metric",
        value_name="estimate",
    )
    interval = (
        bootstrap.groupby(["model_key", "metric"])["value"]
        .quantile([0.025, 0.975])
        .unstack()
        .rename(columns={0.025: "ci_lower", 0.975: "ci_upper"})
        .reset_index()
    )
    summary = point_long.merge(interval, on=["model_key", "metric"])

    primary = bootstrap.loc[
        bootstrap["model_key"] == PRIMARY_MODEL_KEY,
        ["bootstrap_id", "metric", "value"],
    ].rename(columns={"value": "primary_value"})
    differences = bootstrap.merge(primary, on=["bootstrap_id", "metric"])
    differences["difference_vs_primary"] = (
        differences["value"] - differences["primary_value"]
    )
    difference_summary = (
        differences.groupby(["model_key", "metric"])[
            "difference_vs_primary"
        ]
        .agg(
            difference_mean="mean",
            difference_ci_lower=lambda value: value.quantile(0.025),
            difference_ci_upper=lambda value: value.quantile(0.975),
        )
        .reset_index()
    )
    return summary.merge(difference_summary, on=["model_key", "metric"])


def save_figure(fig, base_path: Path) -> None:
    fig.savefig(
        base_path.with_suffix(".png"),
        dpi=600,
        bbox_inches="tight",
        facecolor="white",
    )
    fig.savefig(
        base_path.with_suffix(".svg"),
        bbox_inches="tight",
        facecolor="white",
    )
    fig.savefig(
        base_path.with_suffix(".pdf"),
        bbox_inches="tight",
        facecolor="white",
    )


def set_publication_style() -> None:
    import matplotlib as mpl

    mpl.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.titlesize": 11,
            "axes.labelsize": 10,
            "legend.fontsize": 8,
            "figure.dpi": 150,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "grid.alpha": 0.20,
        }
    )


def plot_figure_1(output_dir: Path) -> None:
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch

    labels = [
        "Raw data\n+ sample IDs",
        "Outer split\n(fixed manifest)",
        "Train-only\npreprocessing /\nresampling",
        "Tuning split\n(hyperparameters)",
        "Calibration split\n(Platt mapping)",
        "Threshold split\n(lock operating point)",
        "Locked test\n(one evaluation)",
    ]
    colors = [
        "#E8F1FA",
        "#DCEAF7",
        "#D7EFE2",
        "#FFF0CC",
        "#FCE3C7",
        "#F8D8D8",
        "#E5DDF3",
    ]
    fig, ax = plt.subplots(figsize=(15, 3.2))
    ax.axis("off")
    x_positions = np.linspace(0.02, 0.86, len(labels))
    width = 0.12
    for index, (x, label, color) in enumerate(
        zip(x_positions, labels, colors)
    ):
        box = FancyBboxPatch(
            (x, 0.35),
            width,
            0.34,
            boxstyle="round,pad=0.015,rounding_size=0.02",
            facecolor=color,
            edgecolor="#334155",
            linewidth=1.2,
            transform=ax.transAxes,
        )
        ax.add_patch(box)
        ax.text(
            x + width / 2,
            0.52,
            label,
            ha="center",
            va="center",
            transform=ax.transAxes,
            fontsize=9,
        )
        if index < len(labels) - 1:
            ax.annotate(
                "",
                xy=(x_positions[index + 1] - 0.005, 0.52),
                xytext=(x + width + 0.005, 0.52),
                xycoords=ax.transAxes,
                arrowprops=dict(arrowstyle="->", lw=1.4, color="#334155"),
            )
    ax.text(
        0.5,
        0.14,
        "Test data never informs preprocessing, tuning, calibration, "
        "or threshold selection.",
        ha="center",
        transform=ax.transAxes,
        color="#9B1C1C",
        fontsize=10,
        weight="bold",
    )
    ax.set_title(
        "Figure 1. Leakage-safe model-development and evaluation workflow",
        weight="bold",
    )
    save_figure(fig, output_dir / "Figure1_leakage_safe_workflow")
    plt.close(fig)


def metric_point_table(combined: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for model_key, frame in combined.groupby("model_key", sort=False):
        metrics = global_metrics(
            frame["y_true"],
            frame["y_prob_raw"],
            frame["y_prob_calibrated"],
            float(frame["locked_threshold"].iloc[0]),
        )
        rows.append(
            {
                "model_key": model_key,
                "model": MODEL_LABELS[model_key],
                "locked_threshold": float(
                    frame["locked_threshold"].iloc[0]
                ),
                **metrics,
            }
        )
    return pd.DataFrame(rows).set_index("model_key").loc[MODEL_ORDER].reset_index()


def strongest_non_primary(point_metrics: pd.DataFrame) -> str:
    candidates = point_metrics.loc[
        ~point_metrics["model_key"].isin(
            [PRIMARY_MODEL_KEY, VANILLA_MODEL_KEY, "lgbm_unbalance"]
        )
    ]
    return str(candidates.sort_values("PR_AUC").iloc[-1]["model_key"])


def plot_figure_2(
    combined: pd.DataFrame, point_metrics: pd.DataFrame, output_dir: Path
) -> None:
    import matplotlib.pyplot as plt
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes
    from sklearn.metrics import precision_recall_curve, roc_curve

    strongest = strongest_non_primary(point_metrics)
    highlighted = {PRIMARY_MODEL_KEY, VANILLA_MODEL_KEY, strongest}
    colors = {
        PRIMARY_MODEL_KEY: "#C62828",
        VANILLA_MODEL_KEY: "#1565C0",
        strongest: "#2E7D32",
    }
    fig, ax = plt.subplots(figsize=(8.5, 6.5))
    inset = inset_axes(ax, width="42%", height="42%", loc="lower left", borderpad=3)
    for model_key in MODEL_ORDER:
        frame = combined.loc[combined["model_key"] == model_key]
        precision, recall, _ = precision_recall_curve(
            frame["y_true"], frame["y_prob_raw"]
        )
        fpr, tpr, _ = roc_curve(frame["y_true"], frame["y_prob_raw"])
        point = point_metrics.loc[
            point_metrics["model_key"] == model_key
        ].iloc[0]
        is_highlighted = model_key in highlighted
        color = colors.get(model_key, "#B8BDC5")
        ax.plot(
            recall,
            precision,
            color=color,
            lw=2.4 if is_highlighted else 1.0,
            alpha=1.0 if is_highlighted else 0.55,
            label=(
                f"{MODEL_LABELS[model_key]} (AP={point['PR_AUC']:.3f})"
                if is_highlighted
                else None
            ),
        )
        inset.plot(
            fpr,
            tpr,
            color=color,
            lw=1.8 if is_highlighted else 0.8,
            alpha=1.0 if is_highlighted else 0.45,
        )
    prevalence = combined.drop_duplicates("sample_id")["y_true"].mean()
    ax.axhline(
        prevalence,
        color="black",
        ls=":",
        lw=1,
        label=f"Prevalence={prevalence:.3f}",
    )
    ax.set(
        xlabel="Recall",
        ylabel="Precision",
        xlim=(0, 1.01),
        ylim=(0, 1.01),
        title="Figure 2. Precision–recall curves (ROC inset)",
    )
    ax.legend(loc="lower left", bbox_to_anchor=(0.48, 0.02), frameon=False)
    inset.plot([0, 1], [0, 1], color="black", ls=":", lw=0.8)
    inset.set(xlabel="FPR", ylabel="TPR", xlim=(0, 1), ylim=(0, 1))
    inset.set_title("ROC", fontsize=9)
    save_figure(fig, output_dir / "Figure2_PR_curves_ROC_inset")
    plt.close(fig)


def plot_figure_3(
    combined: pd.DataFrame, point_metrics: pd.DataFrame, output_dir: Path
) -> None:
    import matplotlib.pyplot as plt
    from sklearn.calibration import calibration_curve

    strongest = strongest_non_primary(point_metrics)
    selected = list(
        dict.fromkeys(
            [
                PRIMARY_MODEL_KEY,
                VANILLA_MODEL_KEY,
                "lgbm_unbalance",
                strongest,
            ]
        )
    )
    colors = ["#C62828", "#1565C0", "#8E24AA", "#2E7D32"]
    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    ax.plot([0, 1], [0, 1], color="black", ls="--", label="Perfect calibration")
    for model_key, color in zip(selected, colors):
        frame = combined.loc[combined["model_key"] == model_key]
        observed, predicted = calibration_curve(
            frame["y_true"],
            frame["y_prob_calibrated"],
            n_bins=8,
            strategy="quantile",
        )
        point = point_metrics.loc[
            point_metrics["model_key"] == model_key
        ].iloc[0]
        label = (
            f"{MODEL_LABELS[model_key]} | Brier={point['Brier']:.3f}, "
            f"intercept={point['calibration_intercept']:.2f}, "
            f"slope={point['calibration_slope']:.2f}"
        )
        ax.plot(
            predicted,
            observed,
            marker="o",
            lw=2,
            color=color,
            label=label,
        )
    ax.set(
        xlabel="Mean predicted probability",
        ylabel="Observed event rate",
        xlim=(-0.02, 1.02),
        ylim=(-0.02, 1.02),
        title="Figure 3. Probability calibration",
    )
    ax.legend(frameon=False, fontsize=7.5, loc="upper left")
    save_figure(fig, output_dir / "Figure3_calibration_curves")
    plt.close(fig)


def plot_figure_4(output_dir: Path) -> None:
    import matplotlib.pyplot as plt

    table_path = (
        output_dir.parent
        / "metrics"
        / f"threshold_metrics_validation_{PRIMARY_MODEL_KEY}.csv"
    )
    table = pd.read_csv(table_path)
    selected = float(table.loc[table["selected"], "threshold"].iloc[0])
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    styles = {
        "recall": ("#1565C0", "Recall"),
        "precision": ("#2E7D32", "Precision"),
        "F2": ("#C62828", "F2"),
        "FPR": ("#6A1B9A", "FPR"),
    }
    for column, (color, label) in styles.items():
        ax.plot(table["threshold"], table[column], color=color, lw=2, label=label)
    policy = table["threshold_policy"].iloc[0]
    descriptor = (
        "pre-specified and locked"
        if policy == "prespecified"
        else "selected by validation F2"
    )
    ax.axvline(
        selected,
        color="black",
        ls="--",
        lw=1.5,
        label=f"Threshold={selected:.2f} ({descriptor})",
    )
    ax.set(
        xlabel="Probability threshold",
        ylabel="Metric value",
        xlim=(0, 1),
        ylim=(-0.02, 1.02),
        title="Figure 4. Validation threshold–performance profile",
    )
    ax.legend(frameon=False, ncol=2)
    save_figure(fig, output_dir / "Figure4_threshold_performance")
    plt.close(fig)


def plot_figure_5(bootstrap_summary: pd.DataFrame, output_dir: Path) -> None:
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(15, 6.5), sharey=True)
    y_positions = np.arange(len(MODEL_ORDER))
    for ax, metric in zip(axes, ("PR_AUC", "Brier", "F2")):
        data = (
            bootstrap_summary.loc[bootstrap_summary["metric"] == metric]
            .set_index("model_key")
            .loc[MODEL_ORDER]
        )
        colors = [
            "#C62828" if key == PRIMARY_MODEL_KEY else "#607D8B"
            for key in MODEL_ORDER
        ]
        for position, key, row, color in zip(
            y_positions, MODEL_ORDER, data.itertuples(), colors
        ):
            ax.errorbar(
                row.estimate,
                position,
                xerr=[
                    [row.estimate - row.ci_lower],
                    [row.ci_upper - row.estimate],
                ],
                fmt="o",
                color=color,
                ecolor=color,
                elinewidth=1.6,
                capsize=3,
                markersize=5,
            )
        ax.set_title(
            f"{metric}" + (" (lower is better)" if metric == "Brier" else "")
        )
        ax.set_xlabel("Estimate (95% CI)")
        ax.set_yticks(y_positions)
        ax.set_yticklabels([MODEL_LABELS[key] for key in MODEL_ORDER])
        ax.invert_yaxis()
    fig.suptitle(
        "Figure 5. Model performance with paired stratified-bootstrap 95% CIs",
        weight="bold",
    )
    fig.tight_layout()
    save_figure(fig, output_dir / "Figure5_performance_forest_plot")
    plt.close(fig)


def plot_figure_7(combined: pd.DataFrame, output_dir: Path) -> None:
    import matplotlib.pyplot as plt

    thresholds = np.linspace(0.02, 0.80, 79)
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))
    for model_key in MODEL_ORDER:
        frame = combined.loc[combined["model_key"] == model_key]
        table = threshold_metrics(
            frame["y_true"], frame["y_prob_calibrated"], thresholds
        )
        color = "#C62828" if model_key == PRIMARY_MODEL_KEY else "#B8BDC5"
        axes[0].plot(
            table["threshold"],
            table["net_benefit"],
            color=color,
            lw=2.5 if model_key == PRIMARY_MODEL_KEY else 0.8,
            alpha=1 if model_key == PRIMARY_MODEL_KEY else 0.5,
            label=MODEL_LABELS[model_key]
            if model_key == PRIMARY_MODEL_KEY
            else None,
        )
    unique_test = combined.drop_duplicates("sample_id")
    prevalence = unique_test["y_true"].mean()
    treat_all = prevalence - (1 - prevalence) * thresholds / (1 - thresholds)
    axes[0].plot(thresholds, treat_all, color="black", ls="--", label="Alert all")
    axes[0].axhline(0, color="black", ls=":", label="Alert none")
    axes[0].set(
        xlabel="Threshold probability",
        ylabel="Net benefit",
        title="(a) Regulatory decision curve",
    )
    axes[0].legend(frameon=False)

    primary = combined.loc[combined["model_key"] == PRIMARY_MODEL_KEY]
    table = threshold_metrics(
        primary["y_true"], primary["y_prob_calibrated"], thresholds
    )
    axes[1].plot(
        table["threshold"],
        table["flagged_per_1000"],
        label="Alerts / 1,000",
        color="#1565C0",
    )
    axes[1].plot(
        table["threshold"],
        table["false_alarms_per_1000"],
        label="False alerts / 1,000",
        color="#F57C00",
    )
    axes[1].plot(
        table["threshold"],
        table["missed_positives_per_1000"],
        label="Missed positives / 1,000",
        color="#C62828",
    )
    locked = float(primary["locked_threshold"].iloc[0])
    axes[1].axvline(locked, color="black", ls="--", label=f"Locked={locked:.2f}")
    axes[1].set(
        xlabel="Threshold probability",
        ylabel="Institutions per 1,000",
        title="(b) Workload–missed-event trade-off",
    )
    axes[1].legend(frameon=False)
    fig.suptitle("Figure 7. Decision utility and operational workload", weight="bold")
    fig.tight_layout()
    save_figure(fig, output_dir / "Figure7_decision_and_workload")
    plt.close(fig)


def plot_supplementary_roc(
    combined: pd.DataFrame, point_metrics: pd.DataFrame, output_dir: Path
) -> None:
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve

    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    palette = plt.cm.tab10(np.linspace(0, 1, len(MODEL_ORDER)))
    for color, model_key in zip(palette, MODEL_ORDER):
        frame = combined.loc[combined["model_key"] == model_key]
        fpr, tpr, _ = roc_curve(frame["y_true"], frame["y_prob_raw"])
        auc = point_metrics.loc[
            point_metrics["model_key"] == model_key, "ROC_AUC"
        ].iloc[0]
        ax.plot(
            fpr,
            tpr,
            color=color,
            lw=1.5,
            label=f"{MODEL_LABELS[model_key]} ({auc:.3f})",
        )
    ax.plot([0, 1], [0, 1], color="black", ls=":")
    ax.set(
        xlabel="False-positive rate",
        ylabel="True-positive rate",
        xlim=(0, 1),
        ylim=(0, 1),
        title="Supplementary Figure S1. ROC curves for all models",
    )
    ax.legend(frameon=False, fontsize=7)
    save_figure(fig, output_dir / "Supplementary_S1_all_ROC")
    plt.close(fig)


def plot_supplementary_confusion(
    combined: pd.DataFrame, output_dir: Path
) -> None:
    import matplotlib.pyplot as plt
    from sklearn.metrics import confusion_matrix

    fig, axes = plt.subplots(3, 3, figsize=(11, 10))
    for ax, model_key in zip(axes.flat, MODEL_ORDER):
        frame = combined.loc[combined["model_key"] == model_key]
        matrix = confusion_matrix(
            frame["y_true"], frame["y_pred"], labels=[0, 1]
        )
        image = ax.imshow(matrix, cmap="Blues")
        for row in range(2):
            for column in range(2):
                ax.text(
                    column,
                    row,
                    f"{matrix[row, column]:,}",
                    ha="center",
                    va="center",
                    color="white"
                    if matrix[row, column] > matrix.max() / 2
                    else "black",
                )
        threshold = float(frame["locked_threshold"].iloc[0])
        ax.set_title(f"{MODEL_LABELS[model_key]}\nt={threshold:.2f}", fontsize=9)
        ax.set_xticks([0, 1], ["Pred 0", "Pred 1"], fontsize=7)
        ax.set_yticks([0, 1], ["Actual 0", "Actual 1"], fontsize=7)
    fig.colorbar(image, ax=axes.ravel().tolist(), shrink=0.6)
    fig.suptitle("Supplementary Figure S2. Locked-threshold confusion matrices")
    fig.subplots_adjust(top=0.90, wspace=0.35, hspace=0.45)
    save_figure(fig, output_dir / "Supplementary_S2_confusion_matrices")
    plt.close(fig)


def plot_supplementary_threshold_heatmap(
    combined: pd.DataFrame, output_dir: Path
) -> None:
    import matplotlib.pyplot as plt

    thresholds = np.arange(0.1, 0.71, 0.1)
    metrics = ("recall", "precision", "FPR", "F2")
    fig, axes = plt.subplots(1, 4, figsize=(17, 6), sharey=True)
    for ax, metric in zip(axes, metrics):
        matrix = []
        for model_key in MODEL_ORDER:
            frame = combined.loc[combined["model_key"] == model_key]
            table = threshold_metrics(
                frame["y_true"], frame["y_prob_calibrated"], thresholds
            )
            matrix.append(table[metric].to_numpy())
        matrix_array = np.asarray(matrix)
        image = ax.imshow(matrix_array, aspect="auto", cmap="viridis")
        for row in range(matrix_array.shape[0]):
            for column in range(matrix_array.shape[1]):
                ax.text(
                    column,
                    row,
                    f"{matrix_array[row, column]:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6,
                    color="white"
                    if matrix_array[row, column] < 0.35
                    else "black",
                )
        ax.set_title(metric)
        ax.set_xticks(
            np.arange(len(thresholds)),
            [f"{value:.1f}" for value in thresholds],
        )
        ax.set_xlabel("Threshold")
        ax.set_yticks(
            np.arange(len(MODEL_ORDER)),
            [MODEL_LABELS[key] for key in MODEL_ORDER],
            fontsize=7,
        )
        fig.colorbar(image, ax=ax, shrink=0.65)
    fig.suptitle("Supplementary Figure S3. Threshold metric heatmaps")
    fig.tight_layout()
    save_figure(fig, output_dir / "Supplementary_S3_threshold_heatmaps")
    plt.close(fig)


def plot_supplementary_bootstrap(
    bootstrap: pd.DataFrame, output_dir: Path
) -> None:
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(16, 6))
    for ax, metric in zip(axes, ("PR_AUC", "Brier", "F2")):
        data = [
            bootstrap.loc[
                (bootstrap["model_key"] == model_key)
                & (bootstrap["metric"] == metric),
                "value",
            ].to_numpy()
            for model_key in MODEL_ORDER
        ]
        ax.boxplot(
            data,
            showfliers=False,
            tick_labels=[str(i + 1) for i in range(9)],
        )
        ax.set_title(metric)
        ax.set_xlabel("Model number")
        ax.set_ylabel("Bootstrap estimate")
    legend_text = "  ".join(
        f"{index + 1}: {MODEL_LABELS[key]}"
        for index, key in enumerate(MODEL_ORDER)
    )
    fig.text(0.5, 0.01, legend_text, ha="center", fontsize=7, wrap=True)
    fig.suptitle("Supplementary Figure S4. Paired bootstrap distributions")
    fig.tight_layout(rect=(0, 0.06, 1, 0.95))
    save_figure(fig, output_dir / "Supplementary_S4_bootstrap_distributions")
    plt.close(fig)


def subgroup_performance(
    combined: pd.DataFrame,
    subgroup_column: str,
    n_bootstrap: int = 500,
) -> pd.DataFrame:
    from sklearn.metrics import fbeta_score, precision_score, recall_score

    primary = combined.loc[combined["model_key"] == PRIMARY_MODEL_KEY].copy()
    if subgroup_column not in primary.columns:
        return pd.DataFrame()
    rng = np.random.default_rng(RANDOM_SEED)
    rows = []
    for group_name, frame in primary.groupby(subgroup_column):
        if len(frame) < 50 or frame["y_true"].sum() < 5:
            continue
        y = frame["y_true"].to_numpy(dtype=int)
        pred = frame["y_pred"].to_numpy(dtype=int)
        bootstrap_values = {"recall": [], "precision": [], "F2": []}
        for _ in range(n_bootstrap):
            index = rng.integers(0, len(frame), size=len(frame))
            y_boot = y[index]
            pred_boot = pred[index]
            if len(np.unique(y_boot)) < 2:
                continue
            bootstrap_values["recall"].append(
                recall_score(y_boot, pred_boot, zero_division=0)
            )
            bootstrap_values["precision"].append(
                precision_score(y_boot, pred_boot, zero_division=0)
            )
            bootstrap_values["F2"].append(
                fbeta_score(y_boot, pred_boot, beta=2, zero_division=0)
            )
        point = {
            "recall": recall_score(y, pred, zero_division=0),
            "precision": precision_score(y, pred, zero_division=0),
            "F2": fbeta_score(y, pred, beta=2, zero_division=0),
        }
        for metric, estimate in point.items():
            values = np.asarray(bootstrap_values[metric])
            rows.append(
                {
                    "subgroup_variable": subgroup_column.replace(
                        "subgroup__", ""
                    ),
                    "subgroup_value": group_name,
                    "n": len(frame),
                    "n_positive": int(y.sum()),
                    "prevalence": y.mean(),
                    "metric": metric,
                    "estimate": estimate,
                    "ci_lower": np.quantile(values, 0.025)
                    if len(values)
                    else np.nan,
                    "ci_upper": np.quantile(values, 0.975)
                    if len(values)
                    else np.nan,
                }
            )
    return pd.DataFrame(rows)


def plot_supplementary_subgroups(
    combined: pd.DataFrame, output_dirs: dict[str, Path]
) -> None:
    import matplotlib.pyplot as plt

    available = [
        f"subgroup__{column}"
        for column in SUBGROUP_COLUMNS
        if f"subgroup__{column}" in combined.columns
    ]
    if not available:
        warnings.warn("No subgroup columns available; subgroup figure skipped.")
        return
    all_tables = []
    for column in available:
        table = subgroup_performance(combined, column)
        if not table.empty:
            all_tables.append(table)
    if not all_tables:
        warnings.warn(
            "No subgroup met minimum n>=50 and positive count>=5; skipped."
        )
        return
    subgroup_table = pd.concat(all_tables, ignore_index=True)
    subgroup_table.to_csv(
        output_dirs["metrics"] / "subgroup_metrics_primary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    chosen_variable = (
        "Ownership Type"
        if "Ownership Type"
        in subgroup_table["subgroup_variable"].unique()
        else subgroup_table["subgroup_variable"].iloc[0]
    )
    plot_data = subgroup_table.loc[
        (subgroup_table["subgroup_variable"] == chosen_variable)
        & (subgroup_table["metric"] == "F2")
    ].sort_values("estimate")
    if plot_data.empty:
        return
    fig, ax = plt.subplots(figsize=(8, max(4, 0.45 * len(plot_data))))
    y_position = np.arange(len(plot_data))
    ax.errorbar(
        plot_data["estimate"],
        y_position,
        xerr=np.vstack(
            [
                plot_data["estimate"] - plot_data["ci_lower"],
                plot_data["ci_upper"] - plot_data["estimate"],
            ]
        ),
        fmt="o",
        color="#C62828",
        capsize=3,
    )
    ax.set_yticks(
        y_position,
        [
            f"{name} (n={n}, pos={positive})"
            for name, n, positive in zip(
                plot_data["subgroup_value"],
                plot_data["n"],
                plot_data["n_positive"],
            )
        ],
    )
    ax.set(
        xlabel="F2 (95% bootstrap CI)",
        title=(
            "Supplementary Figure S5. Primary-model subgroup performance: "
            f"{chosen_variable}"
        ),
    )
    save_figure(
        fig, output_dirs["figures"] / "Supplementary_S5_subgroup_forest"
    )
    plt.close(fig)


def plot_supplementary_shap_stability(output_dirs: dict[str, Path]) -> None:
    import matplotlib.pyplot as plt

    path = output_dirs["shap"] / "shap_stability_summary.csv"
    if not path.exists():
        warnings.warn("SHAP stability data missing; figure skipped.")
        return
    data = pd.read_csv(path).head(20).sort_values("mean_rank", ascending=False)
    fig, ax = plt.subplots(figsize=(8, 7))
    y = np.arange(len(data))
    ax.barh(y, data["top10_frequency"], color="#546E7A")
    ax.set_yticks(y, data["feature"])
    ax.set(
        xlabel="Frequency in top 10 across test-sample bootstraps",
        xlim=(0, 1),
        title=(
            "Supplementary Figure S6. SHAP attribution stability\n"
            "(sampling stability; not model-refit stability)"
        ),
    )
    save_figure(
        fig, output_dirs["figures"] / "Supplementary_S6_SHAP_stability"
    )
    plt.close(fig)


def build_all_figures(
    output_dir: Path | str = DEFAULT_OUTPUT_DIR,
    n_bootstrap: int = 2000,
) -> dict[str, Path]:
    output_dir = Path(output_dir)
    dirs = ensure_output_dirs(output_dir)
    set_publication_style()
    combined = load_all_test_predictions(output_dir)
    combined.to_csv(
        dirs["predictions"] / "all_models_test_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )
    point_metrics = metric_point_table(combined)
    point_metrics.to_csv(
        dirs["metrics"] / "all_models_point_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    bootstrap_path = dirs["metrics"] / "paired_bootstrap_metrics.csv"
    if bootstrap_path.exists():
        bootstrap = pd.read_csv(bootstrap_path)
        existing_replicates = bootstrap["bootstrap_id"].nunique()
    else:
        existing_replicates = 0
        bootstrap = pd.DataFrame()
    if existing_replicates != n_bootstrap:
        bootstrap = paired_stratified_bootstrap(
            combined, n_bootstrap=n_bootstrap
        )
        bootstrap.to_csv(
            bootstrap_path, index=False, encoding="utf-8-sig"
        )
    bootstrap_summary = summarize_bootstrap(bootstrap, point_metrics)
    bootstrap_summary.to_csv(
        dirs["metrics"] / "paired_bootstrap_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    plot_figure_1(dirs["figures"])
    plot_figure_2(combined, point_metrics, dirs["figures"])
    plot_figure_3(combined, point_metrics, dirs["figures"])
    plot_figure_4(dirs["figures"])
    plot_figure_5(bootstrap_summary, dirs["figures"])
    plot_figure_7(combined, dirs["figures"])
    plot_supplementary_roc(combined, point_metrics, dirs["figures"])
    plot_supplementary_confusion(combined, dirs["figures"])
    plot_supplementary_threshold_heatmap(combined, dirs["figures"])
    plot_supplementary_bootstrap(bootstrap, dirs["figures"])
    plot_supplementary_subgroups(combined, dirs)
    plot_supplementary_shap_stability(dirs)

    manifest = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "bootstrap_replicates": n_bootstrap,
        "figures": sorted(
            str(path.relative_to(output_dir))
            for path in dirs["figures"].glob("*")
            if path.is_file()
        ),
        "notes": [
            "Figure 6 files are generated while fitting the primary model.",
            "SHAP explains the uncalibrated tree score; Platt calibration is "
            "a downstream probability mapping.",
            "Subgroup plots suppress groups with n<50 or fewer than 5 positives.",
        ],
    }
    (output_dir / "figure_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return dirs


def write_run_readme(output_dir: Path, threshold_policy: str) -> None:
    text = f"""# SCI unified experiment outputs

Generated by `sci_unified_pipeline.py`.

## Method contract

- A single persisted sample split is reused across all nine models.
- Preprocessing is fitted on the training split only.
- SMOTE is applied only to the transformed training split.
- Hyperparameter tuning, probability calibration, threshold handling and final
  test evaluation use separate data partitions.
- Threshold policy: `{threshold_policy}`.
- The default locked threshold is 0.20. When `validation-f2` is requested, the
  actual validation-selected threshold is used and may differ from 0.20.
- Test predictions are saved per sample so all model comparisons and bootstrap
  intervals are paired.

## Main output folders

- `predictions/`: per-sample raw and calibrated probabilities.
- `metrics/`: curve points, threshold tables, bootstrap and subgroup results.
- `figures/`: PNG (600 dpi), SVG and PDF.
- `shap/`: primary-model SHAP arrays, importance and stability tables.
- `models/`: run metadata and exact selected settings.

Do not select a threshold from the test-set threshold heatmap. It is a
descriptive sensitivity analysis only.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run leakage-safe nine-model SCI experiments and figures."
    )
    mode = parser.add_mutually_exclusive_group(required=False)
    mode.add_argument("--all", action="store_true", help="Run all nine models.")
    mode.add_argument("--model", choices=MODEL_ORDER, help="Run one model.")
    mode.add_argument(
        "--figures-only",
        action="store_true",
        help="Build figures from saved predictions.",
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=DEFAULT_DATA_FILE,
        help="Source CSV containing Target_Penalty.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="SCI output directory.",
    )
    parser.add_argument(
        "--locked-threshold",
        type=float,
        default=DEFAULT_LOCKED_THRESHOLD,
    )
    parser.add_argument(
        "--threshold-policy",
        choices=["prespecified", "validation-f2"],
        default="prespecified",
    )
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--regenerate-split", action="store_true")
    args = parser.parse_args()
    if not args.all and args.model is None and not args.figures_only:
        args.all = True
        print(
            "[SCI] No run mode supplied; defaulting to --all "
            "(all nine models and all figures)."
        )
    return args


def main() -> None:
    args = parse_args()
    ensure_output_dirs(args.output)
    write_run_readme(args.output, args.threshold_policy)
    if args.figures_only:
        build_all_figures(args.output, n_bootstrap=args.bootstrap)
        print(f"SCI figures written to: {args.output / 'figures'}")
        return

    keys = MODEL_ORDER if args.all else [args.model]
    for position, model_key in enumerate(keys):
        run_single_model(
            model_key=model_key,
            data_file=args.data,
            output_dir=args.output,
            locked_threshold=args.locked_threshold,
            threshold_policy=args.threshold_policy,
            regenerate_split=args.regenerate_split and position == 0,
        )
    if args.all:
        build_all_figures(args.output, n_bootstrap=args.bootstrap)
        print(f"SCI figures written to: {args.output / 'figures'}")
    else:
        print(
            "Single model finished. Run all remaining models, then execute "
            "`python sci_unified_pipeline.py --figures-only`."
        )


if __name__ == "__main__":
    main()
