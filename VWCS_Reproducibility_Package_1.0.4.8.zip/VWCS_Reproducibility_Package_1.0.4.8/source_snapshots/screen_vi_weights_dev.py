"""Development-only screen: train-fold exploration, original tune as a secondary check.
Run with LHLenv; no test or calibration predictions or metrics are requested.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.metrics import average_precision_score
from sklearn.model_selection import StratifiedKFold
from ablation_models import FOCAL,FOCAL_BASE_KWARGS

base=Path(__file__).resolve().parent/'logs'
source=base/'Revision2_Vi_20261110'
out=base/'Revision2_Vi_dev_screen'
out.mkdir(exist_ok=False)
protocol=json.loads((source/'protocol.json').read_text(encoding='utf8'))
dev=pd.concat([c.loc[c.split.isin(['train','tune'])] for c in pd.read_csv(source/'revision2_dataset.csv',chunksize=1000)],ignore_index=True)
X=dev[protocol['features']].copy()
for c in X:
    if pd.api.types.is_numeric_dtype(X[c]):X[c]=X[c].astype('float32')
    else:X[c]=X[c].astype('category')
y=dev.y_true.to_numpy(); train=np.flatnonzero(dev.split=='train');tune=np.flatnonzero(dev.split=='tune')
assert len(train)==10290 and len(tune)==1470
arms={'uniform':('linear',0.),'linear025':('linear',.25),'linear100':('linear',1.),'upper025':('upper',.25),'upper100':('upper',1.)}
legacy=FOCAL['focal_loss_custom'](.9,.25,'bce_proxy')
rows=[]
def evaluate(tr,va,fold,arm):
    v=0.
    for c in ['staff_hours','adl_decline_pct','cycle1_deficiencies']:
        col=dev[c];pool=np.sort(col.iloc[tr].dropna());z=col.fillna(np.median(pool));r=(pool.searchsorted(z,'left')+pool.searchsorted(z,'right'))/(2*len(pool))
        v=v+(1-r if c=='staff_hours' else r)/3
    cut=np.quantile(v[tr],.75); pos=y[tr]==1; shape,beta=arms[arm]
    profile=v if shape=='linear' else np.maximum(v-cut,0)/(1-cut)
    m=1+beta*profile[tr];w=np.where(pos,.9*m/m[pos].mean(),.1)
    assert np.isclose(w[pos].sum(),.9*pos.sum())
    def objective(labels,raw):
        assert np.array_equal(labels,y[tr])
        g=legacy(labels,raw)[0]*w/np.where(labels==1,.9,.1)
        p=np.clip(expit(raw),1e-6,1-1e-6)
        return g,np.maximum(w*p*(1-p),1e-5)
    model=FOCAL['FocalLossLGBM'](**{**FOCAL_BASE_KWARGS,'objective':objective,'n_estimators':300,'n_jobs':2})
    model.fit(X.iloc[tr],y[tr]);score=model.booster_.predict(X.iloc[va],raw_score=True,num_threads=2)
    order=np.lexsort((dev.sample_id.to_numpy()[va],-score));hi=(v[va]>=cut)&(y[va]==1)
    rec=dict(fold=fold,arm=arm,n=len(va),positive=int(y[va].sum()),high_pos=int(hi.sum()),ap=average_precision_score(y[va],score))
    for pct in (3,5,10):
        k=int(np.ceil(len(va)*pct/100)); alert=order[:k];rec[f'k{pct}']=k;rec[f'hi_tp{pct}']=int(hi[alert].sum());rec[f'tp{pct}']=int(y[va][alert].sum())
    rows.append(rec)
for i,(tr,va) in enumerate(StratifiedKFold(3,shuffle=True,random_state=42).split(train,y[train])):
    for arm in arms:evaluate(train[tr],train[va],str(i+1),arm)
def totals(rr):
    tab=pd.DataFrame(rr);s=tab.groupby('arm').agg(ap=('ap','mean'),high_pos=('high_pos','sum'),hi_tp3=('hi_tp3','sum'),hi_tp5=('hi_tp5','sum'),hi_tp10=('hi_tp10','sum'),tp5=('tp5','sum'))
    return s
cv=totals(rows); cv.to_csv(out/'cv.csv')
# Primary endpoint: high-risk positives detected at a 5% budget. Permit at most
# 0.002 mean AP loss; retain uniform if no strict improvement in detected count.
eligible=cv[(cv.hi_tp5>cv.loc['uniform','hi_tp5'])&(cv.ap>=cv.loc['uniform','ap']-.002)]
chosen='uniform' if eligible.empty else eligible.sort_values(['hi_tp5','ap'],ascending=False).index[0]
print('CV\n',cv,'\nChosen:',chosen,flush=True)
for arm in ['uniform']+([chosen] if chosen!='uniform' else []):evaluate(train,tune,'tune',arm)
details=pd.DataFrame(rows);details.to_csv(out/'details.csv',index=False);print(details[details.fold=='tune'].to_string(index=False),flush=True)
(out/'selection.json').write_text(json.dumps({'chosen':chosen,'primary_budget':.05,'AP_tolerance':.002,'rounds':300,'fold_seed':42,'test_used':False},indent=2))
