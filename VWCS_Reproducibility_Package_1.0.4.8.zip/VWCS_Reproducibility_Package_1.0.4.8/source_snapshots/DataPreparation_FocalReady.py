"""Build real-data and explicitly synthetic LightGBM + Focal benchmarks.

The ``full-real`` mode is label-free.  ``three-feature-upper-bound`` uses
cross-fitted supervised scores.  ``synthetic-focal-benchmark`` intentionally
uses label-conditional simulation and is restricted to method stress testing;
it must never be represented as an observational prediction dataset.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import lightgbm as lgb
from pandas.errors import PerformanceWarning
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold, train_test_split

import DataPreparation as base


RANDOM_STATE = 42
TARGET_THRESHOLD = 170734.80
DEFAULT_INPUT = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据\backup"
    r"\NH_ProviderInfo_Combine(2026.7.21真实宽表).csv"
)
DEFAULT_OUTPUT = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Focal_Ready.csv"
)
DEFAULT_WIDE_INPUT = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Combine.csv"
)
DEFAULT_THREE_FEATURE_OUTPUT = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Focal_ThreeFeature_UpperBound.csv"
)
DEFAULT_SYNTHETIC_OUTPUT = DEFAULT_THREE_FEATURE_OUTPUT.with_name(
    "NH_ProviderInfo_Focal_Synthetic_Benchmark.csv"
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_ratio(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    numerator = pd.to_numeric(numerator, errors="coerce")
    denominator = pd.to_numeric(denominator, errors="coerce").replace(0, np.nan)
    return (numerator / denominator).replace([np.inf, -np.inf], np.nan)


def add_focal_ready_features(
    result: pd.DataFrame,
    source: pd.DataFrame,
) -> tuple[pd.DataFrame, list[str], list[str]]:
    """Add label-free interactions, reporting flags and missingness flags."""

    result = result.copy()
    derived: list[str] = []
    footnote_flags: list[str] = []

    ratio_definitions = {
        "Bed_Occupancy_Rate": (
            "Average Number of Residents per Day",
            "Number of Certified Beds",
            0.0,
            2.0,
        ),
        "RN_Share_of_Total_Staffing": (
            "Reported RN Staffing Hours per Resident per Day",
            "Reported Total Nurse Staffing Hours per Resident per Day",
            0.0,
            1.0,
        ),
        "Adjusted_to_Reported_Staffing_Ratio": (
            "Adjusted Total Nurse Staffing Hours per Resident per Day",
            "Reported Total Nurse Staffing Hours per Resident per Day",
            0.0,
            3.0,
        ),
        "Reported_to_CaseMix_Staffing_Ratio": (
            "Reported Total Nurse Staffing Hours per Resident per Day",
            "Case-Mix Total Nurse Staffing Hours per Resident per Day",
            0.0,
            3.0,
        ),
    }
    for output, (numerator, denominator, lower, upper) in ratio_definitions.items():
        if numerator in result.columns and denominator in result.columns:
            result[output] = safe_ratio(
                result[numerator], result[denominator]
            ).clip(lower, upper)
            derived.append(output)

    if {
        "Reported Total Nurse Staffing Hours per Resident per Day",
        "Total number of nurse staff hours per resident per day on the weekend",
    }.issubset(result.columns):
        output = "Weekend_Staffing_Gap"
        result[output] = pd.to_numeric(
            result["Reported Total Nurse Staffing Hours per Resident per Day"],
            errors="coerce",
        ) - pd.to_numeric(
            result[
                "Total number of nurse staff hours per resident per day on the weekend"
            ],
            errors="coerce",
        )
        derived.append(output)

    trend_definitions = {
        "Health_Deficiency_Count_Trend_Cycle1_minus_Cycle23": (
            "Rating Cycle 1 Total Number of Health Deficiencies",
            "Rating Cycle 2/3 Total Number of Health Deficiencies",
        ),
        "Health_Deficiency_Score_Trend_Cycle1_minus_Cycle23": (
            "Rating Cycle 1 Health Deficiency Score",
            "Rating Cycle 2/3 Health Deficiency Score",
        ),
        "Total_Health_Score_Trend_Cycle1_minus_Cycle23": (
            "Rating Cycle 1 Total Health Score",
            "Rating Cycle 2/3 Total Health Score",
        ),
    }
    for output, (recent, earlier) in trend_definitions.items():
        if recent in result.columns and earlier in result.columns:
            result[output] = pd.to_numeric(
                result[recent], errors="coerce"
            ) - pd.to_numeric(result[earlier], errors="coerce")
            derived.append(output)

    survey_columns = {
        "Days_Since_Rating_Cycle_1_Health_Survey",
        "Days_Since_Rating_Cycle_2_Health_Survey",
    }
    if survey_columns.issubset(result.columns):
        output = "Survey_Cycle_Gap_Days"
        result[output] = (
            pd.to_numeric(
                result["Days_Since_Rating_Cycle_2_Health_Survey"],
                errors="coerce",
            )
            - pd.to_numeric(
                result["Days_Since_Rating_Cycle_1_Health_Survey"],
                errors="coerce",
            )
        ).abs()
        derived.append(output)

    claims = [column for column in base.CLAIMS_COLUMNS if column in result.columns]
    if claims:
        claims_numeric = result[claims].apply(pd.to_numeric, errors="coerce")
        claims_scaled = claims_numeric.copy()
        for column in claims:
            if "Percentage" in column:
                claims_scaled[column] = claims_scaled[column].clip(0, 100) / 100
            else:
                claims_scaled[column] = np.log1p(
                    claims_scaled[column].clip(lower=0)
                )
        output = "Claims_Utilization_Composite"
        result[output] = claims_scaled.mean(axis=1, skipna=True)
        derived.append(output)

    if "Number of Facilities in Chain" in result.columns:
        chain_size = pd.to_numeric(
            result["Number of Facilities in Chain"], errors="coerce"
        )
        result["Is_Chain_Provider"] = chain_size.notna().astype("int8")
        result["Log_Chain_Size"] = np.log1p(chain_size.clip(lower=0))
        derived.extend(["Is_Chain_Provider", "Log_Chain_Size"])

    if set(base.COMPOSITE_COLUMNS).issubset(result.columns):
        clinical = result["Latent_Clinical_Risk"] / 100.0
        regulatory = result["Regulatory_Antagonism_Index"] / 100.0
        administrative = result["Masked_Admin_Redundancy"] / 100.0
        result["Clinical_x_Regulatory_Risk"] = clinical * regulatory
        result["Administrative_x_Regulatory_Risk"] = (
            administrative * regulatory
        )
        derived.extend(
            [
                "Clinical_x_Regulatory_Risk",
                "Administrative_x_Regulatory_Risk",
            ]
        )

    base_feature_columns = [
        column for column in result.columns if column != "Target_Penalty"
    ]
    result["Feature_Completeness_Rate"] = result[
        base_feature_columns
    ].notna().mean(axis=1)
    derived.append("Feature_Completeness_Rate")

    for column in base_feature_columns:
        missing_rate = float(result[column].isna().mean())
        if 0.15 <= missing_rate < 1.0:
            output = f"Missing__{column}"
            result[output] = result[column].isna().astype("int8")
            derived.append(output)

    excluded_footnotes = {
        "Average Number of Residents per Day Footnote",
        "Geocoding Footnote",
    }
    for column in source.columns:
        if "footnote" not in column.lower() or column in excluded_footnotes:
            continue
        flag = source[column].notna().astype("int8")
        if flag.nunique() <= 1:
            continue
        output = f"Footnote_Present__{column.removesuffix(' Footnote').removesuffix(' footnote')}"
        result[output] = flag
        footnote_flags.append(output)

    return result, derived, footnote_flags


def build_split_manifest(
    source: pd.DataFrame,
    target: pd.Series,
) -> pd.DataFrame:
    """Reproduce the exact split sequence used by the Focal model script.

    The names map as follows: development=train, threshold=tune,
    calibration=cal, and test=test.  Keeping both scripts on the same row
    indices is mandatory because the three domain scores are supervised
    stacked features.
    """

    indices = np.arange(len(target))
    remaining, test = train_test_split(
        indices,
        test_size=0.10,
        random_state=RANDOM_STATE,
        stratify=target,
    )
    development, tune_calibration = train_test_split(
        remaining,
        test_size=0.2222,
        random_state=RANDOM_STATE,
        stratify=target.iloc[remaining],
    )
    threshold, calibration = train_test_split(
        tune_calibration,
        test_size=0.5,
        random_state=RANDOM_STATE + 1,
        stratify=target.iloc[tune_calibration],
    )
    split = np.full(len(target), "", dtype=object)
    split[development] = "development"
    split[calibration] = "calibration"
    split[threshold] = "threshold"
    split[test] = "test"

    ccn = source["CMS Certification Number (CCN)"].astype(str)
    ccn_hash = ccn.map(
        lambda value: hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]
    )
    return pd.DataFrame(
        {
            "sample_id": indices,
            "ccn_hash": ccn_hash,
            "split": split,
            "y_true": target.to_numpy(),
        }
    )


def build_feature_manifest(
    columns: list[str],
    derived: list[str],
    footnote_flags: list[str],
) -> pd.DataFrame:
    base_manifest = base._build_feature_manifest(
        [
            column
            for column in columns
            if column not in set(derived) | set(footnote_flags)
        ]
    )
    base_lookup = base_manifest.set_index("column").to_dict("index")
    rows = []
    for column in columns:
        if column == "Target_Penalty":
            group, role = "Outcome", "target"
        elif column in footnote_flags:
            group, role = "Reporting/footnote pattern", "footnote_indicator"
        elif column.startswith("Missing__"):
            group, role = "Missingness pattern", "missingness_indicator"
        elif column in derived:
            group, role = "Focal-ready business derivation", "derived_feature"
        elif column in base_lookup:
            group = base_lookup[column]["feature_group"]
            role = base_lookup[column]["role"]
        else:
            group, role = "Real wide-table feature", "raw_real_feature"
        rows.append(
            {
                "column": column,
                "feature_group": group,
                "role": role,
                "uses_target_to_construct": column == "Target_Penalty",
                "included_in_model": column != "Target_Penalty",
            }
        )
    return pd.DataFrame(rows)


def build_focal_ready_dataset(
    input_path: str | Path = DEFAULT_INPUT,
    output_path: str | Path = DEFAULT_OUTPUT,
) -> pd.DataFrame:
    input_path = Path(input_path)
    output_path = Path(output_path)
    if not input_path.exists():
        raise FileNotFoundError(input_path)

    print("--- Building leakage-audited Focal-ready real-wide-table data ---")
    print(f"Input : {input_path}")
    print(f"Output: {output_path}")
    source = pd.read_csv(input_path, low_memory=False)

    required = (
        ["Fine Amount", "Provider SSA County Code", "CMS Certification Number (CCN)"]
        + base.QUALITY_MEASURE_COLUMNS
        + base.CLAIMS_COLUMNS
        + base.STAFFING_COLUMNS
        + base.HEALTH_DEFICIENCY_COLUMNS
        + base.RATING_AND_REGULATORY_COLUMNS
        + base.ORGANIZATION_AND_GEOGRAPHY_COLUMNS
        + [
            "Processing Date",
            "Date First Approved to Provide Medicare and Medicaid Services",
            "Rating Cycle 1 Standard Survey Health Date",
            "Rating Cycle 2 Standard Health Survey Date",
        ]
    )
    base._validate_columns(source, required)

    fine_amount = pd.to_numeric(source["Fine Amount"], errors="coerce").fillna(0)
    source["Target_Penalty"] = (
        fine_amount > TARGET_THRESHOLD
    ).astype("int8")
    source["SSA_Region_Code"] = (
        pd.to_numeric(source["Provider SSA County Code"], errors="coerce")
        .round()
        .astype("Int64")
        .astype("string")
        .str.zfill(3)
        .radd("SSA_")
    )
    # The 122-column source can trigger a harmless pandas block-fragmentation
    # warning while several derived columns are appended.  Suppress only that
    # performance warning; data and numerical warnings remain visible.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", PerformanceWarning)
        source = base._add_history_features(source)
        source = base._add_composite_features(source)

    raw_real_features = list(
        dict.fromkeys(
            base.QUALITY_MEASURE_COLUMNS
            + base.CLAIMS_COLUMNS
            + base.STAFFING_COLUMNS
            + base.HEALTH_DEFICIENCY_COLUMNS
            + base.RATING_AND_REGULATORY_COLUMNS
            + base.ORGANIZATION_AND_GEOGRAPHY_COLUMNS
            + ["SSA_Region_Code"]
            + base.DERIVED_HISTORY_COLUMNS
        )
    )
    columns = ["Target_Penalty"] + base.COMPOSITE_COLUMNS + raw_real_features
    result = source[columns].copy()
    result, derived, footnote_flags = add_focal_ready_features(result, source)

    leakage = sorted(set(result.columns) & set(base.DIRECT_LEAKAGE_COLUMNS))
    identifiers = sorted(set(result.columns) & set(base.IDENTIFIER_COLUMNS))
    if leakage or identifiers:
        raise RuntimeError(
            f"Leakage audit failed: leakage={leakage}; identifiers={identifiers}"
        )
    expected_target = (fine_amount > TARGET_THRESHOLD).astype("int8")
    if not result["Target_Penalty"].equals(expected_target):
        raise RuntimeError("Target changed during feature construction.")
    numeric = result.select_dtypes(include=[np.number])
    if np.isinf(numeric.to_numpy(dtype=float, na_value=np.nan)).any():
        raise RuntimeError("Infinite values found in output.")
    if result.columns.duplicated().any():
        raise RuntimeError("Duplicate output column names found.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False, encoding="utf-8-sig")

    manifest_path = output_path.with_name(
        f"{output_path.stem}_feature_manifest.csv"
    )
    build_feature_manifest(
        result.columns.tolist(), derived, footnote_flags
    ).to_csv(manifest_path, index=False, encoding="utf-8-sig")

    split_path = output_path.with_name(f"{output_path.stem}_split_manifest.csv")
    split_manifest = build_split_manifest(source, result["Target_Penalty"])
    split_manifest.to_csv(split_path, index=False, encoding="utf-8-sig")

    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input_path": str(input_path),
        "input_sha256": file_sha256(input_path),
        "output_path": str(output_path),
        "rows": int(len(result)),
        "columns": int(result.shape[1]),
        "model_feature_count": int(result.shape[1] - 1),
        "target_definition": f"Fine Amount > {TARGET_THRESHOLD:.2f}",
        "positive_count": int(result["Target_Penalty"].sum()),
        "negative_count": int((result["Target_Penalty"] == 0).sum()),
        "positive_prevalence": float(result["Target_Penalty"].mean()),
        "natural_imbalance_preserved": True,
        "smote_or_synthetic_sampling_applied": False,
        "label_flipping_applied": False,
        "target_dependent_predictors": False,
        "raw_real_feature_count": len(raw_real_features),
        "transparent_composite_count": len(base.COMPOSITE_COLUMNS),
        "additional_derived_feature_count": len(derived),
        "footnote_indicator_count": len(footnote_flags),
        "split_policy": "70% development, 10% calibration, 10% threshold, 10% locked test",
        "split_summary": (
            split_manifest.groupby("split")["y_true"]
            .agg(n="size", positives="sum", prevalence="mean")
            .reset_index()
            .to_dict("records")
        ),
        "excluded_direct_leakage_columns": base.DIRECT_LEAKAGE_COLUMNS,
        "excluded_identifier_columns": base.IDENTIFIER_COLUMNS,
    }
    metadata_path = output_path.with_name(
        f"{output_path.stem}_preparation_metadata.json"
    )
    metadata["output_sha256"] = file_sha256(output_path)
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(
        f"Rows={len(result):,}; columns={result.shape[1]}; "
        f"positives={int(result['Target_Penalty'].sum()):,} "
        f"({result['Target_Penalty'].mean():.2%})"
    )
    print(f"Feature manifest: {manifest_path}")
    print(f"Split manifest  : {split_path}")
    print(f"Metadata        : {metadata_path}")
    return result


def _load_wide_target(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series, str]:
    """Load/verify the fixed target without changing any labels."""

    frame = frame.copy()
    if "Target_Penalty" in frame.columns:
        target = pd.to_numeric(frame.pop("Target_Penalty"), errors="raise").astype(
            "int8"
        )
        definition = "existing Target_Penalty (originally Fine Amount > 170734.80)"
        if "Fine Amount" in frame.columns:
            expected = (
                pd.to_numeric(frame["Fine Amount"], errors="coerce").fillna(0)
                > TARGET_THRESHOLD
            ).astype("int8")
            if not target.equals(expected):
                raise RuntimeError(
                    "Target_Penalty does not match Fine Amount > 170734.80."
                )
            definition = f"Fine Amount > {TARGET_THRESHOLD:.2f}"
    elif "Fine Amount" in frame.columns:
        target = (
            pd.to_numeric(frame["Fine Amount"], errors="coerce").fillna(0)
            > TARGET_THRESHOLD
        ).astype("int8")
        definition = f"Fine Amount > {TARGET_THRESHOLD:.2f}"
    else:
        raise ValueError("宽表必须包含Target_Penalty或Fine Amount。")

    if set(target.unique()) != {0, 1}:
        raise ValueError("Target_Penalty必须同时包含0和1。")
    excluded = (
        set(base.DIRECT_LEAKAGE_COLUMNS)
        | set(base.IDENTIFIER_COLUMNS)
        | {"Target_Penalty"}
    )
    frame = frame.drop(
        columns=[column for column in excluded if column in frame.columns],
        errors="ignore",
    )
    return frame, target, definition


def _domain_feature_groups(frame: pd.DataFrame) -> dict[str, list[str]]:
    """Assign real wide-table columns to three transparent business domains."""

    columns = frame.columns.tolist()

    def matches(column: str, keywords: tuple[str, ...]) -> bool:
        lowered = column.lower()
        return any(keyword in lowered for keyword in keywords)

    clinical_keywords = (
        "percentage of long-stay",
        "percentage of short-stay",
        "claims_",
        "case-mix index",
        "clinical",
        "quality",
        "qm rating",
    )
    regulatory_keywords = (
        "rating cycle",
        "health survey",
        "health inspection",
        "health deficien",
        "infection control",
        "special focus",
        "abuse icon",
        "overall rating",
        "regulatory",
        "revisit",
        "citation",
    )
    administrative_keywords = (
        "staffing",
        "turnover",
        "administrator",
        "ownership",
        "provider type",
        "state",
        "urban",
        "chain",
        "certified beds",
        "residents per day",
        "resident and family council",
        "sprinkler",
        "administrative",
        "admin_",
        "occupancy",
    )

    groups = {
        "clinical": [
            column for column in columns if matches(column, clinical_keywords)
        ],
        "regulatory": [
            column for column in columns if matches(column, regulatory_keywords)
        ],
        "administrative": [
            column for column in columns if matches(column, administrative_keywords)
        ],
    }
    explicit = {
        "clinical": ["Latent_Clinical_Risk", "Claims_Utilization_Composite"],
        "regulatory": [
            "Regulatory_Antagonism_Index",
            "Total Weighted Health Survey Score",
        ],
        "administrative": [
            "Masked_Admin_Redundancy",
            "Provider Resides in Hospital",
            "Continuing Care Retirement Community",
        ],
    }
    for domain, required in explicit.items():
        groups[domain] = list(
            dict.fromkeys(
                groups[domain]
                + [column for column in required if column in frame.columns]
            )
        )
        if len(groups[domain]) < 3:
            raise ValueError(f"{domain}领域可用特征不足: {groups[domain]}")
    return groups


def _prepare_lightgbm_domain_frame(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    for column in frame.columns:
        if not pd.api.types.is_numeric_dtype(frame[column].dtype):
            frame[column] = frame[column].astype("category")
        else:
            frame[column] = pd.to_numeric(frame[column], errors="coerce").astype(
                "float32"
            )
    return frame


def _cross_fitted_domain_score(
    frame: pd.DataFrame,
    target: pd.Series,
    split_manifest: pd.DataFrame,
    columns: list[str],
    *,
    domain: str,
    folds: int,
    random_state: int,
) -> tuple[np.ndarray, dict]:
    """Create leakage-safe OOF/holdout probabilities for one feature domain."""

    domain_frame = _prepare_lightgbm_domain_frame(frame[columns])
    categorical_columns = domain_frame.select_dtypes(
        include=["category"]
    ).columns.tolist()
    development_ids = split_manifest.loc[
        split_manifest["split"] == "development", "sample_id"
    ].to_numpy(dtype=int)
    holdout_ids = split_manifest.loc[
        split_manifest["split"] != "development", "sample_id"
    ].to_numpy(dtype=int)
    score = np.full(len(frame), np.nan, dtype=float)
    holdout_sum = np.zeros(len(holdout_ids), dtype=float)
    fold_rows = []

    splitter = StratifiedKFold(
        n_splits=folds,
        shuffle=True,
        random_state=random_state,
    )
    development_target = target.iloc[development_ids]
    for fold_id, (train_position, validation_position) in enumerate(
        splitter.split(development_ids, development_target), start=1
    ):
        train_ids = development_ids[train_position]
        validation_ids = development_ids[validation_position]
        y_train = target.iloc[train_ids]
        scale_pos_weight = float((len(y_train) - y_train.sum()) / y_train.sum())
        model = lgb.LGBMClassifier(
            objective="binary",
            n_estimators=1200,
            learning_rate=0.025,
            num_leaves=15,
            max_depth=5,
            min_child_samples=50,
            subsample=0.85,
            subsample_freq=1,
            colsample_bytree=0.85,
            reg_alpha=0.1,
            reg_lambda=5.0,
            scale_pos_weight=scale_pos_weight,
            force_col_wise=True,
            random_state=random_state + fold_id,
            n_jobs=-1,
            verbose=-1,
        )
        model.fit(
            domain_frame.iloc[train_ids],
            y_train,
            categorical_feature=categorical_columns,
            eval_set=[
                (domain_frame.iloc[validation_ids], target.iloc[validation_ids])
            ],
            eval_metric="average_precision",
            callbacks=[
                lgb.early_stopping(
                    stopping_rounds=120,
                    first_metric_only=True,
                    verbose=False,
                )
            ],
        )
        validation_probability = model.predict_proba(
            domain_frame.iloc[validation_ids]
        )[:, 1]
        score[validation_ids] = validation_probability
        holdout_sum += model.predict_proba(domain_frame.iloc[holdout_ids])[:, 1]
        fold_rows.append(
            {
                "fold": fold_id,
                "best_iteration": int(model.best_iteration_ or model.n_estimators),
                "validation_PR_AUC": float(
                    average_precision_score(
                        target.iloc[validation_ids], validation_probability
                    )
                ),
            }
        )

    score[holdout_ids] = holdout_sum / folds
    if np.isnan(score).any():
        raise RuntimeError(f"{domain}交叉拟合分数存在未赋值样本。")

    audit = {
        "domain": domain,
        "source_feature_count": len(columns),
        "source_features": columns,
        "folds": fold_rows,
        "split_metrics": [],
    }
    for split_name, group in split_manifest.groupby("split"):
        ids = group["sample_id"].to_numpy(dtype=int)
        audit["split_metrics"].append(
            {
                "split": split_name,
                "n": int(len(ids)),
                "positives": int(target.iloc[ids].sum()),
                "PR_AUC": float(
                    average_precision_score(target.iloc[ids], score[ids])
                ),
                "ROC_AUC": float(roc_auc_score(target.iloc[ids], score[ids])),
            }
        )
    return score, audit


def build_three_feature_upper_bound_dataset(
    input_path: str | Path = DEFAULT_WIDE_INPUT,
    output_path: str | Path = DEFAULT_THREE_FEATURE_OUTPUT,
    *,
    folds: int = 5,
) -> pd.DataFrame:
    """Build a leakage-safe stacked three-score upper-bound benchmark.

    The three scores are supervised meta-features.  Development rows receive
    out-of-fold predictions; calibration/threshold/test rows receive averages
    from models trained only on development folds.  No holdout label is used
    to fit or select a domain model.
    """

    input_path = Path(input_path)
    output_path = Path(output_path)
    if not input_path.exists():
        raise FileNotFoundError(input_path)
    print("--- Building cross-fitted three-feature Focal upper bound ---")
    print(f"Input : {input_path}")
    print(f"Output: {output_path}")

    source = pd.read_csv(input_path, low_memory=False)
    frame, target, target_definition = _load_wide_target(source)
    groups = _domain_feature_groups(frame)

    split_source = pd.DataFrame(
        {
            "CMS Certification Number (CCN)": (
                source["CMS Certification Number (CCN)"]
                if "CMS Certification Number (CCN)" in source.columns
                else pd.Series([f"ROW_{index}" for index in range(len(source))])
            )
        }
    )
    split_manifest = build_split_manifest(split_source, target)

    score_definitions = {
        "Latent_Clinical_Risk": "clinical",
        "Regulatory_Antagonism_Index": "regulatory",
        "Masked_Admin_Redundancy": "administrative",
    }
    result = pd.DataFrame({"Target_Penalty": target})
    audits = []
    for output_column, domain in score_definitions.items():
        score, audit = _cross_fitted_domain_score(
            frame,
            target,
            split_manifest,
            groups[domain],
            domain=domain,
            folds=folds,
            random_state=RANDOM_STATE + len(audits) * 100,
        )
        result[output_column] = (score * 100.0).round(8)
        audits.append(audit)
        development_metric = next(
            row for row in audit["split_metrics"] if row["split"] == "development"
        )
        print(
            f"{domain}: features={len(groups[domain])}, "
            f"development OOF PR-AUC={development_metric['PR_AUC']:.4f}"
        )

    context_columns = [
        "State",
        "Ownership Type",
        "Provider Type",
        "Reported Total Nurse Staffing Hours per Resident per Day",
        "Rating Cycle 1 Total Number of Health Deficiencies",
    ]
    for column in context_columns:
        if column in frame.columns:
            result[column] = frame[column]

    if result.columns.duplicated().any() or result.isna().all().any():
        raise RuntimeError("Three-feature output failed structural validation.")
    if not result["Target_Penalty"].equals(target):
        raise RuntimeError("Target changed during three-feature construction.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False, encoding="utf-8-sig")
    split_path = output_path.with_name(f"{output_path.stem}_split_manifest.csv")
    split_manifest.to_csv(split_path, index=False, encoding="utf-8-sig")

    manifest_rows = [
        {
            "column": "Target_Penalty",
            "role": "target",
            "construction": target_definition,
            "uses_target": True,
            "leakage_control": "not applicable",
        }
    ]
    for column, domain in score_definitions.items():
        manifest_rows.append(
            {
                "column": column,
                "role": "cross_fitted_domain_score",
                "construction": f"LightGBM probability from {domain} domain × 100",
                "uses_target": True,
                "leakage_control": (
                    "development=out-of-fold; calibration/threshold/test="
                    "average of development-fold models"
                ),
            }
        )
    for column in context_columns:
        if column in result.columns:
            manifest_rows.append(
                {
                    "column": column,
                    "role": "raw_context_feature",
                    "construction": "copied from real wide table",
                    "uses_target": False,
                    "leakage_control": "no outcome information used",
                }
            )
    manifest_path = output_path.with_name(
        f"{output_path.stem}_feature_manifest.csv"
    )
    pd.DataFrame(manifest_rows).to_csv(
        manifest_path, index=False, encoding="utf-8-sig"
    )

    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "intended_use": (
            "upper-bound/stress-test benchmark for LightGBM + Focal Loss; "
            "not a raw-feature primary analysis"
        ),
        "input_path": str(input_path),
        "input_sha256": file_sha256(input_path),
        "output_path": str(output_path),
        "rows": int(len(result)),
        "columns": int(result.shape[1]),
        "model_feature_count": int(result.shape[1] - 1),
        "target_definition": target_definition,
        "positive_count": int(target.sum()),
        "positive_prevalence": float(target.mean()),
        "natural_imbalance_preserved": True,
        "label_flipping_applied": False,
        "random_label_conditioned_feature_injection": False,
        "supervised_meta_features": True,
        "leakage_safe_cross_fitting": True,
        "domain_model_folds": folds,
        "domain_audits": audits,
        "split_policy": (
            "Exact Focal script split: test=10% (random_state=42); then "
            "development=77.78% of remainder and tune/calibration=22.22% "
            "(random_state=42); tune and calibration split equally "
            "(random_state=43). Final proportions are 70/10/10/10."
        ),
        "downstream_split_contract": (
            "The downstream model must preserve the row order and reproduce "
            "the supplied split manifest; re-splitting with another policy "
            "invalidates the locked-test leakage boundary."
        ),
        "warning": (
            "These three scores are stacked predictions. The method must be "
            "reported as supervised cross-fitting and must not be described as "
            "unsupervised or raw latent variables."
        ),
    }
    metadata["output_sha256"] = file_sha256(output_path)
    metadata_path = output_path.with_name(
        f"{output_path.stem}_preparation_metadata.json"
    )
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        f"Rows={len(result):,}; columns={result.shape[1]}; "
        f"positives={int(target.sum()):,} ({target.mean():.2%})"
    )
    print(f"Feature manifest: {manifest_path}")
    print(f"Split manifest  : {split_path}")
    print(f"Metadata        : {metadata_path}")
    return result


def build_synthetic_focal_benchmark(
    input_path: str | Path = DEFAULT_WIDE_INPUT,
    output_path: str | Path = DEFAULT_SYNTHETIC_OUTPUT,
    *,
    seed: int = RANDOM_STATE,
) -> pd.DataFrame:
    """Create a reproducible label-conditional Focal stress-test dataset.

    This deliberately recreates the mechanism behind the former high-scoring
    three-feature file, but makes the simulation status auditable.  The real
    outcome prevalence and contextual columns are retained; the three risk
    indices are synthetic draws conditional on the outcome.  Consequently,
    this output is an oracle-style benchmark and is invalid for estimating
    real-world predictive performance.
    """

    input_path = Path(input_path)
    output_path = Path(output_path)
    if not input_path.exists():
        raise FileNotFoundError(input_path)

    source = pd.read_csv(input_path, low_memory=False)
    frame, target, target_definition = _load_wide_target(source)
    y = target.to_numpy(dtype=np.int8)
    rng = np.random.default_rng(seed)
    n_rows = len(target)

    # Shared hard-example flag creates overlap in all three channels.  Focal
    # loss is designed to place more weight on these difficult observations.
    # The ideal profile is calibrated to the former three-feature benchmark:
    # very strong signal with a small, explicit overlap region.
    hard_probability = np.where(y == 1, 0.025, 0.006)
    hard = rng.random(n_rows) < hard_probability

    clinical = np.empty(n_rows, dtype=float)
    regulatory = np.empty(n_rows, dtype=float)
    administrative = np.empty(n_rows, dtype=float)

    easy_positive = (y == 1) & ~hard
    hard_positive = (y == 1) & hard
    easy_negative = (y == 0) & ~hard
    hard_negative = (y == 0) & hard

    clinical[easy_positive] = rng.normal(11.6, 2.55, easy_positive.sum())
    clinical[hard_positive] = rng.normal(5.8, 1.80, hard_positive.sum())
    clinical[easy_negative] = rng.normal(4.0, 1.95, easy_negative.sum())
    clinical[hard_negative] = rng.normal(9.0, 1.80, hard_negative.sum())

    regulatory[easy_positive] = rng.gamma(5.4, 3.05, easy_positive.sum())
    regulatory[hard_positive] = rng.gamma(2.2, 2.1, hard_positive.sum())
    regulatory[easy_negative] = rng.gamma(2.0, 2.0, easy_negative.sum())
    regulatory[hard_negative] = rng.gamma(5.0, 2.8, hard_negative.sum())

    administrative[easy_positive] = rng.lognormal(
        0.10, 0.50, easy_positive.sum()
    )
    administrative[hard_positive] = rng.lognormal(
        1.35, 0.32, hard_positive.sum()
    )
    administrative[easy_negative] = rng.lognormal(
        1.45, 0.29, easy_negative.sum()
    )
    administrative[hard_negative] = rng.lognormal(
        0.15, 0.40, hard_negative.sum()
    )

    # Small continuous perturbations prevent duplicate feature vectors while
    # keeping the class-conditional mechanism fully reproducible.
    clinical += rng.normal(0.0, 0.12, n_rows)
    regulatory += rng.normal(0.0, 0.10, n_rows)
    administrative += rng.normal(0.0, 0.04, n_rows)

    result = pd.DataFrame(
        {
            "Target_Penalty": target,
            "Latent_Clinical_Risk": clinical.round(8),
            "Regulatory_Antagonism_Index": np.clip(
                regulatory, 0.0, None
            ).round(8),
            "Masked_Admin_Redundancy": np.clip(
                administrative, 0.02, None
            ).round(8),
        }
    )
    context_columns = [
        "State",
        "Ownership Type",
        "Provider Type",
        "Reported Total Nurse Staffing Hours per Resident per Day",
        "Rating Cycle 1 Total Number of Health Deficiencies",
    ]
    for column in context_columns:
        if column in frame.columns:
            result[column] = frame[column]

    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False, encoding="utf-8-sig")

    split_manifest = build_split_manifest(
        pd.DataFrame(
            {
                "CMS Certification Number (CCN)": source.get(
                    "CMS Certification Number (CCN)",
                    pd.Series([f"ROW_{index}" for index in range(n_rows)]),
                )
            }
        ),
        target,
    )
    split_path = output_path.with_name(f"{output_path.stem}_split_manifest.csv")
    split_manifest.to_csv(split_path, index=False, encoding="utf-8-sig")

    synthetic_columns = [
        "Latent_Clinical_Risk",
        "Regulatory_Antagonism_Index",
        "Masked_Admin_Redundancy",
    ]
    audits = []
    for column in synthetic_columns:
        values = result[column].to_numpy(dtype=float)
        auc = roc_auc_score(target, values)
        direction = "higher=risk"
        if auc < 0.5:
            auc = 1.0 - auc
            direction = "lower=risk"
        audits.append(
            {
                "column": column,
                "ROC_AUC_direction_adjusted": float(auc),
                "average_precision_raw_direction": float(
                    average_precision_score(target, values)
                ),
                "direction": direction,
            }
        )

    manifest_rows = [
        {
            "column": "Target_Penalty",
            "role": "real outcome label retained for simulation",
            "construction": target_definition,
            "uses_target": True,
            "scientific_status": "outcome only",
        }
    ]
    for column in synthetic_columns:
        manifest_rows.append(
            {
                "column": column,
                "role": "synthetic label-conditional predictor",
                "construction": (
                    "seeded class-conditional distribution with a shared "
                    "hard-example mixture"
                ),
                "uses_target": True,
                "scientific_status": "simulation/stress test only",
            }
        )
    for column in context_columns:
        if column in result.columns:
            manifest_rows.append(
                {
                    "column": column,
                    "role": "real contextual covariate",
                    "construction": "copied unchanged from source wide table",
                    "uses_target": False,
                    "scientific_status": "real context",
                }
            )
    manifest_path = output_path.with_name(
        f"{output_path.stem}_feature_manifest.csv"
    )
    pd.DataFrame(manifest_rows).to_csv(
        manifest_path, index=False, encoding="utf-8-sig"
    )

    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "dataset_type": "SEMI-SYNTHETIC ORACLE BENCHMARK",
        "allowed_use": (
            "software verification, Focal Loss sensitivity analysis, and "
            "methodological upper-bound stress testing"
        ),
        "prohibited_use": (
            "real-world performance claims, primary SCI effectiveness tables, "
            "clinical/regulatory conclusions, or external validation claims"
        ),
        "input_path": str(input_path),
        "input_sha256": file_sha256(input_path),
        "output_path": str(output_path),
        "rows": int(len(result)),
        "columns": int(result.shape[1]),
        "positive_count": int(target.sum()),
        "positive_prevalence": float(target.mean()),
        "target_definition": target_definition,
        "random_seed": int(seed),
        "label_conditioned_predictors": True,
        "label_flipping_applied": False,
        "hard_positive_probability": 0.025,
        "hard_negative_probability": 0.006,
        "univariate_audits": audits,
        "split_contract": (
            "Exact row-order split used by LightGBM + Focal Loss Final.py; "
            "see supplied split manifest."
        ),
        "warning": (
            "Predictors were generated conditional on Target_Penalty. High "
            "scores measure recoverability of an injected signal, not the "
            "predictability of nursing-home penalties from observed data."
        ),
    }
    metadata["output_sha256"] = file_sha256(output_path)
    metadata_path = output_path.with_name(
        f"{output_path.stem}_preparation_metadata.json"
    )
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("--- Built explicit semi-synthetic Focal benchmark ---")
    print(
        f"Rows={len(result):,}; columns={result.shape[1]}; "
        f"positives={int(target.sum()):,} ({target.mean():.2%})"
    )
    for audit in audits:
        print(
            f"{audit['column']}: adjusted ROC-AUC="
            f"{audit['ROC_AUC_direction_adjusted']:.4f}"
        )
    print(f"Output          : {output_path}")
    print(f"Feature manifest: {manifest_path}")
    print(f"Split manifest  : {split_path}")
    print(f"Metadata        : {metadata_path}")
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build full-real, cross-fitted upper-bound, or explicit synthetic "
            "Focal benchmark data."
        )
    )
    parser.add_argument(
        "--mode",
        choices=[
            "three-feature-upper-bound",
            "synthetic-focal-benchmark",
            "full-real",
        ],
        default="three-feature-upper-bound",
    )
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=RANDOM_STATE)
    args = parser.parse_args()
    if args.folds < 2:
        parser.error("--folds必须至少为2。")
    return args


if __name__ == "__main__":
    arguments = parse_args()
    if arguments.mode == "full-real":
        build_focal_ready_dataset(
            arguments.input or DEFAULT_INPUT,
            arguments.output or DEFAULT_OUTPUT,
        )
    elif arguments.mode == "three-feature-upper-bound":
        build_three_feature_upper_bound_dataset(
            arguments.input or DEFAULT_WIDE_INPUT,
            arguments.output or DEFAULT_THREE_FEATURE_OUTPUT,
            folds=arguments.folds,
        )
    else:
        build_synthetic_focal_benchmark(
            arguments.input or DEFAULT_WIDE_INPUT,
            arguments.output or DEFAULT_SYNTHETIC_OUTPUT,
            seed=arguments.seed,
        )
