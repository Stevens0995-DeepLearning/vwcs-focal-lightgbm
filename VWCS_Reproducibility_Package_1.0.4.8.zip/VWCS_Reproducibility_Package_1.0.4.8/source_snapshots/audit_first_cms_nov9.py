from pathlib import Path
import numpy as np, pandas as pd, hashlib, ast
from types import SimpleNamespace
from zipfile import ZipFile
from xml.etree import ElementTree as ET
b=Path(r'C:\ASQ备考\博士论文\西藏项目')
e=b/'资料准备/数据/实验数据'
raw=e/'others'; other=e.parent/'数据准备'; main=b/'Main coding'
cc='CMS Certification Number (CCN)'
def load(p):
    return pd.read_csv(p,dtype={cc:str},low_memory=False)
for loc in [raw,other]:
    for f in sorted(loc.glob('*May2026.csv')):
        d=load(f);print(loc.name,f.name,d.shape,d[cc].nunique() if cc in d else '-',d['Processing Date'].value_counts().head(2).to_dict() if 'Processing Date' in d else '-')
xf=other/'数据映射关系.xlsx'
with ZipFile(xf) as z:
    print('mapping', ''.join(ET.fromstring(z.read('xl/sharedStrings.xml')).itertext())[:1100] if 'xl/sharedStrings.xml' in z.namelist() else z.namelist()[:10])
r=load(raw/'NH_ProviderInfo_May2026.csv'); f=load(raw/'NH_Penalties_May2026.csv')
d=load(e/'NH_ProviderInfo_Combine.csv'); y=d.Target_Penalty
print('sha',hashlib.sha256((e/'NH_ProviderInfo_Combine.csv').read_bytes()).hexdigest());print('final',d.shape, y.value_counts().to_dict(),d.isna().sum().to_dict())
v=f.groupby(cc)['Fine Amount'].sum().reindex(r[cc]); observed=v.fillna(0).reset_index(drop=True)
print('raw', v.isna().sum(),observed.quantile(.95),sum(observed>170734.8),'label diffs', sum((observed>170734.8)!=y), 'p95 without fill',v.quantile(.95),'penalty dates',pd.to_datetime(f['Penalty Date']).min(),pd.to_datetime(f['Penalty Date']).max())
for c in d.columns.intersection(r.columns):
    print('shared',c,'different',(~(d[c].eq(r[c]) | (d[c].isna()&r[c].isna()))).sum(),'missing raw,final',r[c].isna().sum(),d[c].isna().sum())
for f in sorted((e/'backup').glob('*.csv')):
    t=load(f);print(f.name,t.shape, 'fineq',t['Fine Amount'].fillna(0).quantile(.95) if 'Fine Amount' in t else None, 'yf', int(((t['Fine Amount'].fillna(0)>170734.8)!=y).sum()) if 'Fine Amount' in t and len(t)==len(d) else None, 'y mismatch',int((t.Target_Penalty!=y).sum()) if 'Target_Penalty' in t and len(t)==len(y) else None)
def extract(script,namelist,env):
    tree=ast.parse((main/script).read_text(encoding='utf-8-sig'))
    tree.body=[s for s in tree.body if isinstance(s,ast.FunctionDef) and s.name in namelist or isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id in namelist for t in s.targets)]
    exec(compile(tree,str(script),'exec'),env);return SimpleNamespace(**env)
a=extract('Generate_Focal_Attenuation_Scenarios.py',{'RANDOM_STATE','SCENARIOS','MECHANISM_NAMES','MECHANISM_FEATURES','MECHANISM_WEIGHTS','CORE_FEATURES','shared_simulation_design','regenerate_mechanism_scores','attenuate_core','exact_subset'},dict(np=np,pd=pd))
s=load(e/'backup/NH_ProviderInfo_Focal_Synthetic_Benchmark.csv')
design=a.shared_simulation_design(y)
spl=main/'logs/sci_model_outputs/focal_lgbm/20260802_194022'
print('run files', [p.name for p in spl.iterdir()])
trainids=None
for p in spl.glob('*split*.csv'):
    m=load(p);print(p.name,m.columns.tolist(),m.head(1).to_dict('records'))
    if 'split' in m and 'sample_id' in m:
        trainids=m.loc[m['split'].isin(['train','development']),'sample_id'].to_numpy()
def sss(ids,test_frac,seed):
    rng=np.random.RandomState(seed); labs=y.to_numpy()[ids]; ns=np.bincount(labs); n=len(ids)-int(np.ceil(test_frac*len(ids)))
    q=ns/ns.sum()*n; counts=np.floor(q).astype(int); remain=n-counts.sum()
    for frac in sorted(set(q-counts),reverse=True):
        if not remain: break
        choices=np.flatnonzero((q-np.floor(q))==frac); k=min(remain,len(choices));counts[rng.choice(choices,k,replace=False)]+=1;remain-=k
    tr=[];te=[]
    for label,nt in enumerate(counts):
        group=ids[labs==label][rng.permutation(ns[label])];tr.extend(group[:nt]);te.extend(group[nt:])
    return rng.permutation(tr),rng.permutation(te)
rem,test=sss(np.arange(len(y)),.1,42)
print('test identity',set(test)==set(load(spl/'test_predictions.csv').sample_id))
trainids=np.sort(sss(rem,.2222,42)[0])
src=(main/'DataPreparation_FocalReady.py').read_text(encoding='utf-8-sig')
start=src.index('    hard_probability ='); stop=src.index('    output_path.parent.mkdir', start)
import textwrap
env=dict(np=np,pd=pd,n_rows=len(y),y=y.to_numpy(),target=y,frame=r,rng=np.random.default_rng(42))
exec(textwrap.dedent(src[start:stop]),env)
print('base simulated exact?',np.allclose(env['result'][a.CORE_FEATURES],s[a.CORE_FEATURES],rtol=0,atol=0))
print('key relationship',d[[d.columns[7],d.columns[8]]].corr().iloc[0,1])
for j,(name,config) in enumerate(a.SCENARIOS.items()):
    weak=design['weak_order'][:round(y.sum()*.15)]; risky=design['negative_order'][:round((len(y)-y.sum())*.05)]
    pred=a.regenerate_mechanism_scores(s,y,design,weak,risky,a.RANDOM_STATE+100*j)
    print(name,'mechanism max error',np.max(abs(d[a.MECHANISM_FEATURES]-pred[a.MECHANISM_FEATURES]).to_numpy()))
    if trainids is not None and len(trainids)==10290:
        p,_=a.attenuate_core(pred,y,trainids,design,weak,risky,config,a.RANDOM_STATE+1000*j)
        if j==0:
            for c in a.CORE_FEATURES:
                for group,xx in [('base',s),('replayed',p)]:
                    err=(xx[c]-d[c]).abs(); print(group,c,'different rows',sum(err>1e-7),'by class',err.gt(1e-7).groupby(y).sum().to_dict(),'max',err.max())
        print(name,'all columns', [(c, np.allclose(p[c],d[c],atol=1e-7,rtol=0,equal_nan=True) if pd.api.types.is_numeric_dtype(d[c]) else p[c].equals(d[c])) for c in d])
