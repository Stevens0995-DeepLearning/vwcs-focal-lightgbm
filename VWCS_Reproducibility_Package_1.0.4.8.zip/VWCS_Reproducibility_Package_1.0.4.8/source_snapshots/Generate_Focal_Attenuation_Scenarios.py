"""Generate auditable signal-attenuation scenarios for the Focal benchmark.

The locked split is created before any empirical scale or replacement pool is
calculated.  Every empirical quantity used by attenuation comes exclusively
from the development split.  Labels and rows are never changed or resampled.
These outputs remain target-conditional simulations and are not observational
real-world validation data.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import train_test_split


RANDOM_STATE = 20260801
SPLIT_RANDOM_STATE = 42
TARGET = "Target_Penalty"
CORE_FEATURES = [
    "Latent_Clinical_Risk",
    "Regulatory_Antagonism_Index",
    "Masked_Admin_Redundancy",
]
MECHANISM_FEATURES = [
    "Clinical_High_Risk_Score",
    "Historical_Regulatory_Deficit_Score",
    "Staffing_Shortage_Risk_Score",
    "Historical_Claims_Anomaly_Score",
    "Multifactor_Interaction_Risk_Score",
]
MECHANISM_NAMES = np.array(
    [
        "clinical_high_risk",
        "regulatory_deficit",
        "staffing_shortage",
        "claims_anomaly",
        "multifactor_interaction",
    ],
    dtype=object,
)
MECHANISM_WEIGHTS = np.array([0.24, 0.20, 0.20, 0.18, 0.18])

INPUT = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Focal_Synthetic_Benchmark.csv"
)
OUTPUT_DIR = INPUT.parent
OUTPUT_STEM = "NH_ProviderInfo_Focal_Synthetic_Benchmark_Attenuation"

SCENARIOS = {
    "Unweakened": {
        "noise_sd": 0.0,
        "replacement_rate": 0.0,
        "missing_rate": 0.0,
        "weak_positive_rate": 0.15,
        "high_risk_negative_rate": 0.05,
        "regenerate_mechanisms": True,
        "orthogonalize_core_mechanisms": False,
    },
    "Light": {
        "noise_sd": 0.5,
        "replacement_rate": 0.15,
        "missing_rate": 0.05,
        "weak_positive_rate": 0.15,
        "high_risk_negative_rate": 0.05,
        "regenerate_mechanisms": True,
        "orthogonalize_core_mechanisms": False,
    },
    "Moderate": {
        "noise_sd": 1.0,
        "replacement_rate": 0.25,
        "missing_rate": 0.10,
        "weak_positive_rate": 0.15,
        "high_risk_negative_rate": 0.05,
        "regenerate_mechanisms": True,
        "orthogonalize_core_mechanisms": False,
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def locked_split(target: pd.Series) -> pd.DataFrame:
    indices = np.arange(len(target))
    remaining, test = train_test_split(
        indices,
        test_size=0.10,
        random_state=SPLIT_RANDOM_STATE,
        stratify=target,
    )
    development, tune_calibration = train_test_split(
        remaining,
        test_size=0.2222,
        random_state=SPLIT_RANDOM_STATE,
        stratify=target.iloc[remaining],
    )
    threshold, calibration = train_test_split(
        tune_calibration,
        test_size=0.50,
        random_state=SPLIT_RANDOM_STATE + 1,
        stratify=target.iloc[tune_calibration],
    )
    names = np.full(len(target), "", dtype=object)
    names[development] = "development"
    names[threshold] = "threshold"
    names[calibration] = "calibration"
    names[test] = "test"
    return pd.DataFrame(
        {
            "sample_id": indices,
            "split": names,
            "y_true": target.to_numpy(dtype=int),
        }
    )


def exact_subset(
    candidates: np.ndarray,
    rate: float,
    rng: np.random.Generator,
) -> np.ndarray:
    count = int(round(len(candidates) * rate))
    if count == 0:
        return np.array([], dtype=int)
    return np.sort(rng.choice(candidates, size=count, replace=False))


def shared_simulation_design(target: pd.Series) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(RANDOM_STATE)
    y = target.to_numpy(dtype=np.int8)
    positives = np.flatnonzero(y == 1)
    negatives = np.flatnonzero(y == 0)
    mechanism = np.full(len(y), "background", dtype=object)
    mechanism[positives] = rng.choice(
        MECHANISM_NAMES,
        size=len(positives),
        p=MECHANISM_WEIGHTS,
    )
    negative_order = rng.permutation(negatives)
    weak_order = rng.permutation(positives)
    negative_mechanism = rng.choice(
        MECHANISM_NAMES,
        size=len(negatives),
        p=MECHANISM_WEIGHTS,
    )
    return {
        "mechanism": mechanism,
        "positives": positives,
        "negatives": negatives,
        "weak_order": weak_order,
        "negative_order": negative_order,
        "negative_mechanism": negative_mechanism,
    }


def regenerate_mechanism_scores(
    frame: pd.DataFrame,
    target: pd.Series,
    design: dict[str, np.ndarray],
    weak_ids: np.ndarray,
    risky_negative_ids: np.ndarray,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    y = target.to_numpy(dtype=np.int8)
    mechanism = design["mechanism"].copy()
    negative_map = dict(
        zip(design["negatives"], design["negative_mechanism"], strict=True)
    )
    for sample_id in risky_negative_ids:
        mechanism[sample_id] = negative_map[int(sample_id)]

    component = rng.beta(2.0, 6.0, size=(len(frame), 4)) * 100.0
    weak_mask = np.zeros(len(frame), dtype=bool)
    weak_mask[weak_ids] = True
    risky_mask = np.zeros(len(frame), dtype=bool)
    risky_mask[risky_negative_ids] = True

    for index, name in enumerate(MECHANISM_NAMES[:4]):
        strong = (y == 1) & (mechanism == name) & ~weak_mask
        weak = (y == 1) & (mechanism == name) & weak_mask
        mimic = (y == 0) & (mechanism == name) & risky_mask
        component[strong, index] = rng.beta(6.0, 2.0, strong.sum()) * 100.0
        component[weak, index] = rng.beta(3.0, 3.0, weak.sum()) * 100.0
        component[mimic, index] = rng.beta(5.0, 2.3, mimic.sum()) * 100.0

    multi_strong = (
        (y == 1)
        & (mechanism == "multifactor_interaction")
        & ~weak_mask
    )
    multi_weak = (
        (y == 1)
        & (mechanism == "multifactor_interaction")
        & weak_mask
    )
    multi_mimic = (
        (y == 0)
        & (mechanism == "multifactor_interaction")
        & risky_mask
    )
    component[multi_strong] = 40.0 + rng.beta(
        3.5, 2.3, size=(multi_strong.sum(), 4)
    ) * 45.0
    component[multi_weak] = 25.0 + rng.beta(
        2.5, 3.0, size=(multi_weak.sum(), 4)
    ) * 35.0
    component[multi_mimic] = 35.0 + rng.beta(
        3.0, 2.8, size=(multi_mimic.sum(), 4)
    ) * 45.0
    ordered = np.sort(component, axis=1)
    interaction = np.sqrt(ordered[:, -1] * ordered[:, -2])
    interaction += rng.normal(0.0, 3.0, len(frame))

    result = frame.copy()
    for index, column in enumerate(MECHANISM_FEATURES[:4]):
        result[column] = np.clip(component[:, index], 0, 100).round(6)
    result[MECHANISM_FEATURES[4]] = np.clip(
        interaction, 0, 100
    ).round(6)
    return result


def attenuate_core(
    frame: pd.DataFrame,
    target: pd.Series,
    development_ids: np.ndarray,
    design: dict[str, np.ndarray],
    weak_ids: np.ndarray,
    risky_negative_ids: np.ndarray,
    config: dict,
    seed: int,
) -> tuple[pd.DataFrame, list[dict]]:
    result = frame.copy()
    rng = np.random.default_rng(seed)
    y = target.to_numpy(dtype=np.int8)
    mechanism = design["mechanism"]
    dev_negative_ids = development_ids[y[development_ids] == 0]
    audit_rows = []

    if config["orthogonalize_core_mechanisms"]:
        active_map = {
            "Latent_Clinical_Risk": "clinical_high_risk",
            "Regulatory_Antagonism_Index": "regulatory_deficit",
            "Masked_Admin_Redundancy": "staffing_shortage",
        }
        weak_mask = np.zeros(len(result), dtype=bool)
        weak_mask[weak_ids] = True
        for feature, active_name in active_map.items():
            background_pool = pd.to_numeric(
                frame.loc[dev_negative_ids, feature], errors="coerce"
            ).dropna().to_numpy()
            inactive_positive = (
                (y == 1) & ((mechanism != active_name) | weak_mask)
            )
            ids = np.flatnonzero(inactive_positive)
            result.loc[ids, feature] = rng.choice(
                background_pool, size=len(ids), replace=True
            )

    for feature in CORE_FEATURES:
        dev_values = pd.to_numeric(
            frame.loc[development_ids, feature], errors="coerce"
        ).dropna()
        dev_std = float(dev_values.std(ddof=1))
        dev_min = float(dev_values.min())
        dev_max = float(dev_values.max())
        dev_pool = dev_values.to_numpy()
        dev_negative_pool = pd.to_numeric(
            frame.loc[dev_negative_ids, feature], errors="coerce"
        ).dropna().to_numpy()
        if len(weak_ids):
            result.loc[weak_ids, feature] = rng.choice(
                dev_negative_pool, size=len(weak_ids), replace=True
            )
        replacement_ids = exact_subset(
            np.arange(len(result)), config["replacement_rate"], rng
        )
        if len(replacement_ids):
            result.loc[replacement_ids, feature] = rng.choice(
                dev_pool, size=len(replacement_ids), replace=True
            )
        numeric = pd.to_numeric(result[feature], errors="coerce")
        numeric = numeric + (
            config["noise_sd"]
            * dev_std
            * rng.normal(0.0, 1.0, len(result))
        )
        if config["noise_sd"] > 0 or config["replacement_rate"] > 0:
            clipped_count = int(
                ((numeric < dev_min) | (numeric > dev_max)).sum()
            )
            numeric = numeric.clip(lower=dev_min, upper=dev_max)
        else:
            clipped_count = 0
        result[feature] = numeric

        missing_ids = exact_subset(
            np.arange(len(result)), config["missing_rate"], rng
        )
        if len(missing_ids):
            result.loc[missing_ids, feature] = np.nan
        indicator = f"Missing__{feature}"
        result[indicator] = result[feature].isna().astype("int8")
        audit_rows.append(
            {
                "feature": feature,
                "development_std": dev_std,
                "development_min": dev_min,
                "development_max": dev_max,
                "noise_multiplier": config["noise_sd"],
                "development_bound_clipped_count": clipped_count,
                "random_replacement_count": int(len(replacement_ids)),
                "random_replacement_rate": float(len(replacement_ids) / len(result)),
                "missing_count": int(len(missing_ids)),
                "missing_rate": float(len(missing_ids) / len(result)),
            }
        )

    # High-risk negatives receive one positive-looking mechanism only through
    # the regenerated mechanism scores; they are never relabeled or resampled.
    return result, audit_rows


def main() -> None:
    if not INPUT.exists():
        raise FileNotFoundError(INPUT)
    source = pd.read_csv(INPUT, low_memory=False)
    required = {TARGET, *CORE_FEATURES}
    missing = required - set(source.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    forbidden = [
        column
        for column in source.columns
        if column != TARGET
        and any(term in column.lower() for term in ("fine amount", "penalty date"))
    ]
    if forbidden:
        raise ValueError(f"Forbidden leakage fields present: {forbidden}")

    target = pd.to_numeric(source[TARGET], errors="raise").astype("int8")
    if set(target.unique()) != {0, 1} or not np.isclose(target.mean(), 0.05):
        raise ValueError("Target must remain binary with natural 5% prevalence.")
    split = locked_split(target)
    development_ids = split.loc[
        split["split"].eq("development"), "sample_id"
    ].to_numpy(dtype=int)
    design = shared_simulation_design(target)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    split_path = OUTPUT_DIR / f"{OUTPUT_STEM}_shared_split_manifest.csv"
    split.to_csv(split_path, index=False, encoding="utf-8-sig")
    design_rows = []
    feature_audits = []
    modification_audits = []
    scenario_metadata = {}

    for scenario_index, (scenario, config) in enumerate(SCENARIOS.items()):
        frame = source.copy()
        frame[TARGET] = target
        weak_count = int(round(len(design["positives"]) * config["weak_positive_rate"]))
        risky_count = int(round(len(design["negatives"]) * config["high_risk_negative_rate"]))
        weak_ids = np.sort(design["weak_order"][:weak_count])
        risky_ids = np.sort(design["negative_order"][:risky_count])

        if config["regenerate_mechanisms"]:
            frame = regenerate_mechanism_scores(
                frame,
                target,
                design,
                weak_ids,
                risky_ids,
                RANDOM_STATE + scenario_index * 100,
            )
        frame, audit_rows = attenuate_core(
            frame,
            target,
            development_ids,
            design,
            weak_ids,
            risky_ids,
            config,
            RANDOM_STATE + scenario_index * 1000,
        )
        if len(frame) != len(source) or not frame[TARGET].equals(target):
            raise RuntimeError(f"{scenario}: rows or labels changed.")
        if any(column in frame.columns for column in forbidden):
            raise RuntimeError(f"{scenario}: forbidden field survived.")

        output_path = OUTPUT_DIR / f"{OUTPUT_STEM}_{scenario}.csv"
        frame.to_csv(output_path, index=False, encoding="utf-8-sig")
        for row in audit_rows:
            modification_audits.append({"scenario": scenario, **row})

        weak_set = set(weak_ids.tolist())
        risky_set = set(risky_ids.tolist())
        for sample_id in range(len(frame)):
            mechanism = design["mechanism"][sample_id]
            if sample_id in risky_set:
                negative_position = int(
                    np.flatnonzero(design["negatives"] == sample_id)[0]
                )
                mechanism = design["negative_mechanism"][negative_position]
            design_rows.append(
                {
                    "scenario": scenario,
                    "sample_id": sample_id,
                    "split": split.loc[sample_id, "split"],
                    "y_true": int(target.iloc[sample_id]),
                    "hidden_primary_mechanism": mechanism,
                    "weak_positive": int(sample_id in weak_set),
                    "high_risk_negative": int(sample_id in risky_set),
                    "retained": 1,
                    "include_in_model": 0,
                }
            )

        dev_y = target.iloc[development_ids]
        for feature in CORE_FEATURES + MECHANISM_FEATURES:
            values = pd.to_numeric(
                frame.loc[development_ids, feature], errors="coerce"
            )
            valid = values.notna().to_numpy()
            auc = roc_auc_score(dev_y.to_numpy()[valid], values.to_numpy()[valid])
            directed = values.to_numpy()[valid] if auc >= 0.5 else -values.to_numpy()[valid]
            feature_audits.append(
                {
                    "scenario": scenario,
                    "feature": feature,
                    "development_nonmissing": int(valid.sum()),
                    "development_missing": int((~valid).sum()),
                    "development_AUC_direction_adjusted": float(max(auc, 1 - auc)),
                    "development_PR_AUC_direction_adjusted": float(
                        average_precision_score(dev_y.to_numpy()[valid], directed)
                    ),
                }
            )
        scenario_metadata[scenario] = {
            **config,
            "output_path": str(output_path),
            "output_sha256": sha256(output_path),
            "rows": len(frame),
            "positive_count": int(target.sum()),
            "positive_prevalence": float(target.mean()),
            "weak_positive_count": len(weak_ids),
            "high_risk_negative_count": len(risky_ids),
        }

    modification_path = OUTPUT_DIR / f"{OUTPUT_STEM}_modification_audit.csv"
    pd.DataFrame(modification_audits).to_csv(
        modification_path, index=False, encoding="utf-8-sig"
    )
    feature_path = OUTPUT_DIR / f"{OUTPUT_STEM}_development_feature_audit.csv"
    pd.DataFrame(feature_audits).to_csv(
        feature_path, index=False, encoding="utf-8-sig"
    )
    hidden_path = OUTPUT_DIR / f"{OUTPUT_STEM}_hidden_design_DO_NOT_MODEL.csv"
    pd.DataFrame(design_rows).to_csv(hidden_path, index=False, encoding="utf-8-sig")

    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input_path": str(INPUT),
        "input_sha256": sha256(INPUT),
        "split_first": True,
        "empirical_statistics_scope": "development only",
        "random_seed": RANDOM_STATE,
        "rows_deleted": 0,
        "labels_changed": 0,
        "SMOTE_applied": False,
        "test_resampled": False,
        "scenario_definitions": scenario_metadata,
        "warning": (
            "All three outputs remain semi-synthetic target-conditional "
            "simulation datasets. They are suitable for sensitivity and "
            "stress testing, not real-world effectiveness claims."
        ),
    }
    metadata_path = OUTPUT_DIR / f"{OUTPUT_STEM}_metadata.json"
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Generated scenarios in: {OUTPUT_DIR}")
    for scenario in SCENARIOS:
        item = scenario_metadata[scenario]
        print(
            f"{scenario}: rows={item['rows']:,}; positives={item['positive_count']}; "
            f"weak_positive={item['weak_positive_count']}; "
            f"high_risk_negative={item['high_risk_negative_count']}"
        )
    print(f"Shared split : {split_path}")
    print(f"Modification : {modification_path}")
    print(f"Feature audit: {feature_path}")
    print(f"Hidden design: {hidden_path} (DO NOT MODEL)")
    print(f"Metadata     : {metadata_path}")


if __name__ == "__main__":
    main()
