"""Prepare a leakage-audited real-wide-table dataset for SCI experiments.

The output contains:
1. Real staffing, health-deficiency, quality-measure, claims, organization,
   geography, historical-rating, and inspection-history variables.
2. Three deterministic composite variables derived only from those real
   predictors.
3. Target_Penalty = 1 when Fine Amount > 170734.80, otherwise 0.

Fine Amount and all direct penalty fields are used only to construct the
target and are never exported as predictors.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


TARGET_THRESHOLD = 170734.80

DEFAULT_INPUT_PATH = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据\backup"
    r"\NH_ProviderInfo_Combine(2026.7.22).csv"
)
DEFAULT_OUTPUT_PATH = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Combine.csv"
)


QUALITY_MEASURE_COLUMNS = [
    "Percentage of long-stay residents assessed and appropriately given the pneumococcal vaccine",
    "Percentage of long-stay residents assessed and appropriately given the seasonal influenza vaccine",
    "Percentage of long-stay residents experiencing one or more falls with major injury",
    "Percentage of long-stay residents who have depressive symptoms",
    "Percentage of long-stay residents who lose too much weight",
    "Percentage of long-stay residents who received an antianxiety or hypnotic medication",
    "Percentage of long-stay residents who received an antipsychotic medication",
    "Percentage of long-stay residents who were physically restrained",
    "Percentage of long-stay residents whose ability to walk independently worsened",
    "Percentage of long-stay residents whose need for help with daily activities has increased",
    "Percentage of long-stay residents with a catheter inserted and left in their bladder",
    "Percentage of long-stay residents with a urinary tract infection",
    "Percentage of long-stay residents with new or worsened bowel or bladder incontinence",
    "Percentage of long-stay residents with pressure ulcers",
    "Percentage of short-stay residents assessed and appropriately given the pneumococcal vaccine",
    "Percentage of short-stay residents who newly received an antipsychotic medication",
    "Percentage of short-stay residents who were assessed and appropriately given the seasonal influenza vaccine",
]

BENEFICIAL_QUALITY_COLUMNS = [
    "Percentage of long-stay residents assessed and appropriately given the pneumococcal vaccine",
    "Percentage of long-stay residents assessed and appropriately given the seasonal influenza vaccine",
    "Percentage of short-stay residents assessed and appropriately given the pneumococcal vaccine",
    "Percentage of short-stay residents who were assessed and appropriately given the seasonal influenza vaccine",
]

CLAIMS_COLUMNS = [
    "Claims_Number of hospitalizations per 1000 long-stay resident days",
    "Claims_Number of outpatient emergency department visits per 1000 long-stay resident days",
    "Claims_Percentage of short-stay residents who had an outpatient emergency department visit",
    "Claims_Percentage of short-stay residents who were rehospitalized after a nursing home admission",
]

STAFFING_COLUMNS = [
    "Reported Nurse Aide Staffing Hours per Resident per Day",
    "Reported LPN Staffing Hours per Resident per Day",
    "Reported RN Staffing Hours per Resident per Day",
    "Reported Licensed Staffing Hours per Resident per Day",
    "Reported Total Nurse Staffing Hours per Resident per Day",
    "Total number of nurse staff hours per resident per day on the weekend",
    "Registered Nurse hours per resident per day on the weekend",
    "Reported Physical Therapist Staffing Hours per Resident Per Day",
    "Total nursing staff turnover",
    "Registered Nurse turnover",
    "Number of administrators who have left the nursing home",
    "Nursing Case-Mix Index",
    "Nursing Case-Mix Index Ratio",
    "Case-Mix Nurse Aide Staffing Hours per Resident per Day",
    "Case-Mix LPN Staffing Hours per Resident per Day",
    "Case-Mix RN Staffing Hours per Resident per Day",
    "Case-Mix Total Nurse Staffing Hours per Resident per Day",
    "Case-Mix Weekend Total Nurse Staffing Hours per Resident per Day",
    "Adjusted Nurse Aide Staffing Hours per Resident per Day",
    "Adjusted LPN Staffing Hours per Resident per Day",
    "Adjusted RN Staffing Hours per Resident per Day",
    "Adjusted Total Nurse Staffing Hours per Resident per Day",
    "Adjusted Weekend Total Nurse Staffing Hours per Resident per Day",
]

HEALTH_DEFICIENCY_COLUMNS = [
    "Rating Cycle 1 Total Number of Health Deficiencies",
    "Rating Cycle 1 Number of Standard Health Deficiencies",
    "Rating Cycle 1 Number of Complaint Health Deficiencies",
    "Rating Cycle 1 Health Deficiency Score",
    "Rating Cycle 1 Number of Health Revisits",
    "Rating Cycle 1 Health Revisit Score",
    "Rating Cycle 1 Total Health Score",
    "Rating Cycle 2/3 Total Number of Health Deficiencies",
    "Rating Cycle 2 Number of Standard Health Deficiencies",
    "Rating Cycle 2/3 Number of Complaint Health Deficiencies",
    "Rating Cycle 2/3 Health Deficiency Score",
    "Rating Cycle 2/3 Number of Health Revisits",
    "Rating Cycle 2/3 Health Revisit Score",
    "Rating Cycle 2/3 Total Health Score",
    "Total Weighted Health Survey Score",
    "Number of Citations from Infection Control Inspections",
]

RATING_AND_REGULATORY_COLUMNS = [
    "Overall Rating",
    "Health Inspection Rating",
    "QM Rating",
    "Long-Stay QM Rating",
    "Short-Stay QM Rating",
    "Staffing Rating",
    "Chain Average Overall 5-star Rating",
    "Chain Average Health Inspection Rating",
    "Chain Average Staffing Rating",
    "Chain Average QM Rating",
    "Special Focus Status",
    "Abuse Icon",
    "Most Recent Health Inspection More Than 2 Years Ago",
]

ORGANIZATION_AND_GEOGRAPHY_COLUMNS = [
    "State",
    "Urban",
    "Ownership Type",
    "Provider Type",
    "Provider Resides in Hospital",
    "Continuing Care Retirement Community",
    "Number of Certified Beds",
    "Average Number of Residents per Day",
    "Number of Facilities in Chain",
    "With a Resident and Family Council",
    "Automatic Sprinkler Systems in All Required Areas",
]

DERIVED_HISTORY_COLUMNS = [
    "Provider_Tenure_Days",
    "Days_Since_Rating_Cycle_1_Health_Survey",
    "Days_Since_Rating_Cycle_2_Health_Survey",
]

COMPOSITE_COLUMNS = [
    "Latent_Clinical_Risk",
    "Regulatory_Antagonism_Index",
    "Masked_Admin_Redundancy",
]

DIRECT_LEAKAGE_COLUMNS = [
    "Fine Amount",
    "Penalty Date",
    "Number of Fines",
    "Total Amount of Fines in Dollars",
    "Number of Payment Denials",
    "Total Number of Penalties",
]

IDENTIFIER_COLUMNS = [
    "CMS Certification Number (CCN)",
    "Provider Name",
    "Provider Address",
    "City/Town",
    "ZIP Code",
    "Telephone Number",
    "County/Parish",
    "Legal Business Name",
    "Chain Name",
    "Chain ID",
    "Location",
    "Latitude",
    "Longitude",
]


def _as_numeric(frame: pd.DataFrame, column: str) -> pd.Series:
    return pd.to_numeric(frame[column], errors="coerce")


def _bounded_component(
    frame: pd.DataFrame,
    column: str,
    lower: float,
    upper: float,
    *,
    inverse: bool = False,
) -> pd.Series:
    """Map a real variable to a fixed 0-1 risk scale without using labels."""

    values = _as_numeric(frame, column)
    component = ((values - lower) / (upper - lower)).clip(0.0, 1.0)
    return 1.0 - component if inverse else component


def _yes_component(frame: pd.DataFrame, column: str) -> pd.Series:
    values = frame[column].astype("string").str.strip().str.lower()
    mapping = {
        "yes": 1.0,
        "y": 1.0,
        "true": 1.0,
        "1": 1.0,
        "no": 0.0,
        "n": 0.0,
        "false": 0.0,
        "0": 0.0,
    }
    return values.map(mapping).astype(float)


def _mean_index(
    components: list[pd.Series],
    *,
    minimum_observed: int,
) -> pd.Series:
    """Return a 0-100 row mean only when enough source components are observed."""

    matrix = pd.concat(components, axis=1)
    index = matrix.mean(axis=1, skipna=True) * 100.0
    index.loc[matrix.notna().sum(axis=1) < minimum_observed] = np.nan
    return index.round(6)


def _validate_columns(frame: pd.DataFrame, required: list[str]) -> None:
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise ValueError(
            "The real-wide-table source is missing required columns:\n- "
            + "\n- ".join(missing)
        )


def _add_history_features(frame: pd.DataFrame) -> pd.DataFrame:
    processing_date = pd.to_datetime(frame["Processing Date"], errors="coerce")
    approved_date = pd.to_datetime(
        frame["Date First Approved to Provide Medicare and Medicaid Services"],
        errors="coerce",
    )
    cycle_1_date = pd.to_datetime(
        frame["Rating Cycle 1 Standard Survey Health Date"],
        errors="coerce",
    )
    cycle_2_date = pd.to_datetime(
        frame["Rating Cycle 2 Standard Health Survey Date"],
        errors="coerce",
    )

    frame["Provider_Tenure_Days"] = (processing_date - approved_date).dt.days
    frame["Days_Since_Rating_Cycle_1_Health_Survey"] = (
        processing_date - cycle_1_date
    ).dt.days
    frame["Days_Since_Rating_Cycle_2_Health_Survey"] = (
        processing_date - cycle_2_date
    ).dt.days

    for column in DERIVED_HISTORY_COLUMNS:
        frame.loc[frame[column] < 0, column] = np.nan
    return frame


def _add_composite_features(frame: pd.DataFrame) -> pd.DataFrame:
    """Construct three transparent indices without target-dependent randomness."""

    clinical_components: list[pd.Series] = []
    for column in QUALITY_MEASURE_COLUMNS:
        clinical_components.append(
            _bounded_component(
                frame,
                column,
                0.0,
                100.0,
                inverse=column in BENEFICIAL_QUALITY_COLUMNS,
            )
        )

    clinical_components.extend(
        [
            _bounded_component(frame, CLAIMS_COLUMNS[0], 0.0, 10.0),
            _bounded_component(frame, CLAIMS_COLUMNS[1], 0.0, 15.0),
            _bounded_component(frame, CLAIMS_COLUMNS[2], 0.0, 50.0),
            _bounded_component(frame, CLAIMS_COLUMNS[3], 0.0, 60.0),
            _bounded_component(frame, "Nursing Case-Mix Index", 0.7, 3.0),
            _bounded_component(frame, "Nursing Case-Mix Index Ratio", 0.5, 2.5),
        ]
    )
    frame["Latent_Clinical_Risk"] = _mean_index(
        clinical_components,
        minimum_observed=6,
    )

    regulatory_components = [
        _bounded_component(
            frame,
            "Rating Cycle 1 Total Number of Health Deficiencies",
            0.0,
            100.0,
        ),
        _bounded_component(
            frame,
            "Rating Cycle 1 Number of Standard Health Deficiencies",
            0.0,
            60.0,
        ),
        _bounded_component(
            frame,
            "Rating Cycle 1 Number of Complaint Health Deficiencies",
            0.0,
            60.0,
        ),
        _bounded_component(
            frame, "Rating Cycle 1 Health Deficiency Score", 0.0, 1000.0
        ),
        _bounded_component(
            frame, "Rating Cycle 1 Number of Health Revisits", 0.0, 5.0
        ),
        _bounded_component(
            frame,
            "Rating Cycle 2/3 Total Number of Health Deficiencies",
            0.0,
            120.0,
        ),
        _bounded_component(
            frame,
            "Rating Cycle 2/3 Number of Complaint Health Deficiencies",
            0.0,
            100.0,
        ),
        _bounded_component(
            frame, "Rating Cycle 2/3 Health Deficiency Score", 0.0, 1500.0
        ),
        _bounded_component(
            frame, "Rating Cycle 2/3 Number of Health Revisits", 0.0, 5.0
        ),
        _bounded_component(
            frame, "Total Weighted Health Survey Score", 0.0, 2500.0
        ),
        _bounded_component(
            frame,
            "Number of Citations from Infection Control Inspections",
            0.0,
            20.0,
        ),
        _bounded_component(
            frame, "Health Inspection Rating", 1.0, 5.0, inverse=True
        ),
        _bounded_component(frame, "Overall Rating", 1.0, 5.0, inverse=True),
        _yes_component(frame, "Special Focus Status"),
        _yes_component(frame, "Abuse Icon"),
        _yes_component(
            frame, "Most Recent Health Inspection More Than 2 Years Ago"
        ),
    ]
    frame["Regulatory_Antagonism_Index"] = _mean_index(
        regulatory_components,
        minimum_observed=5,
    )

    reported_total = _as_numeric(
        frame, "Reported Total Nurse Staffing Hours per Resident per Day"
    )
    adjusted_total = _as_numeric(
        frame, "Adjusted Total Nurse Staffing Hours per Resident per Day"
    )
    staffing_gap = (
        (reported_total - adjusted_total).abs()
        / reported_total.abs().replace(0.0, np.nan)
    ).clip(0.0, 1.0)

    admin_components = [
        _bounded_component(
            frame, "Total nursing staff turnover", 0.0, 100.0
        ),
        _bounded_component(frame, "Registered Nurse turnover", 0.0, 100.0),
        _bounded_component(
            frame,
            "Number of administrators who have left the nursing home",
            0.0,
            5.0,
        ),
        _bounded_component(
            frame,
            "Reported Total Nurse Staffing Hours per Resident per Day",
            0.0,
            8.0,
            inverse=True,
        ),
        _bounded_component(
            frame,
            "Total number of nurse staff hours per resident per day on the weekend",
            0.0,
            8.0,
            inverse=True,
        ),
        _bounded_component(
            frame,
            "Reported RN Staffing Hours per Resident per Day",
            0.0,
            2.0,
            inverse=True,
        ),
        _bounded_component(
            frame,
            "Adjusted Total Nurse Staffing Hours per Resident per Day",
            0.0,
            8.0,
            inverse=True,
        ),
        _bounded_component(
            frame,
            "Adjusted Weekend Total Nurse Staffing Hours per Resident per Day",
            0.0,
            8.0,
            inverse=True,
        ),
        _bounded_component(
            frame, "Staffing Rating", 1.0, 5.0, inverse=True
        ),
        staffing_gap,
    ]
    frame["Masked_Admin_Redundancy"] = _mean_index(
        admin_components,
        minimum_observed=4,
    )
    return frame


def _build_feature_manifest(output_columns: list[str]) -> pd.DataFrame:
    categories: dict[str, str] = {}
    for column in QUALITY_MEASURE_COLUMNS:
        categories[column] = "Quality measures"
    for column in CLAIMS_COLUMNS:
        categories[column] = "Claims history"
    for column in STAFFING_COLUMNS:
        categories[column] = "Staffing"
    for column in HEALTH_DEFICIENCY_COLUMNS:
        categories[column] = "Health deficiencies / inspection history"
    for column in RATING_AND_REGULATORY_COLUMNS:
        categories[column] = "Historical ratings / regulatory history"
    for column in ORGANIZATION_AND_GEOGRAPHY_COLUMNS:
        categories[column] = "Ownership / provider type / geography"
    for column in DERIVED_HISTORY_COLUMNS:
        categories[column] = "Derived historical timing"
    categories["SSA_Region_Code"] = "State and regional variables"
    categories["Target_Penalty"] = "Outcome"
    for column in COMPOSITE_COLUMNS:
        categories[column] = "Derived real-data composite"

    return pd.DataFrame(
        {
            "column": output_columns,
            "feature_group": [categories[column] for column in output_columns],
            "role": [
                "target"
                if column == "Target_Penalty"
                else "derived_feature"
                if column in COMPOSITE_COLUMNS or column in DERIVED_HISTORY_COLUMNS
                else "raw_real_feature"
                for column in output_columns
            ],
        }
    )


def generate_methodology_dataset(
    input_path: str | Path = DEFAULT_INPUT_PATH,
    output_path: str | Path = DEFAULT_OUTPUT_PATH,
) -> pd.DataFrame:
    input_path = Path(input_path)
    output_path = Path(output_path)
    print("--- Preparing leakage-audited real-wide-table experiment data ---")
    print(f"Input : {input_path}")
    print(f"Output: {output_path}")

    if not input_path.exists():
        raise FileNotFoundError(f"Input data not found: {input_path}")

    frame = pd.read_csv(input_path, low_memory=False)
    required_source_columns = (
        ["Fine Amount", "Provider SSA County Code"]
        + QUALITY_MEASURE_COLUMNS
        + CLAIMS_COLUMNS
        + STAFFING_COLUMNS
        + HEALTH_DEFICIENCY_COLUMNS
        + RATING_AND_REGULATORY_COLUMNS
        + ORGANIZATION_AND_GEOGRAPHY_COLUMNS
        + [
            "Processing Date",
            "Date First Approved to Provide Medicare and Medicaid Services",
            "Rating Cycle 1 Standard Survey Health Date",
            "Rating Cycle 2 Standard Health Survey Date",
        ]
    )
    _validate_columns(frame, required_source_columns)

    fine_amount = pd.to_numeric(frame["Fine Amount"], errors="coerce").fillna(0.0)
    frame["Target_Penalty"] = (
        fine_amount > TARGET_THRESHOLD
    ).astype("int8")

    frame["SSA_Region_Code"] = (
        pd.to_numeric(frame["Provider SSA County Code"], errors="coerce")
        .round()
        .astype("Int64")
        .astype("string")
        .str.zfill(3)
        .radd("SSA_")
    )

    frame = _add_history_features(frame)
    frame = _add_composite_features(frame)

    real_feature_columns = list(
        dict.fromkeys(
            QUALITY_MEASURE_COLUMNS
            + CLAIMS_COLUMNS
            + STAFFING_COLUMNS
            + HEALTH_DEFICIENCY_COLUMNS
            + RATING_AND_REGULATORY_COLUMNS
            + ORGANIZATION_AND_GEOGRAPHY_COLUMNS
            + ["SSA_Region_Code"]
            + DERIVED_HISTORY_COLUMNS
        )
    )
    output_columns = (
        ["Target_Penalty"] + COMPOSITE_COLUMNS + real_feature_columns
    )
    result = frame[output_columns].copy()

    leaked = sorted(set(result.columns) & set(DIRECT_LEAKAGE_COLUMNS))
    identifiers = sorted(set(result.columns) & set(IDENTIFIER_COLUMNS))
    if leaked or identifiers:
        raise RuntimeError(
            f"Leakage audit failed. Direct leakage={leaked}; identifiers={identifiers}"
        )

    if result["Target_Penalty"].nunique() != 2:
        raise ValueError("Target_Penalty must contain both classes.")
    expected_target = (fine_amount > TARGET_THRESHOLD).astype("int8")
    if not result["Target_Penalty"].equals(expected_target):
        raise RuntimeError("Target_Penalty does not match the fixed threshold.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False, encoding="utf-8-sig")

    manifest_path = output_path.with_name(
        f"{output_path.stem}_feature_manifest.csv"
    )
    manifest = _build_feature_manifest(output_columns)
    manifest.to_csv(manifest_path, index=False, encoding="utf-8-sig")

    metadata = {
        "input_path": str(input_path),
        "output_path": str(output_path),
        "rows": int(len(result)),
        "columns": int(result.shape[1]),
        "target_definition": f"Fine Amount > {TARGET_THRESHOLD:.2f}",
        "positive_count": int(result["Target_Penalty"].sum()),
        "negative_count": int((result["Target_Penalty"] == 0).sum()),
        "positive_prevalence": float(result["Target_Penalty"].mean()),
        "real_feature_count": int(len(real_feature_columns)),
        "composite_features": COMPOSITE_COLUMNS,
        "excluded_direct_leakage_columns": DIRECT_LEAKAGE_COLUMNS,
        "excluded_identifier_columns": IDENTIFIER_COLUMNS,
        "label_flipping_applied": False,
        "target_dependent_feature_generation": False,
    }
    metadata_path = output_path.with_name(
        f"{output_path.stem}_preparation_metadata.json"
    )
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(
        f"Rows={len(result):,}; columns={result.shape[1]}; "
        f"positive={metadata['positive_count']:,} "
        f"({metadata['positive_prevalence']:.2%})"
    )
    print(f"Feature manifest: {manifest_path}")
    print(f"Metadata        : {metadata_path}")
    print("--- Real-wide-table experiment data generated successfully ---")
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate real-wide-table experiment data without target leakage."
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT_PATH)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT_PATH)
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    generate_methodology_dataset(arguments.input, arguments.output)
