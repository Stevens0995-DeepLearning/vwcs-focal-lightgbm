import hashlib,json,time,sys,warnings
from pathlib import Path
import numpy as np,pandas as pd,lightgbm as lgb
from scipy.special import expit
base=Path(r'C:/ASQ备考/博士论文/西藏项目/Main coding')
sys.path.insert(0,str(base))
from ablation_data import DEFAULT_DATA,load_data_and_splits,split_manifest
from ablation_models import FOCAL,FOCAL_BASE_KWARGS,focal_eval
from run_ablation import MAX_ROUNDS,platt_predict,score_predictions
out=Path('r5_qa');out.mkdir(exist_ok=True)
def deriv(z,y,w,gam):
    s=2*y-1; logq=-np.logaddexp(0,-s*z); q=expit(s*z); r=expit(-s*z)
    A=gam*q*logq-r
    return -w*r**gam*logq,s*w*r**gam*A,w*q*r**gam*(r*(gam*logq+gam+1)-gam*A)
z,y,w,gam=np.meshgrid(np.log(np.array([.001,.01,.1,.5,.9,.99,.999])/(1-np.array([.001,.01,.1,.5,.9,.99,.999]))),[0,1],[.1,.9,1,1.8],[0,.25,1],indexing='ij')
_,g,h=deriv(z,y,w,gam);fd=[]
for e in [.001,.0001,.00001]:
    L1,g1,_=deriv(z+e,y,w,gam);L0,g0,_=deriv(z-e,y,w,gam)
    fd.append([e,np.max(abs((L1-L0)/(2*e)-g)),np.max(abs((g1-g0)/(2*e)-h))])
pd.DataFrame(fd,columns=['step','g_error','h_error']).to_csv(out/'derivatives.csv',index=False)
r=base/'logs/Revision2_Vi_20261110';proto=json.loads((r/'protocol.json').read_text('utf8'))
assert hashlib.sha256(DEFAULT_DATA.read_bytes()).hexdigest()==proto['dataset_sha256'][str(DEFAULT_DATA)]
X,y,S=load_data_and_splits();assert split_manifest(S)==proto['splits']
a=pd.read_csv(r/'vulnerability_auxiliary.csv',float_precision='round_trip').set_index('sample_id')
assert a.index.equals(y.index) and np.array_equal(a.y_true,y)
tr=S['train'][0].index;xt,yt=S['tune'];xc,yc=S['calibration'];xe,ye=S['test'];rf=np.r_[tr,xt.index]
old=pd.read_csv(r/'paired_predictions.csv',float_precision='round_trip').set_index('sample_id').loc[xe.index]
def weights(idx):return np.where(y.loc[idx].to_numpy()==1,.9*(1+a.loc[idx,'V_i'].to_numpy()),.1)
legacy=FOCAL['focal_loss_custom'](.9,.25,'bce_proxy')
rows=[];pred=pd.DataFrame({'y':ye})
for arm in ['H1','H2','H3','H4']:
    def model(idx,n):
        w=weights(idx); lab=y.loc[idx].to_numpy();counter=np.zeros(3,dtype='int64')
        def obj(label,z):
            assert np.array_equal(label,lab)
            p=np.clip(expit(z),1e-6,1-1e-6);q=np.where(lab==1,p,1-p);rr=1-q
            ex=w*q*rr**.25*(rr*(.25*np.log(q)+1.25)-.25*(.25*q*np.log(q)-rr))
            g=legacy(label,z)[0]*w/np.where(lab==1,.9,.1)
            hv={'H1':w*p*(1-p),'H2':ex,'H3':w*rr**.25*p*(1-p),'H4':p*(1-p)}[arm]
            assert np.isfinite(z).all() and np.isfinite(hv).all() and np.isfinite(g).all()
            counter[:]+=[len(lab),(ex<0).sum(),(hv<1e-5).sum()]
            return g,np.maximum(hv,1e-5)
        return FOCAL['FocalLossLGBM'](**{**FOCAL_BASE_KWARGS,'n_estimators':int(n),'n_jobs':2},objective=obj),counter
    t=time.perf_counter()
    m,_=model(tr,MAX_ROUNDS);m.fit(X.loc[tr],y.loc[tr],eval_set=[(xt,yt)],eval_metric=focal_eval(),callbacks=[lgb.early_stopping(100,first_metric_only=True,verbose=False)])
    it=m.best_iteration_ or MAX_ROUNDS
    z=m.booster_.predict(xt,raw_score=True,num_iteration=it,num_threads=2)
    loss=deriv(z,yt.to_numpy(),weights(xt.index),.25)[0].mean()
    f,c=model(rf,it);f.fit(X.loc[rf],y.loc[rf]);elapsed=time.perf_counter()-t
    raw,q,_=platt_predict(f,xc,yc,xe)
    if arm=='H1':assert np.allclose(q,old.B_calibrated,atol=1e-9,rtol=0) and np.allclose(raw,old.B_raw_probability,atol=1e-9,rtol=0)
    pred[arm+'_raw']=raw;pred[arm+'_q']=q
    hp=a.loc[xe.index,'high_V'].eq(1)&ye.eq(1)
    rows.append(dict(arm=arm,it=it,loss=loss,seconds=elapsed,neg=c[1]/c[0],floor=c[2]/c[0],high_fn=int((hp&(q<.2)).sum()),**score_predictions(ye,raw,q)))
    pd.DataFrame(rows).to_csv(out/'curvature.csv',index=False);pred.to_csv(out/'predictions.csv');print(rows[-1],flush=True)
