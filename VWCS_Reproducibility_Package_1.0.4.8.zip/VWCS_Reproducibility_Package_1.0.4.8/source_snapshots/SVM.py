import os
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    fbeta_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from evaluation_utils import (
    append_best_threshold_output,
    platt_calibrate_probabilities,
)
from sci_artifact_export import export_model_sci_artifacts


def prepare_data(file_path):
    """按照Logistic Regression脚本的方式准备SVM输入数据。"""
    print(f"正在读取数据并准备特征空间: {file_path}")

    df = pd.read_csv(file_path)

    if "Target_Penalty" not in df.columns:
        raise ValueError("数据集中未找到 'Target_Penalty' 列！")

    y = df["Target_Penalty"]
    pos_ratio = y.mean()
    print(f"[标签分布] 正类 (Target=1) 占比: {pos_ratio:.2%}")

    X = df.drop(columns=["Target_Penalty"])

    numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()

    known_cats = ["State", "Ownership Type", "Provider Type"]
    for col in known_cats:
        if col in numeric_cols:
            numeric_cols.remove(col)
            categorical_cols.append(col)

    X[numeric_cols] = X[numeric_cols].fillna(X[numeric_cols].median())
    for col in categorical_cols:
        if col in X.columns:
            mode = X[col].mode(dropna=True)
            fill_value = mode.iloc[0] if not mode.empty else "Missing"
            X[col] = X[col].fillna(fill_value)

    print("\n[数据处理] 正在执行与Logistic Regression相同的分箱和观测噪声处理...")

    features_to_bin = [
        "Latent_Clinical_Risk",
        "Regulatory_Antagonism_Index",
    ]
    for col in features_to_bin:
        if col in X.columns:
            X[col] = pd.qcut(
                X[col], q=5, labels=False, duplicates="drop"
            ).astype("float32")
            print(f"  -> 已对特征 {col} 进行5档等频分箱。")

    features_to_noise = [
        "Masked_Admin_Redundancy",
        "Reported Total Nurse Staffing Hours per Resident per Day",
    ]
    for col in features_to_noise:
        if col in X.columns:
            noise_std = X[col].std() * 0.3
            np.random.seed(42)
            noise = np.random.normal(
                loc=0.0, scale=noise_std, size=X[col].shape
            )
            X[col] = (X[col] + noise).astype("float32")
            print(f"  -> 已对特征 {col} 注入30% STD高斯观测误差。")

    X = pd.get_dummies(X, columns=categorical_cols, drop_first=True)

    scaler = StandardScaler()
    X[numeric_cols] = scaler.fit_transform(X[numeric_cols])
    X = X.astype("float32")

    print(f"\n[特征工程] SVM预处理完成。最终特征维度: {X.shape[1]}\n")
    return X, y


def evaluate_and_log(
    model_name,
    y_test,
    y_probs,
    thresholds,
    log_file,
    ranking_probs=None,
):
    """计算指标并写入实验日志。"""
    results = []
    if ranking_probs is None:
        ranking_probs = y_probs

    pr_auc = average_precision_score(y_test, ranking_probs)
    roc_auc = roc_auc_score(y_test, ranking_probs)
    brier = brier_score_loss(y_test, y_probs)

    with open(log_file, "a", encoding="utf-8") as file:
        file.write(f"\n{'=' * 60}\n")
        file.write(f"模型: {model_name}\n")
        file.write("【全局概率评估指标 (阈值无关)】\n")
        file.write(f"  - PR-AUC     (核心识别能力)    : {pr_auc:.4f}\n")
        file.write(f"  - ROC-AUC    (行业基准对齐)    : {roc_auc:.4f}\n")
        file.write(f"  - Brier Score(概率校准误差，越低越好): {brier:.4f}\n")
        file.write(f"{'-' * 60}\n")
        file.write("【不同行政监管阈值下的治理效能评估】\n")
        file.write(
            f"{'阈值':<8} | {'Recall(安全)':<12} | "
            f"{'Precision(效率)':<15} | {'FPR(行政冗余)':<14} | "
            f"{'F-beta(综合)':<12}\n"
        )
        file.write(f"{'-' * 75}\n")

        for threshold in thresholds:
            y_pred = (y_probs >= threshold).astype(int)
            recall = recall_score(y_test, y_pred, zero_division=0)
            precision = precision_score(y_test, y_pred, zero_division=0)
            fbeta = fbeta_score(
                y_test, y_pred, beta=2, zero_division=0
            )
            tn, fp, fn, tp = confusion_matrix(
                y_test, y_pred, labels=[0, 1]
            ).ravel()
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

            file.write(
                f"{threshold:<10.2f} | {recall:<14.4f} | "
                f"{precision:<17.4f} | {fpr:<16.4f} | "
                f"{fbeta:<14.4f}\n"
            )
            results.append(
                {
                    "Model": model_name,
                    "Threshold": threshold,
                    "Recall": recall,
                    "Precision": precision,
                    "FPR": fpr,
                    "F-beta": fbeta,
                }
            )

    results.append(
        append_best_threshold_output(
            model_name,
            y_test,
            y_probs,
            log_file,
            best_threshold=0.2,
        )
    )
    print(
        f"[{model_name}] 评估完成: ROC-AUC={roc_auc:.4f}, "
        f"PR-AUC={pr_auc:.4f}, Brier={brier:.4f}"
    )
    return results


def run_experiment(X, y, log_dir, data_file=None):
    """训练SVM并生成日志和SCI绘图数据。"""
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(
        log_dir, f"experiment_log_{timestamp}_SVM.txt"
    )
    artifact_dir = os.path.join(
        log_dir, "sci_model_outputs", "svm", timestamp
    )

    X_temp, X_test, y_temp, y_test = train_test_split(
        X,
        y,
        test_size=0.1,
        random_state=42,
        stratify=y,
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_temp,
        y_temp,
        test_size=0.2222,
        random_state=42,
        stratify=y_temp,
    )

    with open(log_file, "w", encoding="utf-8") as file:
        file.write(
            "Nursing Home 监管预测模型 (SVM) 实验报告 - "
            f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        )
        file.write(
            "目标定义: 极度不平衡模型 "
            "(罚款金额 > $170,734.80, Target=1)\n"
        )
        file.write(
            f"划分比例: 训练集 {X_train.shape[0]}, "
            f"验证集 {X_val.shape[0]}, 测试集 {X_test.shape[0]}\n"
        )

    model_name = "SVM"
    model = SVC(
        C=1.0,
        kernel="rbf",
        gamma="scale",
        probability=True,
        random_state=42,
        cache_size=1024,
    )

    print("\n============================================================")
    print(f"开始训练与评估模型: {model_name}")
    model.fit(X_train, y_train)

    thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]
    y_probs_val_raw = model.predict_proba(X_val)[:, 1]
    y_probs_test_raw = model.predict_proba(X_test)[:, 1]
    y_probs_test_calibrated, _ = platt_calibrate_probabilities(
        y_val,
        y_probs_val_raw,
        y_probs_test_raw,
    )

    evaluate_and_log(
        model_name,
        y_test,
        y_probs_test_calibrated,
        thresholds,
        log_file,
        ranking_probs=y_probs_test_raw,
    )

    export_model_sci_artifacts(
        artifact_dir=artifact_dir,
        model_key="svm",
        model_name=model_name,
        data_file=data_file,
        X=X,
        y=y,
        X_train=X_train,
        y_train=y_train,
        X_validation=X_val,
        y_validation=y_val,
        X_test=X_test,
        y_test=y_test,
        y_prob_raw=y_probs_test_raw,
        y_prob_calibrated=y_probs_test_calibrated,
        calibration="Platt/Sigmoid fitted on validation split",
        preprocessing={
            "pipeline": "SVM feature encoding and scaling",
            "scope": "as implemented before splitting",
        },
        resampling="none",
        model_parameters={
            "C": 1.0,
            "kernel": "rbf",
            "gamma": "scale",
            "probability": True,
        },
    )

    with open(log_file, "a", encoding="utf-8") as file:
        file.write(f"\nSCI绘图数据包: {artifact_dir}\n")

    return log_file, artifact_dir


def main():
    print("--- 启动研究项目：Nursing Home 监管预测模型 (SVM) ---")

    data_file = (
        r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
        r"\NH_ProviderInfo_Combine.csv"
    )
    log_dir = r"C:\ASQ备考\博士论文\西藏项目\Main coding\logs"

    if not os.path.exists(data_file):
        print(f"错误：找不到文件 -> {data_file}")
        return

    X, y = prepare_data(data_file)
    run_experiment(X, y, log_dir, data_file=data_file)
    print("--- 实验流程结束，请前往 logs 文件夹查看效能表 ---")


if __name__ == "__main__":
    main()
