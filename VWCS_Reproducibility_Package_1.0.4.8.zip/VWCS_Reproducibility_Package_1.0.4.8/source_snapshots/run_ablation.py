"""Run the locked 2x2 LightGBM component ablation and external baselines.

Usage: python run_ablation.py [--data PATH] [--output PATH]
Outputs are versioned below ``logs/Ablation experiment``; test labels are used
only after fitting, hyperparameter/iteration choice, and calibration are fixed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
import sklearn
from scipy.special import expit
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    fbeta_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from ablation_data import (
    BASELINE_SOURCE,
    DEFAULT_DATA,
    FOCAL_SOURCE,
    load_data_and_splits,
    source_sha256,
    split_manifest,
)
from ablation_models import (
    ALPHA_ASYMMETRIC,
    FACTORIAL_ARMS,
    FOCAL_BASE_KWARGS,
    GAMMA_GRID,
    SMOTE_BASE_KWARGS,
    SMOTE_SOURCE,
    focal_eval,
    make_focal_model,
    make_legacy_baseline,
    make_smote_baseline,
    make_smote_sampler,
)


DEFAULT_OUTPUT = Path(__file__).resolve().parent / "logs" / "Ablation experiment"
LOCKED_THRESHOLD = 0.20
MAX_ROUNDS = int(FOCAL_BASE_KWARGS["n_estimators"])


def score_predictions(y, raw, calibrated, threshold=LOCKED_THRESHOLD):
    truth = np.asarray(y, dtype=int)
    raw = np.asarray(raw, dtype=float)
    calibrated = np.asarray(calibrated, dtype=float)
    if not (np.isfinite(raw).all() and np.isfinite(calibrated).all()):
        raise ValueError("Predictions contain a nonfinite value")
    if np.any(calibrated < 0) or np.any(calibrated > 1):
        raise ValueError("Calibrated probabilities must lie in [0, 1]")
    pred = (calibrated >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(truth, pred, labels=[0, 1]).ravel()
    return {
        "pr_auc": float(average_precision_score(truth, raw)),
        "roc_auc": float(roc_auc_score(truth, raw)),
        "brier": float(brier_score_loss(truth, calibrated)),
        "recall": float(recall_score(truth, pred, zero_division=0)),
        "precision": float(precision_score(truth, pred, zero_division=0)),
        "fpr": float(fp / (fp + tn)),
        "f2": float(fbeta_score(truth, pred, beta=2, zero_division=0)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


def tune_focal(X_train, y_train, X_tune, y_tune, alpha, gamma):
    model = make_focal_model(alpha, gamma, MAX_ROUNDS)
    model.fit(
        X_train,
        y_train,
        eval_set=[(X_tune, y_tune)],
        eval_metric=focal_eval(),
        callbacks=[lgb.early_stopping(
            stopping_rounds=100, first_metric_only=True, verbose=False
        )],
    )
    tune_raw = model.predict_proba(X_tune)[:, 1]
    iteration = int(getattr(model, "best_iteration_", 0) or MAX_ROUNDS)
    return {
        "alpha": float(alpha),
        "gamma": float(gamma),
        "best_iteration": iteration,
        "tune_pr_auc": float(average_precision_score(y_tune, tune_raw)),
        "tune_roc_auc": float(roc_auc_score(y_tune, tune_raw)),
    }


def platt_predict(model, X_cal, y_cal, X_test):
    """Reuse the exact Platt estimator and raw-margin mapping of Focal Final."""
    cal_margin = np.asarray(model.booster_.predict(X_cal, raw_score=True))
    test_margin = np.asarray(model.booster_.predict(X_test, raw_score=True))
    calibrator = LogisticRegression(
        C=1e6, solver="lbfgs", max_iter=2000, random_state=42
    )
    calibrator.fit(cal_margin.reshape(-1, 1), y_cal)
    calibrated = calibrator.predict_proba(test_margin.reshape(-1, 1))[:, 1]
    return expit(test_margin), calibrated, {
        "coefficient": float(calibrator.coef_[0, 0]),
        "intercept": float(calibrator.intercept_[0]),
        "calibration_brier_raw": float(brier_score_loss(y_cal, expit(cal_margin))),
        "calibration_brier_mapped": float(brier_score_loss(
            y_cal, calibrator.predict_proba(cal_margin.reshape(-1, 1))[:, 1]
        )),
    }


def smote_numeric_representation(X_fit, X_cal, X_test):
    """Fit all imputation/encoding statistics on development rows only.

    The historical SMOTE script performs its transformations before splitting
    and injects a synthetic perturbation.  Neither action is admissible in a
    controlled ablation; only its sampler and estimator are reused unchanged.
    """
    numeric = X_fit.select_dtypes(include=[np.number, "bool"]).columns.tolist()
    categorical = [c for c in X_fit.columns if c not in numeric]
    transform = ColumnTransformer(
        [
            ("numeric", Pipeline([
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
            ]), numeric),
            ("categorical", Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
            ]), categorical),
        ],
        sparse_threshold=0,
    )
    fit = transform.fit_transform(X_fit)
    cal = transform.transform(X_cal)
    test = transform.transform(X_test)
    return fit.astype(np.float32), cal.astype(np.float32), test.astype(np.float32), {
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "encoded_feature_count": int(fit.shape[1]),
    }


def save_model_result(out, key, label, family, X_test, y_test,
                      raw, calibrated, calibration_info, extra):
    frame = pd.DataFrame({
        "sample_id": np.asarray(X_test.index, dtype=np.int64),
        "y_true": np.asarray(y_test, dtype=np.int8),
        "y_prob_raw": raw,
        "y_prob_calibrated": calibrated,
        "y_pred_020": (calibrated >= LOCKED_THRESHOLD).astype(np.int8),
    })
    frame.to_csv(out / f"predictions_{key}.csv", index=False, float_format="%.12g")
    return {
        "model_key": key,
        "model": label,
        "family": family,
        "threshold": LOCKED_THRESHOLD,
        **score_predictions(y_test, raw, calibrated),
        "calibration": calibration_info,
        **extra,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    X, y, splits = load_data_and_splits(args.data)
    X_train, y_train = splits["train"]
    X_tune, y_tune = splits["tune"]
    X_cal, y_cal = splits["calibration"]
    X_test, y_test = splits["test"]
    X_fit = pd.concat((X_train, X_tune))
    y_fit = pd.concat((y_train, y_tune))
    run_name = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = args.output / run_name
    out.mkdir(parents=True, exist_ok=False)
    print(f"Ablation output: {out}", flush=True)

    # Freeze the selected alpha/gamma values from the existing Focal run.
    # All 2x2 cells use the very same custom objective and estimator settings.
    tune_cache = {}
    for arm in FACTORIAL_ARMS:
        print(f"Tuning {arm.label}", flush=True)
        tune_cache[(arm.alpha, arm.gamma)] = tune_focal(
            X_train, y_train, X_tune, y_tune, arm.alpha, arm.gamma
        )
    gamma_rows = []
    for gamma in GAMMA_GRID:
        pair = (ALPHA_ASYMMETRIC, gamma)
        if pair not in tune_cache:
            print(f"Gamma sensitivity: gamma={gamma}", flush=True)
            tune_cache[pair] = tune_focal(
                X_train, y_train, X_tune, y_tune, *pair
            )
        gamma_rows.append(tune_cache[pair])
    pd.DataFrame(gamma_rows).to_csv(out / "gamma_sensitivity_tune.csv", index=False)

    results = []
    for arm in FACTORIAL_ARMS:
        tuned = tune_cache[(arm.alpha, arm.gamma)]
        print(f"Refitting {arm.label}: {tuned['best_iteration']} trees", flush=True)
        model = make_focal_model(arm.alpha, arm.gamma, tuned["best_iteration"])
        model.fit(X_fit, y_fit)
        raw, mapped, calibration_info = platt_predict(model, X_cal, y_cal, X_test)
        results.append(save_model_result(
            out, arm.key, arm.label, "controlled_2x2", X_test, y_test,
            raw, mapped, calibration_info, {**tuned, "focal_hessian": "bce_proxy"}
        ))

    # Exact legacy baseline training/evaluation route. It is an external
    # reference row, not a cell of the controlled 2x2: the source script uses
    # train only, tune for early stopping, and explicitly does not calibrate.
    print("Fitting original LightGBM Baseline estimator", flush=True)
    baseline = make_legacy_baseline()
    baseline.fit(
        X_train, y_train,
        eval_set=[(X_tune, y_tune)],
        eval_metric="average_precision",
        callbacks=[lgb.early_stopping(
            stopping_rounds=100, first_metric_only=True, verbose=False
        )],
    )
    raw = baseline.predict_proba(X_test)[:, 1]
    mapped = raw.copy()
    calibration_info = {"method": "none; calibrated column duplicates raw probability"}
    results.append(save_model_result(
        out, "legacy_baseline", "Original LightGBM Baseline", "external_reference",
        X_test, y_test, raw, mapped, calibration_info,
        {"estimator_parameters": baseline.get_params(),
         "note": "Unchanged baseline fit: train only; tune for early stopping; no calibration."}
    ))

    # Original SMOTE sampler + estimator, with leakage-safe feature preparation.
    print("Fitting SMOTE + LightGBM external comparator", flush=True)
    sm_fit, sm_cal, sm_test, smote_features = smote_numeric_representation(
        X_fit, X_cal, X_test
    )
    smote = make_smote_sampler()
    sm_fit_resampled, sm_y_resampled = smote.fit_resample(sm_fit, y_fit)
    smote_model = make_smote_baseline()
    smote_model.fit(sm_fit_resampled, sm_y_resampled)
    raw, mapped, calibration_info = platt_predict(
        smote_model, sm_cal, y_cal, sm_test
    )
    results.append(save_model_result(
        out, "smote_lgbm", "SMOTE + LightGBM", "external_reference",
        X_test, y_test, raw, mapped, calibration_info,
        {"estimator_parameters": SMOTE_BASE_KWARGS,
         "resampling": "SMOTE(random_state=42) on train+tune only",
         "resampled_n": int(len(sm_y_resampled)),
         "preprocessing": "train+tune-only imputation, scaling and one-hot encoding; no source-script zigzag/noise",
         **smote_features}
    ))

    result_frame = pd.DataFrame(results)
    main_columns = [
        "model_key", "model", "family", "alpha", "gamma", "best_iteration",
        "pr_auc", "roc_auc", "brier", "recall", "precision", "fpr",
        "f2", "tn", "fp", "fn", "tp",
    ]
    result_frame.reindex(columns=main_columns).to_csv(
        out / "ablation_results.csv", index=False
    )
    run_info = {
        "data_file": str(args.data.resolve()),
        "data_sha256": source_sha256(args.data),
        "label_rule": "Target_Penalty in supplied CSV; source metadata: Fine Amount > 170734.80",
        "feature_columns": list(X.columns),
        "n_total": int(len(y)),
        "n_positive": int(y.sum()),
        "splits": split_manifest(splits),
        "locked_threshold": LOCKED_THRESHOLD,
        "focal_source": {"path": str(FOCAL_SOURCE), "sha256": source_sha256(FOCAL_SOURCE)},
        "baseline_source": {"path": str(BASELINE_SOURCE), "sha256": source_sha256(BASELINE_SOURCE)},
        "smote_source": {"path": str(SMOTE_SOURCE), "sha256": source_sha256(SMOTE_SOURCE)},
        "focal_candidate_parameters": FOCAL_BASE_KWARGS,
        "smote_estimator_parameters": SMOTE_BASE_KWARGS,
        "gamma_sensitivity_scope": "tune partition only; no test-set gamma selection",
        "comparison_scope": (
            "Four focal-family cells are a controlled 2x2 under one feature/split/"
            "calibration protocol. Legacy baseline follows its original train-only, "
            "uncalibrated route. SMOTE is an external comparator with train-only "
            "preprocessing; its historical pre-split perturbation is omitted."
        ),
        "versions": {
            "numpy": np.__version__, "pandas": pd.__version__,
            "scikit_learn": sklearn.__version__, "lightgbm": lgb.__version__,
        },
        "results": results,
    }
    (out / "experiment_metadata.json").write_text(
        json.dumps(run_info, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )
    (args.output / "latest_run.json").write_text(
        json.dumps({"run": run_name}, indent=2), encoding="utf-8"
    )
    print(result_frame[main_columns].to_string(index=False), flush=True)
    print(f"Completed: {out}", flush=True)


if __name__ == "__main__":
    main()
