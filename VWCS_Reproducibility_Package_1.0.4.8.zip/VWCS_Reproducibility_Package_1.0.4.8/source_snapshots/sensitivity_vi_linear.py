"""Single-factor linear Vi sensitivity experiment; same protocol as revision A/B.
LHLenv: python sensitivity_vi_linear.py [--out NEW_DIRECTORY]
"""
import argparse,hashlib,json,ast
from pathlib import Path
import numpy as np,pandas as pd,lightgbm as lgb
from scipy.special import expit
from sklearn.metrics import average_precision_score,fbeta_score,brier_score_loss,confusion_matrix
from ablation_data import DEFAULT_DATA,load_data_and_splits,split_manifest
from ablation_models import FOCAL,FOCAL_BASE_KWARGS,focal_eval
from run_ablation import MAX_ROUNDS,platt_predict,score_predictions

base=Path(__file__).resolve().parent
src=base/'logs/Revision2_Vi_20261110'
p=argparse.ArgumentParser()
p.add_argument('--out',type=Path,default=base/'logs/Revision3_Vi_Sensitivity')
out=p.parse_args().out;out.mkdir(parents=True,exist_ok=False)
proto=json.loads((src/'protocol.json').read_text(encoding='utf8'))
def h(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for name,digest in proto['dataset_sha256'].items():assert h(Path(name))==digest,name
X,y,splits=load_data_and_splits()
assert split_manifest(splits)==proto['splits']
aux=pd.read_csv(src/'vulnerability_auxiliary.csv',dtype={'ccn':str},float_precision='round_trip').set_index('sample_id')
assert aux.index.equals(y.index) and np.array_equal(aux.y_true,y)
train=splits['train'][0].index;xt,yt=splits['tune'];xc,yc=splits['calibration'];xe,ye=splits['test'];refit=np.r_[train,xt.index]
comp=pd.DataFrame(index=y.index);names=['staff_hours','adl_decline_pct','cycle1_deficiencies']
for c in names:
    vals=np.sort(aux[c].loc[train].dropna()); z=aux[c].fillna(np.median(vals))
    r=(vals.searchsorted(z,'left')+vals.searchsorted(z,'right'))/(2*len(vals))
    comp[c]=1-r if c==names[0] else r
    assert np.allclose(comp[c],aux[c+'_risk'],rtol=0,atol=1e-12)
v0=comp.mean(axis=1);high=v0.ge(v0.loc[train].quantile(.75))
assert high.equals(aux.high_V.astype(bool))
hp=high.loc[xe.index].to_numpy() & ye.to_numpy().astype(bool);assert hp.sum()==38
# Load the exact scalar-weight objective factory without executing the legacy script.
f=base/'run_revision2_vulnerability.py'
assert h(f)==proto['source_hashes'][f.name]
tree=ast.parse(f.read_text(encoding='utf-8-sig'));tree.body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='obj']
env={'FOCAL':FOCAL,'expit':expit,'np':np};exec(compile(tree,str(f),'exec'),env);objective=env['obj']
equal=(1/3,)*3
cases=[('off',0.,equal),('weak',.25,equal),('reference',1.,equal)]
for i,c in enumerate(names):
    cases.extend([('up_'+c,1.,tuple(.5 if i==j else .25 for j in range(3))),('omit_'+c,1.,tuple(0. if i==j else .5 for j in range(3)))])
original=pd.read_csv(src/'paired_predictions.csv',float_precision='round_trip').set_index('sample_id').loc[xe.index]
pred=aux.loc[xe.index,['ccn','y_true','high_V']].copy(); rows=[];cals={}
for name,beta,omega in cases:
    v=v0 if omega==equal else comp.dot(omega)
    def model(idx,rounds):
        lab=y.loc[idx].to_numpy()
        w=np.where(lab==1,.9*(1+beta*v.loc[idx].to_numpy()),.1)
        return FOCAL['FocalLossLGBM'](**{**FOCAL_BASE_KWARGS,'n_estimators':int(rounds),'n_jobs':2,'objective':objective(lab,w)})
    m=model(train,MAX_ROUNDS)
    m.fit(X.loc[train],y.loc[train],eval_set=[(xt,yt)],eval_metric=focal_eval(),callbacks=[lgb.early_stopping(100,first_metric_only=True,verbose=False)])
    it=int(m.best_iteration_ or MAX_ROUNDS);final=model(refit,it);final.fit(X.loc[refit],y.loc[refit])
    raw,q,cal=platt_predict(final,xc,yc,xe);flag=q>=.2
    perf=score_predictions(ye,raw,q);tn,fp,fn,tp=confusion_matrix(ye,flag).ravel()
    assert np.allclose([average_precision_score(ye,raw),fbeta_score(ye,flag,beta=2),brier_score_loss(ye,q),tn,fp,fn,tp],[perf[k] for k in ['pr_auc','f2','brier','tn','fp','fn','tp']])
    if name in ['reference','off']:
        arm={'reference':'B','off':'A'}[name];assert np.allclose(original[arm+'_calibrated'],q,rtol=0,atol=1e-9) and np.allclose(original[arm+'_raw_probability'],raw,rtol=0,atol=1e-9)
    rows.append(dict(config=name,beta=beta,staff=omega[0],adl=omega[1],defect=omega[2],iteration=it,**perf,high_tp=int(sum(flag&hp)),high_fn=int(sum(~flag&hp)),alerts=int(flag.sum())))
    pred[name+'_raw']=raw;pred[name+'_cal']=q;pred[name+'_flag']=flag.astype(int);cals[name]=cal
    print(name,it,perf['pr_auc'],sum(~flag&hp),flush=True)
mt=pd.DataFrame(rows);mt.to_csv(out/'metrics.csv',index=False);pred.to_csv(out/'predictions.csv')
(out/'protocol.json').write_text(json.dumps({'reference':proto,'frozen_high_test_ids':pred.index[hp].tolist(),'threshold':.2,'cases':cases,'calibrators':cals,'script_sha256':h(Path(__file__)),'aux_sha256':h(src/'vulnerability_auxiliary.csv'),'note':'Positive weight mass is not renormalized, matching revision A/B. Each row uses the same tuning stopping protocol; test is for sensitivity reporting only.'},indent=2),encoding='utf8')
print(mt.to_string(index=False))
