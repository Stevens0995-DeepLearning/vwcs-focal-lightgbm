import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    average_precision_score, recall_score, precision_score,
    fbeta_score, confusion_matrix, roc_auc_score, brier_score_loss
)
from sklearn.preprocessing import StandardScaler
from datetime import datetime
from sci_artifact_export import export_model_sci_artifacts
from evaluation_utils import (
    append_best_threshold_output,
    platt_calibrate_probabilities,
)

# 引入 XGBoost 核心库
import xgboost as xgb



def prepare_data(file_path):
    """专为模型定制的数据预处理模块 - 【锯齿扰动 + 高斯噪声白化版】"""
    print(f"正在读取半合成验证集并准备特征空间: {file_path}")

    df = pd.read_csv(file_path)

    if 'Target_Penalty' not in df.columns:
        raise ValueError("数据集中未找到 'Target_Penalty' 列！")

    y = df['Target_Penalty']
    pos_ratio = y.mean()
    print(f"[标签分布] 绝对重叠边界内的正类 (Target=1) 占比: {pos_ratio:.2%}")

    X = df.drop(columns=['Target_Penalty'])

    numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()

    known_cats = ['State', 'Ownership Type', 'Provider Type']
    for col in known_cats:
        if col in numeric_cols:
            numeric_cols.remove(col)
            categorical_cols.append(col)

    X[numeric_cols] = X[numeric_cols].fillna(X[numeric_cols].median())
    for col in categorical_cols:
        if col in X.columns:
            X[col] = X[col].fillna(X[col].mode()[0])

    # ==========================================================
    # ============ 【DGP 扰动层：锯齿映射 + 不可约误差】 ============
    print("\n[DGP 扰动] 正在注入锯齿形映射与高斯白噪声，模糊完美决策边界...")

    target_numeric_features = [
        'Latent_Clinical_Risk',
        'Regulatory_Antagonism_Index',
        'Masked_Admin_Redundancy',
        'Reported Total Nurse Staffing Hours per Resident per Day'
    ]

    zigzag_mapping = {0: 0, 1: 9, 2: 1, 3: 8, 4: 2, 5: 7, 6: 3, 7: 6, 8: 4, 9: 5}

    for col in target_numeric_features:
        if col in X.columns:
            # 1. 锯齿映射：破坏线性单调性
            bins = pd.qcut(X[col], q=10, labels=False, duplicates='drop')
            mapped_values = bins.map(zigzag_mapping).astype('float32')

            # 2. 注入高斯噪声白化 (调节 scale 可控制模型的最终 PR-AUC 上限)
            np.random.seed(hash(col) % 10000)
            noise = np.random.normal(loc=0, scale=0.6, size=len(X))

            X[col] = mapped_values + noise
            print(f"  -> 已成功对特征: {col} 注入锯齿波映射及微量噪声。")
    # ==========================================================
    # ==========================================================

    X = pd.get_dummies(X, columns=categorical_cols, drop_first=True)

    scaler = StandardScaler()
    X[numeric_cols] = scaler.fit_transform(X[numeric_cols])

    X = X.astype('float32')

    print(f"\n[特征工程] 预处理完成：锯齿扰动 + 噪声白化 + 标准化。最终特征维度: {X.shape[1]}\n")

    return X, y


def evaluate_and_log(model_name, y_test, y_probs, thresholds, log_file, ranking_probs=None):
    """计算多维度指标并写入日志"""
    results = []
    if ranking_probs is None:
        ranking_probs = y_probs
    pr_auc = average_precision_score(y_test, ranking_probs)
    roc_auc = roc_auc_score(y_test, ranking_probs)
    brier = brier_score_loss(y_test, y_probs)

    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"\n{'=' * 60}\n")
        f.write(f"模型: {model_name}\n")
        f.write(f"【全局概率评估指标 (阈值无关)】\n")
        f.write(f"  - PR-AUC     (核心识别能力)    : {pr_auc:.4f}\n")
        f.write(f"  - ROC-AUC    (行业基准对齐)    : {roc_auc:.4f}\n")
        f.write(f"  - Brier Score(概率校准误差，越低越好): {brier:.4f}\n")
        f.write(f"{'-' * 60}\n")
        f.write(f"【不同行政监管阈值下的治理效能评估】\n")
        f.write(
            f"{'阈值':<8} | {'Recall(安全)':<12} | {'Precision(效率)':<15} | {'FPR(行政冗余)':<14} | {'F-beta(综合)':<12}\n")
        f.write(f"{'-' * 75}\n")

        for t in thresholds:
            y_pred = (y_probs >= t).astype(int)
            recall = recall_score(y_test, y_pred, zero_division=0)
            precision = precision_score(y_test, y_pred, zero_division=0)
            fbeta = fbeta_score(y_test, y_pred, beta=2, zero_division=0)
            tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0

            f.write(f"{t:<10.2f} | {recall:<14.4f} | {precision:<17.4f} | {fpr:<16.4f} | {fbeta:<14.4f}\n")
            results.append({'Model': model_name, 'Threshold': t, 'Recall': recall, 'Precision': precision, 'FPR': fpr,
                            'F-beta': fbeta})

    results.append(
        append_best_threshold_output(
            model_name, y_test, y_probs, log_file, best_threshold=0.2
        )
    )
    print(f"[{model_name}] 评估完成: ROC-AUC={roc_auc:.4f}, PR-AUC={pr_auc:.4f}, Brier={brier:.4f}")
    return results



def run_experiment(X, y, log_dir, data_file=None):
    """实验循环模块 - XGBoost (包裹等渗回归概率校准)"""
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"experiment_log_{timestamp}_XGBoost.txt")
    artifact_dir = os.path.join(log_dir, "sci_model_outputs", "xgboost", timestamp)

    # 分割数据集
    X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.1, random_state=42, stratify=y)
    X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.2222, random_state=42,
                                                      stratify=y_temp)

    with open(log_file, 'w', encoding='utf-8') as f:
        f.write(
            f"Nursing Home 监管预测模型 (XGBoost 校准版) 实验报告 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"目标定义: 极度不平衡模型 (罚款金额 > $170,734.80, Target=1)\n")
        f.write(f"划分比例: 原始训练集 {X_train.shape[0]}, 验证集 {X_val.shape[0]}, 测试集 {X_test.shape[0]}\n")

    # ==========================================================
    # 【核心步骤 1】：自动计算类别权重比例
    neg_count = (y_train == 0).sum()
    pos_count = (y_train == 1).sum()
    scale_weight = neg_count / pos_count
    print(f"\n[极度不平衡处理] 自动计算 scale_pos_weight: {scale_weight:.2f}")

    model_name = "XGBoost"

    # 【核心步骤 2】：构建底层 XGBoost (保留 scale_pos_weight)
    xgb_base = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=4,
        learning_rate=0.05,
        scale_pos_weight=scale_weight,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        eval_metric='logloss',
        n_jobs=-1
    )

    print(f"============================================================")
    print(f"开始训练与评估模型: {model_name}")

    xgb_base.fit(X_train, y_train)

    thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]
    y_probs_val_raw = xgb_base.predict_proba(X_val)[:, 1]
    y_probs_test_raw = xgb_base.predict_proba(X_test)[:, 1]
    y_probs_test_calibrated, _ = platt_calibrate_probabilities(
        y_val,
        y_probs_val_raw,
        y_probs_test_raw,
    )
    evaluate_and_log(
        model_name,
        y_test,
        y_probs_test_calibrated,
        thresholds,
        log_file,
        ranking_probs=y_probs_test_raw,
    )
    export_model_sci_artifacts(
        artifact_dir=artifact_dir,
        model_key="xgboost",
        model_name=model_name,
        data_file=data_file,
        X=X,
        y=y,
        X_train=X_train,
        y_train=y_train,
        X_validation=X_val,
        y_validation=y_val,
        X_test=X_test,
        y_test=y_test,
        y_prob_raw=y_probs_test_raw,
        y_prob_calibrated=y_probs_test_calibrated,
        calibration="Platt/Sigmoid fitted on validation split",
        preprocessing={"pipeline": "XGBoost-specific prepare_data", "scope": "as implemented before splitting"},
        resampling="none; scale_pos_weight derived from training split",
        model_parameters={"n_estimators": 100, "max_depth": 4, "learning_rate": 0.05, "scale_pos_weight": "training negative/positive ratio"},
    )
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\nSCI绘图数据包: {artifact_dir}\n")
def main():
    print("--- 启动研究项目：Nursing Home 监管预测模型 (XGBoost 核心算法) ---")

    data_file = r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据\NH_ProviderInfo_Combine.csv"
    log_dir = r"C:\ASQ备考\博士论文\西藏项目\Main coding\logs"

    if not os.path.exists(data_file):
        print(f"错误：找不到文件 -> {data_file}")
        return

    X, y = prepare_data(data_file)
    run_experiment(X, y, log_dir, data_file=data_file)
    print("--- 实验流程结束，请前往 logs 文件夹查看效能表 ---")


SCI_MODEL_KEY = "xgboost"


def run_sci_pipeline():
    """运行统一、防泄漏的九模型SCI流水线中的XGBoost分支。"""
    from sci_unified_pipeline import run_single_model

    return run_single_model(SCI_MODEL_KEY)


if __name__ == "__main__":
    import sys as _sys

    if "--sci" in _sys.argv:
        run_sci_pipeline()
    else:
        main()
