"""Temporal transport of the frozen upper100 weighting rule, not of the 16-feature model."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.metrics import average_precision_score,roc_auc_score
from ablation_models import FOCAL,FOCAL_BASE_KWARGS

B=Path(__file__).resolve().parent
root=B.parent.parent/'西藏项目2/数据集/原始数据'
default_out=B/'logs/Revision2_Vi_CMS_time_20261110'
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=default_out);out=p.parse_args().out
out.mkdir(parents=True,exist_ok=True)
if any(out.iterdir()): raise FileExistsError(out)
s=json.loads((B/'logs/Revision2_Vi_dev_screen/selection.json').read_text())
assert (s['chosen'],s['primary_budget'],s['rounds'])==('upper100',.05,300)
CC='CMS Certification Number (CCN)'
hours='Reported Total Nurse Staffing Hours per Resident per Day'
defs='Rating Cycle 1 Total Number of Health Deficiencies'
names=['State','Ownership Type','Provider Type',hours,defs]
hashes={}; audits=[]
def read(f):
    hashes[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest();return pd.read_csv(f,dtype={CC:str},low_memory=False)
def cohort(yr):
    origin=pd.Timestamp({2024:'2024-05-29',2025:'2025-05-28'}[yr]);end=origin+pd.Timedelta(days=270)
    folder=root/f'nursing-homes_annual_{yr}'
    roster=read(folder/f'NH_ProviderInfo_May{yr}.csv');md=read(folder/f'NH_QualityMsr_MDS_May{yr}.csv')
    assert pd.to_datetime(roster['Processing Date']).max()<=origin and pd.to_datetime(md['Processing Date']).max()<=origin
    md=md.loc[md['Measure Code'].eq(401)&md['Resident type'].eq('Long Stay')]
    assert md['Measure Description'].eq('Percentage of long-stay residents whose need for help with daily activities has increased').all()
    assert roster[CC].notna().all() and roster[CC].is_unique and md[CC].is_unique
    d=roster[[CC]+names].merge(md[[CC,'Four Quarter Average Score']],on=CC,how='left',validate='one_to_one').rename(columns={'Four Quarter Average Score':'adl'})
    for field in [hours,defs,'adl']:
        old=d[field];d[field]=pd.to_numeric(old,errors='coerce')
        print(yr,field,'non-numeric placeholders',old[old.notna()&d[field].isna()].value_counts().to_dict(),flush=True)
    pf=(root/'nursing-homes_annual_2025/NH_Penalties_May2025.csv' if yr==2024 else B.parent/'资料准备/数据/实验数据/others/NH_Penalties_May2026.csv')
    penalties=read(pf);dates=pd.to_datetime(penalties['Penalty Date'])
    assert dates.min()<=origin and dates.max()>=end
    fines=penalties.loc[dates.gt(origin)&dates.le(end)&penalties['Penalty Type'].eq('Fine')]
    assert fines['Fine Amount'].notna().all()
    total=fines.groupby(CC)['Fine Amount'].sum()
    d['window_fines']=d[CC].map(total).fillna(0);d['y']=d.window_fines.gt(170734.80).astype(int)
    audits.append(dict(origin=str(origin.date()),end=str(end.date()),rows=len(d),positive=int(d.y.sum()),period=sorted(md['Measure Period'].dropna().unique().tolist()),fine_rows=len(fines),missing=d[[hours,defs,'adl']].isna().sum().to_dict()))
    return d
train=cohort(2024);val=cohort(2025)
overlap=int(val[CC].isin(train[CC]).sum())
def index(d):
    v=np.zeros(len(d))
    for c in [hours,'adl',defs]:
        a=np.sort(train[c].dropna()); z=d[c].fillna(np.median(a))
        r=(a.searchsorted(z,'left')+a.searchsorted(z,'right'))/(2*len(a))
        v+=(1-r if c==hours else r)/3
    return v
trv=index(train);vt=index(val);cut=np.quantile(trv,.75);train['V_i']=trv;val['V_i']=vt
hi=vt>=cut; y=train.y.to_numpy();truth=val.y.to_numpy();hp=hi&(truth==1)
xt=train[names].copy();xv=val[names].copy()
for c in names:
    if c in [hours,defs]:
        xt[c]=xt[c].astype('float32');xv[c]=xv[c].astype('float32')
    else:
        xt[c]=xt[c].astype('category');xv[c]=pd.Categorical(xv[c],categories=xt[c].cat.categories)
legacy=FOCAL['focal_loss_custom'](.9,.25,'bce_proxy')
k=int(np.ceil(len(val)*.05)); rows=[];mask={}
for arm,beta in [('uniform',0.),('upper100',1.)]:
    m=1+beta*np.maximum(trv-cut,0)/(1-cut)
    w=np.where(y==1,.9*m/m[y==1].mean(),.1)
    assert np.isclose(w[y==1].sum(),.9*y.sum())
    def objective(labels,margin):
        assert np.array_equal(labels,y)
        g=legacy(labels,margin)[0]*w/np.where(y==1,.9,.1)
        pr=np.clip(expit(margin),1e-6,1-1e-6)
        return g,np.maximum(w*pr*(1-pr),1e-5)
    mdl=FOCAL['FocalLossLGBM'](**{**FOCAL_BASE_KWARGS,'objective':objective,'n_estimators':300,'n_jobs':2})
    mdl.fit(xt,y)
    score=mdl.booster_.predict(xv,raw_score=True,num_threads=2)
    ordered=np.lexsort((np.arange(len(score)),-score)); keep=np.zeros(len(val),bool);keep[ordered[:k]]=True;mask[arm]=keep
    val[arm+'_margin']=score;val[arm+'_alert']=keep.astype(int)
    tp=int(truth[keep].sum());ht=int(hp[keep].sum())
    rows.append(dict(arm=arm,n=len(val),positive=int(truth.sum()),high_positive=int(hp.sum()),k=k,TP=tp,FP=k-tp,FN=int(truth.sum()-tp),high_TP=ht,high_FN=int(hp.sum()-ht),AP=average_precision_score(truth,score),ROC_AUC=roc_auc_score(truth,score),precision_at_k=tp/k))
for d,tag in [(train,'train'),(val,'validation')]:
    d.to_csv(out/(tag+'.csv'),index=False,encoding='utf-8-sig')
res=pd.DataFrame(rows);res.to_csv(out/'metrics.csv',index=False)
au={'cohorts':audits,'overlapping_ccns':overlap,'files_sha256':hashes,'train_v_q75':cut,'policy':s,'endpoint':'recorded Fine amounts within (origin, origin+270d], total > 170734.80; no matching fine = 0 recorded','queue_overlap':int((mask['uniform']&mask['upper100']).sum()),'only_upper_high_tp':int((hp&mask['upper100']&~mask['uniform']).sum()),'only_uniform_high_tp':int((hp&~mask['upper100']&mask['uniform']).sum())}
(out/'protocol.json').write_text(json.dumps(au,indent=2,ensure_ascii=False),encoding='utf8')
print(res.to_string(index=False));print(audits,overlap,au['queue_overlap'],au['only_upper_high_tp'],au['only_uniform_high_tp'])
