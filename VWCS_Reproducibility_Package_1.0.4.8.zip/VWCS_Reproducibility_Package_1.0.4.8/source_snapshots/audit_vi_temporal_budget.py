"""Paired facility bootstrap with each model's top-k queue rebuilt in each draw."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
b=Path(__file__).resolve().parent/'logs/Revision2_Vi_CMS_time_20261110'
d=pd.read_csv(b/'validation.csv');p=json.loads((b/'protocol.json').read_text(encoding='utf8'))
z=d.y.to_numpy();hi=(d.V_i.to_numpy()>=p['train_v_q75'])*z;n=len(z);k=int(np.ceil(n*.05));rng=np.random.default_rng(42)
orders=[np.lexsort((np.arange(n),-d[a+'_margin'].to_numpy())) for a in ['uniform','upper100']]
def perf(count,order):
    v=count[order];cum=np.cumsum(v);zsel=np.minimum(v,np.maximum(k-(cum-v),0)); assert zsel.sum()==k
    return np.array([zsel@hi[order]/(count@hi),zsel@z[order]/(count@z)])
raw=perf(np.ones(n,int),orders[1])-perf(np.ones(n,int),orders[0])
arr=[]
for _ in range(2000):
    cnt=np.bincount(rng.integers(0,n,n),minlength=n)
    if cnt@hi:arr.append(perf(cnt,orders[1])-perf(cnt,orders[0]))
summary=dict(metrics=['delta_high_positive_recall','delta_all_positive_recall'],estimate=raw.tolist(),percentile_95=np.quantile(arr,[.025,.975],axis=0).tolist(),replicates=len(arr),seed=42)
(b/'paired_bootstrap.json').write_text(json.dumps(summary,indent=2));print(summary)
