"""Read frozen predictions; calculate and draw the revision-10 supplement.

No training, model recalibration, source-file changes, or noise regeneration.
"""
from pathlib import Path
import csv, json, hashlib, sys
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import pypdfium2 as pdfium

sys.stdout.reconfigure(encoding='utf-8')
BASE = Path(r'C:/ASQ备考/博士论文/西藏项目/Main coding/logs')
OUT = Path('revision10_doc_qa')
OUT.mkdir(exist_ok=True)
PROTOCOL = json.loads((BASE/'Revision7_Paired_Analysis_20261113/Analysis_Protocol.json').read_text(encoding='utf8'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
NAMES = dict(focal_lgbm='VWCS-Focal-LightGBM', lgbm_baseline='LightGBM', svm='SVM', catboost='CatBoost', xgboost='XGBoost', smote_lgbm='SMOTE-LightGBM', easy_ensemble='EasyEnsemble', random_forest='Random Forest', lr='Logistic Regression')

def diagnostic(y, prob):
    q = np.clip(prob, 1e-6, 1-1e-6)
    X = np.column_stack([np.ones(len(y)), np.log(q/(1-q))])
    coef = np.array([0., 1.])
    penalty = np.diag([0., 1e-6])
    def objective(w):
        z = X@w
        return np.sum(np.logaddexp(0, z)-y*z) + .5*w@penalty@w
    for i in range(100):
        z = X@coef
        p = 1/(1+np.exp(-np.clip(z, -700, 700)))
        g = X.T@(p-y)+penalty@coef
        H = X.T@((p*(1-p))[:, None]*X)+penalty
        step = np.linalg.solve(H, g)
        rate = 1.
        while objective(coef-rate*step)>objective(coef)+1e-10:
            rate *= .5
            assert rate>1e-8
        coef -= rate*step
        if np.max(np.abs(rate*step))<1e-10:
            break
    assert np.max(np.abs(X.T@(1/(1+np.exp(-X@coef))-y)+penalty@coef))<1e-6
    return dict(brier=float(np.mean((prob-y)**2)), intercept=float(coef[0]), slope=float(coef[1]), iterations=i+1)

def operating(y, p):
    flag = p>=.2
    tp, fp = int(np.sum(flag & (y==1))), int(np.sum(flag & (y==0)))
    fn, tn = int(np.sum(~flag & (y==1))), int(np.sum(~flag & (y==0)))
    return dict(tp=tp, fp=fp, fn=fn, tn=tn, recall=tp/(tp+fn), precision=tp/(tp+fp), fpr=fp/(fp+tn), f2=5*tp/(5*tp+4*fn+fp), reviews=tp+fp, workload=(tp+fp)/len(y))

models, rows = {}, []
for path, expected in PROTOCOL['sources'].items():
    if not path.endswith('test_predictions.csv'):
        continue
    assert sha(path)==expected, path
    with open(path, encoding='utf-8-sig', newline='') as f:
        records = list(csv.DictReader(f))
    key = records[0]['model_key']
    records.sort(key=lambda r:int(r['sample_id']))
    ids = [r['sample_id'] for r in records]
    y = np.array([int(r['y_true']) for r in records])
    raw = np.array([float(r['y_prob_raw']) for r in records])
    q = np.array([float(r['y_prob_calibrated']) for r in records])
    assert len(set(ids))==1470 and int(y.sum())==73
    assert np.all(np.isfinite(q)) and np.all((q>=0)&(q<=1))
    if models:
        ref = next(iter(models.values()))
        assert ids==ref['ids'] and np.array_equal(y, ref['y'])
    meta = json.loads((Path(path).parent/'experiment_metadata.json').read_text(encoding='utf8'))
    diag = diagnostic(y, q)
    row = dict(model_key=key, model=NAMES[key], **diag, **operating(y,q), calibration=meta['calibration'], source=path, sha256=expected)
    rows.append(row)
    models[key]=dict(ids=ids, y=y, raw=raw, q=q)

focal=models['focal_lgbm']
before_after=[]
for label, p in [('Before Platt',focal['raw']), ('After Platt',focal['q'])]:
    before_after.append(dict(output=label, **diagnostic(focal['y'],p), **operating(focal['y'],p)))

report=dict(n=1470,positive=73,negative=1397,threshold=.2,diagnostic='logistic regression of y on logit(q); intercept unpenalized, slope L2 penalty 1/(2C) with C=1e6; Newton solver to step tolerance 1e-10; probability clip 1e-6 only for logit',models=rows, before_after=before_after)
(OUT/'calibration_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
with (OUT/'Table_S13_Calibration.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

# Two reliability panels, with probability histograms beneath. Vector PDF is
# the master; a 600-dpi raster is used in Word for broad rendering compatibility.
pdfmetrics.registerFont(TTFont('TNR','C:/Windows/Fonts/times.ttf'))
pdfmetrics.registerFont(TTFont('TNRB','C:/Windows/Fonts/timesbd.ttf'))
W,H=432,342
c=canvas.Canvas(str(OUT/'Figure_S1_Calibration_Diagnostics.pdf'),pagesize=(W,H))
c.setTitle('Probability calibration diagnostics on the locked benchmark')
BLUE='#23639B'; ORANGE='#C56C14'; GREEN='#22806D'; GREY='#91989E'; BLACK='#20282E'

def txt(x,y,s,size=9,align='left',bold=False,color=BLACK):
    c.setFillColor(color);c.setFont('TNRB' if bold else 'TNR',size)
    getattr(c,{'left':'drawString','center':'drawCentredString','right':'drawRightString'}[align])(x,y,s)

def line(x1,y1,x2,y2,color=BLACK,width=.6,dash=()):
    c.setStrokeColor(color);c.setLineWidth(width);c.setDash(dash)
    c.line(x1,y1,x2,y2);c.setDash()

def marker(x,y,color,shape):
    c.setStrokeColor(color);c.setFillColor('white');c.setLineWidth(.8)
    if shape=='o':c.circle(x,y,2.5,stroke=1,fill=1)
    elif shape=='s':c.rect(x-2.2,y-2.2,4.4,4.4,stroke=1,fill=1)
    else:
        p=c.beginPath();p.moveTo(x,y+3);p.lineTo(x-2.6,y-2);p.lineTo(x+2.6,y-2);p.close();c.drawPath(p,stroke=1,fill=1)

def reliability(y,q):
    edges=np.percentile(q,np.linspace(0,100,11));groups=np.searchsorted(edges[1:-1],q)
    return [(float(q[groups==i].mean()),float(y[groups==i].mean()),int((groups==i).sum())) for i in range(10) if np.any(groups==i)]

def panel(x,title,series):
    width=158; y0=142; height=133
    txt(x,328,title,10.5,bold=True)
    for j,(name,key,which,col,dash,shape) in enumerate(series):
        yy=312-j*11
        line(x,yy,x+14,yy,col,1.2,dash);marker(x+7,yy,col,shape)
        txt(x+19,yy-3,name,8.9)
    for t in np.linspace(0,1,6):
        line(x,y0+t*height,x+width,y0+t*height,'#E0E4E6',.4)
        line(x-3,y0+t*height,x,y0+t*height,BLACK,.5)
        txt(x-6,y0+t*height-3,f'{t:.1f}',8.5,'right')
    line(x,y0,x,y0+height);line(x,y0,x+width,y0)
    line(x,y0,x+width,y0+height,GREY,.8,(3,2))
    c.saveState();c.translate(x-30,y0+height/2);c.rotate(90);txt(0,0,'Observed positive fraction',9,'center');c.restoreState()
    for name,key,which,col,dash,shape in series:
        rr=reliability(models[key]['y'],models[key][which])
        for (a,b,_),(d,e,_) in zip(rr,rr[1:]):line(x+a*width,y0+b*height,x+d*width,y0+e*height,col,1.2,dash)
        for a,b,_ in rr:marker(x+a*width,y0+b*height,col,shape)
    # Distribution panels share probability axes; frequency is percent of cohort.
    by=56; bh=55
    txt(x,119,'Distribution of predicted probabilities',8.9)
    for t in [0,.5,1]:
        line(x,by+t*bh,x+width,by+t*bh,'#E0E4E6',.4)
        txt(x-6,by+t*bh-3,f'{100*t:.0f}',8.5,'right')
    line(x,by,x,by+bh);line(x,by,x+width,by)
    for t in np.linspace(0,1,6):
        line(x+t*width,by-3,x+t*width,by,BLACK,.5);txt(x+t*width,by-15,f'{t:.1f}',8.5,'center')
    txt(x+width/2,24,'Predicted probability',9.5,'center')
    c.saveState();c.translate(x-30,by+bh/2);c.rotate(90);txt(0,0,'Facilities (%)',9,'center');c.restoreState()
    bins=np.linspace(0,1,21)
    for name,key,which,col,dash,shape in series:
        counts,_=np.histogram(models[key][which],bins)
        vals=counts/1470
        for i,val in enumerate(vals):
            line(x+bins[i]*width,by+val*bh,x+bins[i+1]*width,by+val*bh,col,1,dash)
            if i<19:line(x+bins[i+1]*width,by+val*bh,x+bins[i+1]*width,by+vals[i+1]*bh,col,1,dash)

panel(44,'(a) VWCS before and after calibration',[
    ('Before Platt','focal_lgbm','raw',ORANGE,(3,2),'s'),
    ('After Platt','focal_lgbm','q',BLUE,(),'o')])
panel(254,'(b) Final probability outputs',[
    ('VWCS-Focal-LightGBM','focal_lgbm','q',BLUE,(),'o'),
    ('LightGBM','lgbm_baseline','q',ORANGE,(3,2),'s'),
    ('SVM','svm','q',GREEN,(1,2),'t')])
c.save()
pdf=pdfium.PdfDocument(OUT/'Figure_S1_Calibration_Diagnostics.pdf')
pdf[0].render(scale=600/72).to_pil().save(OUT/'Figure_S1_Calibration_Diagnostics.png',dpi=(600,600))
pdf[0].render(scale=2).to_pil().save(OUT/'figure_preview.png')
print(json.dumps(report,ensure_ascii=False,indent=2))
