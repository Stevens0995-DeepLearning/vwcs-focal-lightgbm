"""Standalone LightGBM baseline experiment.

This file intentionally contains no Focal Loss objective, focal parameter
search, Platt calibration, ``scale_pos_weight`` or ``is_unbalance``.  Its data
split, threshold grid and evaluation format match the corresponding baseline
section of the ablation report so that results remain directly comparable.
"""

import os
from datetime import datetime

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    fbeta_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split

from evaluation_utils import (
    append_best_threshold_output,
)
from sci_artifact_export import export_model_sci_artifacts


DEFAULT_DATA_FILE = (
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Combine.csv"
)
DEFAULT_LOG_DIR = r"C:\ASQ备考\博士论文\西藏项目\Main coding\logs"
LOCKED_THRESHOLD = 0.20
THRESHOLDS = [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70]


def prepare_data(file_path):
    """读取实验数据，并转换为 LightGBM 支持的数据类型。"""
    print(f"正在读取实验数据并准备特征空间: {file_path}")
    df = pd.read_csv(file_path, low_memory=False)
    if "Target_Penalty" not in df.columns:
        raise ValueError("数据集中未找到 'Target_Penalty' 列。")

    y = pd.to_numeric(df["Target_Penalty"], errors="raise").astype(int)
    if y.nunique(dropna=True) < 2:
        raise ValueError("Target_Penalty 仅包含一个类别，无法训练二分类模型。")
    print(f"[标签分布] 正类 (Target=1) 占比: {y.mean():.2%}")

    X = df.drop(columns=["Target_Penalty"])
    categorical_cols = [
        column
        for column in X.columns
        if not pd.api.types.is_numeric_dtype(X[column].dtype)
        and not pd.api.types.is_bool_dtype(X[column].dtype)
    ]
    for column in categorical_cols:
        X[column] = X[column].astype("category")

    numeric_cols = X.select_dtypes(include=[np.number]).columns
    X[numeric_cols] = X[numeric_cols].astype("float32")
    print(
        f"[特征工程] 成功加载 {X.shape[1]} 个特征；"
        f"其中分类特征 {len(categorical_cols)} 个。"
    )
    return X, y


def split_data(X, y):
    """复制原消融日志使用的固定随机划分。"""
    X_temp, X_test, y_temp, y_test = train_test_split(
        X,
        y,
        test_size=0.10,
        random_state=42,
        stratify=y,
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_temp,
        y_temp,
        test_size=0.2222,
        random_state=42,
        stratify=y_temp,
    )
    X_tune, X_cal, y_tune, y_cal = train_test_split(
        X_val,
        y_val,
        test_size=0.50,
        random_state=43,
        stratify=y_val,
    )
    return X_train, y_train, X_tune, y_tune, X_cal, y_cal, X_test, y_test


def build_baseline_model():
    """构建与上传消融日志一致的受限容量 LightGBM baseline。"""
    return lgb.LGBMClassifier(
        boosting_type="gbdt",
        objective="binary",
        n_estimators=50,
        learning_rate=0.05,
        max_depth=2,
        num_leaves=4,
        min_child_samples=500,
        max_bin=32,
        reg_lambda=1.0,
        random_state=42,
        verbose=-1,
    )


def evaluate_and_log(model_name, y_test, y_probs, log_file):
    """按上传报告的版式输出全局指标和阈值表。"""
    pr_auc = average_precision_score(y_test, y_probs)
    roc_auc = roc_auc_score(y_test, y_probs)
    brier = brier_score_loss(y_test, y_probs)
    rows = []

    with open(log_file, "a", encoding="utf-8") as stream:
        stream.write(f"\n{'=' * 60}\n")
        stream.write(f"模型: {model_name}\n")
        stream.write("【全局概率评估指标 (阈值无关)】\n")
        stream.write(f"  - PR-AUC     (核心识别能力)    : {pr_auc:.4f}\n")
        stream.write(f"  - ROC-AUC    (行业基准对齐)    : {roc_auc:.4f}\n")
        stream.write(f"  - Brier Score(概率校准误差，越低越好): {brier:.4f}\n")
        stream.write(f"{'-' * 60}\n")
        stream.write("【不同行政监管阈值下的治理效能评估】\n")
        stream.write(
            f"{'阈值':<8} | {'Recall(安全)':<12} | "
            f"{'Precision(效率)':<15} | {'FPR(行政冗余)':<14} | "
            f"{'F-beta(综合)':<12}\n"
        )
        stream.write(f"{'-' * 75}\n")

        for threshold in THRESHOLDS:
            y_pred = (y_probs >= threshold).astype(int)
            recall = recall_score(y_test, y_pred, zero_division=0)
            precision = precision_score(y_test, y_pred, zero_division=0)
            fbeta = fbeta_score(y_test, y_pred, beta=2, zero_division=0)
            tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
            fpr = fp / (fp + tn) if fp + tn else 0.0
            stream.write(
                f"{threshold:<10.2f} | {recall:<14.4f} | "
                f"{precision:<17.4f} | {fpr:<16.4f} | {fbeta:<14.4f}\n"
            )
            rows.append(
                {
                    "Model": model_name,
                    "Threshold": threshold,
                    "Recall": recall,
                    "Precision": precision,
                    "FPR": fpr,
                    "F-beta": fbeta,
                }
            )

    rows.append(
        append_best_threshold_output(
            model_name,
            y_test,
            y_probs,
            log_file,
            best_threshold=LOCKED_THRESHOLD,
        )
    )
    print(
        f"[{model_name}] 评估完成: ROC-AUC={roc_auc:.4f}, "
        f"PR-AUC={pr_auc:.4f}, Brier={brier:.4f}"
    )
    return rows


def run_experiment(X, y, log_dir, data_file=None):
    """训练并评估独立的 LightGBM baseline。"""
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(
        log_dir,
        f"experiment_log_{timestamp}_lightGBM_Baseline.txt",
    )
    artifact_dir = os.path.join(
        log_dir,
        "sci_model_outputs",
        "lgbm_baseline",
        timestamp,
    )
    (
        X_train,
        y_train,
        X_tune,
        y_tune,
        X_cal,
        y_cal,
        X_test,
        y_test,
    ) = split_data(X, y)

    with open(log_file, "w", encoding="utf-8") as stream:
        stream.write(
            "Nursing Home LightGBM Baseline实验报告 - "
            f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        )
        stream.write(
            "目标定义: 极度不平衡模型 "
            "(罚款金额 > $170,734.80, Target=1)\n"
        )
        stream.write(
            f"划分比例: 训练集 {len(y_train)}, 调参集 {len(y_tune)}, "
            f"校准集 {len(y_cal)}, 测试集 {len(y_test)}\n"
        )
        stream.write(
            "Baseline约束: GBDT；不使用Focal Loss、SMOTE、"
            "scale_pos_weight、is_unbalance或概率校准。\n"
        )
        stream.write(
            "模型参数: n_estimators=50, learning_rate=0.05, "
            "max_depth=2, num_leaves=4, min_child_samples=500, max_bin=32, "
            "reg_lambda=1.0\n"
        )
        stream.write(
            "说明: tuning子集仅用于early stopping；calibration子集"
            "为保持同一划分而保留，本未校准baseline不使用它；"
            "test仅评估一次。\n"
        )

    model = build_baseline_model()
    model.fit(
        X_train,
        y_train,
        eval_set=[(X_tune, y_tune)],
        eval_metric="average_precision",
        callbacks=[
            lgb.early_stopping(
                stopping_rounds=100,
                first_metric_only=True,
                verbose=False,
            )
        ],
    )
    y_probs_test = model.predict_proba(X_test)[:, 1]
    evaluate_and_log(
        "LightGBM Baseline",
        y_test,
        y_probs_test,
        log_file,
    )
    X_validation = pd.concat([X_tune, X_cal], axis=0)
    y_validation = pd.concat([y_tune, y_cal], axis=0)
    export_model_sci_artifacts(
        artifact_dir=artifact_dir,
        model_key="lgbm_baseline",
        model_name="LightGBM Baseline",
        data_file=data_file,
        X=X,
        y=y,
        X_train=X_train,
        y_train=y_train,
        X_validation=X_validation,
        y_validation=y_validation,
        X_test=X_test,
        y_test=y_test,
        y_prob_raw=y_probs_test,
        y_prob_calibrated=y_probs_test,
        calibration=(
            "none; y_prob_calibrated intentionally duplicates y_prob_raw"
        ),
        preprocessing={
            "pipeline": "native LightGBM numeric/category conversion",
            "scope": "as implemented in prepare_data before splitting",
        },
        resampling="none",
        model_parameters={
            "boosting_type": "gbdt",
            "n_estimators": 50,
            "learning_rate": 0.05,
            "max_depth": 2,
            "num_leaves": 4,
            "min_child_samples": 500,
            "max_bin": 32,
            "reg_lambda": 1.0,
        },
        split_strategy={
            "test": "stratified 10%, random_state=42",
            "development": "remaining 90%",
            "train": "77.78% of development, random_state=42",
            "validation_pool": "22.22% of development",
            "tune_calibration": (
                "validation pool split 50/50, random_state=43; tune used for "
                "early stopping and calibration half retained but unused"
            ),
        },
    )
    with open(log_file, "a", encoding="utf-8") as stream:
        stream.write(f"\nSCI绘图数据包: {artifact_dir}\n")

    print(f"日志已保存: {log_file}")
    return log_file


def main():
    print("--- 启动 LightGBM Baseline 独立实验 ---")
    if not os.path.exists(DEFAULT_DATA_FILE):
        raise FileNotFoundError(f"找不到数据文件: {DEFAULT_DATA_FILE}")
    X, y = prepare_data(DEFAULT_DATA_FILE)
    run_experiment(X, y, DEFAULT_LOG_DIR, data_file=DEFAULT_DATA_FILE)
    print("--- LightGBM Baseline 实验结束 ---")


if __name__ == "__main__":
    main()
