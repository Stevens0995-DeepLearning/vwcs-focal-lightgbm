"""Leakage-audited cleaning for the semi-synthetic Focal benchmark.

All preprocessing statistics are fitted on the locked development split.
Fine Amount is used only to verify Target_Penalty and is never exported.
OOF predictions are used only to audit hard development samples; no row is
deleted and no OOF-derived field is included in the predictive dataset.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold, train_test_split


TARGET_THRESHOLD = 170734.80
RANDOM_STATE = 42
MECHANISM_RANDOM_STATE = 20260801
DEFAULT_INPUT = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据"
    r"\NH_ProviderInfo_Focal_Synthetic_Benchmark.csv"
)
DEFAULT_RAW_WIDE = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据"
    r"\NH_ProviderInfo_Combine.csv"
)
# The benchmark generator read this processed table row-for-row.  It retains
# the fixed target but excludes Fine Amount, so it is the only valid source for
# row-level target provenance after identifiers were removed from the benchmark.
DEFAULT_RAW_WIDE = DEFAULT_INPUT.with_name("NH_ProviderInfo_Combine.csv")
DEFAULT_SPLIT = DEFAULT_INPUT.with_name(
    f"{DEFAULT_INPUT.stem}_split_manifest.csv"
)
DEFAULT_OUTPUT = DEFAULT_INPUT.with_name(
    "NH_ProviderInfo_Focal_Synthetic_Benchmark_Cleaned_Multimechanism.csv"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalize_text(series: pd.Series) -> pd.Series:
    normalized = series.astype("string").str.strip()
    normalized = normalized.replace(
        {"": pd.NA, "nan": pd.NA, "None": pd.NA, "<NA>": pd.NA}
    )
    return normalized.fillna("__MISSING__")


def _validate_row_alignment(
    benchmark: pd.DataFrame,
    raw: pd.DataFrame,
) -> dict[str, int]:
    if len(benchmark) != len(raw):
        raise ValueError(
            f"Row-count mismatch: benchmark={len(benchmark)}, raw={len(raw)}"
        )
    checks: dict[str, int] = {}
    columns = [
        "State",
        "Ownership Type",
        "Provider Type",
        "Reported Total Nurse Staffing Hours per Resident per Day",
        "Rating Cycle 1 Total Number of Health Deficiencies",
    ]
    for column in columns:
        if column not in benchmark.columns or column not in raw.columns:
            continue
        left = benchmark[column]
        right = raw[column]
        if pd.api.types.is_numeric_dtype(left) or pd.api.types.is_numeric_dtype(
            right
        ):
            equal = np.isclose(
                pd.to_numeric(left, errors="coerce"),
                pd.to_numeric(right, errors="coerce"),
                equal_nan=True,
            )
        else:
            equal = _normalize_text(left).eq(_normalize_text(right)).to_numpy()
        mismatches = int((~equal).sum())
        checks[column] = mismatches
        if mismatches:
            raise ValueError(
                f"Row-order alignment failed for {column}: {mismatches} mismatches"
            )
    if not checks:
        raise ValueError("No shared context columns available for row alignment.")
    return checks


def _load_and_validate_split(
    split_path: Path,
    target: pd.Series,
) -> pd.DataFrame:
    if not split_path.exists():
        indices = np.arange(len(target))
        remaining, test = train_test_split(
            indices,
            test_size=0.10,
            random_state=RANDOM_STATE,
            stratify=target,
        )
        development, tune_calibration = train_test_split(
            remaining,
            test_size=0.2222,
            random_state=RANDOM_STATE,
            stratify=target.iloc[remaining],
        )
        threshold, calibration = train_test_split(
            tune_calibration,
            test_size=0.50,
            random_state=RANDOM_STATE + 1,
            stratify=target.iloc[tune_calibration],
        )
        split_name = np.full(len(target), "", dtype=object)
        split_name[development] = "development"
        split_name[calibration] = "calibration"
        split_name[threshold] = "threshold"
        split_name[test] = "test"
        split_path.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(
            {
                "sample_id": indices,
                "split": split_name,
                "y_true": target.to_numpy(dtype=int),
            }
        ).to_csv(split_path, index=False, encoding="utf-8-sig")

    split = pd.read_csv(split_path, low_memory=False)
    required = {"sample_id", "split", "y_true"}
    missing = required - set(split.columns)
    if missing:
        raise ValueError(f"Split manifest missing columns: {sorted(missing)}")
    split = split.sort_values("sample_id").reset_index(drop=True)
    expected_ids = np.arange(len(target))
    if not np.array_equal(split["sample_id"].to_numpy(), expected_ids):
        raise ValueError("Split manifest sample_id does not match row order.")
    if not np.array_equal(
        pd.to_numeric(split["y_true"]).astype(int).to_numpy(),
        target.astype(int).to_numpy(),
    ):
        raise ValueError("Split manifest labels do not match verified target.")
    expected_names = {"development", "calibration", "threshold", "test"}
    if set(split["split"]) != expected_names:
        raise ValueError(
            f"Unexpected split names: {sorted(set(split['split']))}"
        )
    return split


def _fit_development_preprocessor(
    predictors: pd.DataFrame,
    development_ids: np.ndarray,
    *,
    lower_quantile: float,
    upper_quantile: float,
    rare_min_count: int,
) -> tuple[pd.DataFrame, dict]:
    cleaned = predictors.copy()
    development = predictors.iloc[development_ids]
    numeric_columns = predictors.select_dtypes(
        include=[np.number, "bool"]
    ).columns.tolist()
    categorical_columns = [
        column for column in predictors.columns if column not in numeric_columns
    ]
    audit = {
        "fit_scope": "development only",
        "development_rows": int(len(development_ids)),
        "numeric": {},
        "categorical": {},
        "added_missing_indicators": [],
    }

    numeric_blocks: list[pd.Series] = []
    for column in numeric_columns:
        all_values = pd.to_numeric(cleaned[column], errors="coerce").replace(
            [np.inf, -np.inf], np.nan
        )
        dev_values = pd.to_numeric(
            development[column], errors="coerce"
        ).replace([np.inf, -np.inf], np.nan)
        non_missing = dev_values.dropna()
        if non_missing.empty:
            raise ValueError(
                f"Numeric feature {column!r} has no development observations."
            )
        median = float(non_missing.median())
        lower = float(non_missing.quantile(lower_quantile))
        upper = float(non_missing.quantile(upper_quantile))
        if lower > upper:
            lower, upper = upper, lower
        missing_indicator = all_values.isna().astype("int8")
        if int(missing_indicator.sum()) > 0:
            indicator_name = f"Missing__{column}"
            missing_indicator.name = indicator_name
            numeric_blocks.append(missing_indicator)
            audit["added_missing_indicators"].append(indicator_name)
        clipped = all_values.clip(lower=lower, upper=upper).fillna(median)
        cleaned[column] = clipped.astype("float32")
        audit["numeric"][column] = {
            "development_median": median,
            "development_lower_bound": lower,
            "development_upper_bound": upper,
            "lower_quantile": lower_quantile,
            "upper_quantile": upper_quantile,
            "missing_all_rows": int(all_values.isna().sum()),
            "missing_development": int(dev_values.isna().sum()),
            "clipped_low_all_rows": int((all_values < lower).sum()),
            "clipped_high_all_rows": int((all_values > upper).sum()),
        }

    for column in categorical_columns:
        all_values = _normalize_text(cleaned[column])
        dev_values = _normalize_text(development[column])
        counts = dev_values.value_counts(dropna=False)
        retained = sorted(
            str(value)
            for value, count in counts.items()
            if int(count) >= rare_min_count
        )
        retained_set = set(retained)
        mapped = all_values.where(
            all_values.isin(retained_set), "__RARE_OR_UNSEEN__"
        )
        cleaned[column] = mapped.astype("category")
        audit["categorical"][column] = {
            "rare_min_count": rare_min_count,
            "development_unique_before": int(dev_values.nunique()),
            "retained_levels": retained,
            "mapped_to_rare_all_rows": int(
                mapped.eq("__RARE_OR_UNSEEN__").sum()
            ),
        }

    if numeric_blocks:
        cleaned = pd.concat([cleaned] + numeric_blocks, axis=1)
    return cleaned, audit


def _forbidden_predictor_reason(column: str) -> str | None:
    """Return the prespecified exclusion reason for an unsafe predictor."""

    lowered = column.strip().lower().replace("_", " ")
    rules = {
        "Fine Amount or a transformation/proxy": (
            "fine",
            "civil money penalty",
            "penalty amount",
            "penalty count",
        ),
        "penalty date or enforcement date": (
            "penalty date",
            "fine date",
            "enforcement date",
            "action date",
        ),
        "concurrent/post-outcome enforcement information": (
            "enforcement outcome",
            "penalty outcome",
            "action result",
            "citation result",
            "revisit result",
        ),
        "direct label-identifying code": (
            "target code",
            "label code",
            "outcome code",
            "penalty flag",
            "positive flag",
        ),
    }
    for reason, terms in rules.items():
        if any(term in lowered for term in terms):
            return reason
    return None


def _add_multimechanism_scores(
    predictors: pd.DataFrame,
    target: pd.Series,
    split: pd.DataFrame,
    *,
    seed: int = MECHANISM_RANDOM_STATE,
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Add five overlapping simulation scores without exporting mechanism IDs.

    Distribution parameters are prespecified constants; no empirical statistic
    from calibration, threshold, or test labels/features is calculated.  The
    hidden mechanism assignment is exported only to a separate audit file and
    must never be supplied to a model.
    """

    rng = np.random.default_rng(seed)
    n_rows = len(target)
    y = target.to_numpy(dtype=np.int8)
    mechanism_names = np.array(
        [
            "clinical_high_risk",
            "regulatory_deficit",
            "staffing_shortage",
            "claims_anomaly",
            "multifactor_interaction",
        ],
        dtype=object,
    )
    mechanism_weights = np.array([0.24, 0.20, 0.20, 0.18, 0.18])

    hidden_mechanism = np.full(n_rows, "background_overlap", dtype=object)
    positive_ids = np.flatnonzero(y == 1)
    hidden_mechanism[positive_ids] = rng.choice(
        mechanism_names,
        size=len(positive_ids),
        p=mechanism_weights,
    )

    # A small set of negatives deliberately resembles one positive mechanism.
    # This preserves class overlap and prevents any score from encoding y exactly.
    negative_ids = np.flatnonzero(y == 0)
    negative_mimic = rng.random(len(negative_ids)) < 0.06
    mimic_ids = negative_ids[negative_mimic]
    hidden_mechanism[mimic_ids] = rng.choice(
        mechanism_names,
        size=len(mimic_ids),
        p=mechanism_weights,
    )

    score_columns = [
        "Clinical_High_Risk_Score",
        "Historical_Regulatory_Deficit_Score",
        "Staffing_Shortage_Risk_Score",
        "Historical_Claims_Anomaly_Score",
    ]
    scores = rng.beta(2.0, 6.0, size=(n_rows, len(score_columns))) * 100.0
    direct_mechanisms = mechanism_names[:4]
    weak_positive = np.zeros(n_rows, dtype=bool)
    weak_positive[positive_ids] = rng.random(len(positive_ids)) < 0.12

    for score_index, mechanism in enumerate(direct_mechanisms):
        strong_positive = (
            (y == 1)
            & (hidden_mechanism == mechanism)
            & ~weak_positive
        )
        weak = (
            (y == 1)
            & (hidden_mechanism == mechanism)
            & weak_positive
        )
        mimic = (y == 0) & (hidden_mechanism == mechanism)
        scores[strong_positive, score_index] = (
            rng.beta(6.0, 2.0, strong_positive.sum()) * 100.0
        )
        scores[weak, score_index] = (
            rng.beta(3.0, 3.0, weak.sum()) * 100.0
        )
        scores[mimic, score_index] = (
            rng.beta(5.0, 2.3, mimic.sum()) * 100.0
        )

    multifactor_positive = (
        (y == 1) & (hidden_mechanism == "multifactor_interaction")
    )
    multifactor_mimic = (
        (y == 0) & (hidden_mechanism == "multifactor_interaction")
    )
    scores[multifactor_positive] = (
        40.0
        + rng.beta(3.5, 2.3, size=(multifactor_positive.sum(), 4)) * 45.0
    )
    scores[multifactor_mimic] = (
        35.0
        + rng.beta(3.0, 2.8, size=(multifactor_mimic.sum(), 4)) * 45.0
    )

    sorted_scores = np.sort(scores, axis=1)
    interaction_score = np.sqrt(
        sorted_scores[:, -1] * sorted_scores[:, -2]
    )
    interaction_score += rng.normal(0.0, 3.0, n_rows)

    result = predictors.copy()
    for index, column in enumerate(score_columns):
        result[column] = np.clip(scores[:, index], 0.0, 100.0).round(6)
    result["Multifactor_Interaction_Risk_Score"] = np.clip(
        interaction_score, 0.0, 100.0
    ).round(6)

    audit = pd.DataFrame(
        {
            "sample_id": np.arange(n_rows, dtype=int),
            "split": split.sort_values("sample_id")["split"].to_numpy(),
            "y_true": y,
            "hidden_simulation_mechanism": hidden_mechanism,
            "weak_positive_overlap": weak_positive.astype("int8"),
            "negative_overlap_mimic": (
                (y == 0) & (hidden_mechanism != "background_overlap")
            ).astype("int8"),
            "retained_in_cleaned_output": np.ones(n_rows, dtype="int8"),
            "included_as_model_predictor": np.zeros(n_rows, dtype="int8"),
        }
    )
    positive_counts = (
        audit.loc[audit["y_true"].eq(1), "hidden_simulation_mechanism"]
        .value_counts()
        .to_dict()
    )
    summary = {
        "simulation_only": True,
        "seed": seed,
        "distribution_parameters": "prespecified; not estimated from holdouts",
        "positive_mechanism_counts": {
            str(key): int(value) for key, value in positive_counts.items()
        },
        "weak_positive_overlap_count": int(weak_positive.sum()),
        "negative_overlap_mimic_count": int(
            audit["negative_overlap_mimic"].sum()
        ),
        "mechanism_identifier_exported_to_model_data": False,
    }
    return result, audit, summary


def _build_development_oof_audit(
    predictors: pd.DataFrame,
    target: pd.Series,
    development_ids: np.ndarray,
    *,
    folds: int,
) -> tuple[pd.DataFrame, dict]:
    X_dev = predictors.iloc[development_ids].copy()
    y_dev = target.iloc[development_ids].astype(int).reset_index(drop=True)
    X_dev = X_dev.reset_index(drop=True)
    oof = np.full(len(X_dev), np.nan, dtype=float)
    splitter = StratifiedKFold(
        n_splits=folds, shuffle=True, random_state=RANDOM_STATE
    )
    fold_rows = []
    for fold, (train_idx, valid_idx) in enumerate(
        splitter.split(X_dev, y_dev), start=1
    ):
        y_train = y_dev.iloc[train_idx]
        ratio = float((y_train == 0).sum() / (y_train == 1).sum())
        model = lgb.LGBMClassifier(
            objective="binary",
            n_estimators=800,
            learning_rate=0.03,
            num_leaves=15,
            max_depth=5,
            min_child_samples=50,
            subsample=0.85,
            subsample_freq=1,
            colsample_bytree=0.85,
            reg_alpha=0.1,
            reg_lambda=5.0,
            scale_pos_weight=ratio,
            random_state=RANDOM_STATE + fold,
            n_jobs=-1,
            verbose=-1,
        )
        model.fit(
            X_dev.iloc[train_idx],
            y_train,
            eval_set=[(X_dev.iloc[valid_idx], y_dev.iloc[valid_idx])],
            eval_metric="average_precision",
            callbacks=[
                lgb.early_stopping(
                    stopping_rounds=80,
                    first_metric_only=True,
                    verbose=False,
                )
            ],
        )
        probabilities = model.predict_proba(X_dev.iloc[valid_idx])[:, 1]
        oof[valid_idx] = probabilities
        fold_rows.append(
            {
                "fold": fold,
                "validation_rows": int(len(valid_idx)),
                "validation_positives": int(y_dev.iloc[valid_idx].sum()),
                "PR_AUC": float(
                    average_precision_score(y_dev.iloc[valid_idx], probabilities)
                ),
                "ROC_AUC": float(
                    roc_auc_score(y_dev.iloc[valid_idx], probabilities)
                ),
                "best_iteration": int(model.best_iteration_ or 0),
            }
        )
    if np.isnan(oof).any():
        raise RuntimeError("OOF audit did not score every development sample.")

    positive_scores = oof[y_dev.to_numpy() == 1]
    negative_scores = oof[y_dev.to_numpy() == 0]
    hard_positive_cutoff = float(np.quantile(positive_scores, 0.25))
    hard_negative_cutoff = float(np.quantile(negative_scores, 0.95))
    hard_type = np.full(len(oof), "not_flagged", dtype=object)
    hard_type[(y_dev.to_numpy() == 1) & (oof <= hard_positive_cutoff)] = (
        "hard_positive_bottom_quartile"
    )
    hard_type[(y_dev.to_numpy() == 0) & (oof >= hard_negative_cutoff)] = (
        "hard_negative_top_5pct"
    )
    audit = pd.DataFrame(
        {
            "sample_id": development_ids,
            "split": "development",
            "y_true": y_dev.to_numpy(),
            "oof_probability": oof,
            "hard_sample_type": hard_type,
            "retained_in_cleaned_output": 1,
        }
    ).sort_values("sample_id")
    summary = {
        "scope": "development only; predictions are out-of-fold",
        "folds": folds,
        "overall_PR_AUC": float(average_precision_score(y_dev, oof)),
        "overall_ROC_AUC": float(roc_auc_score(y_dev, oof)),
        "hard_positive_cutoff": hard_positive_cutoff,
        "hard_negative_cutoff": hard_negative_cutoff,
        "hard_positive_count": int(
            (audit["hard_sample_type"] == "hard_positive_bottom_quartile").sum()
        ),
        "hard_negative_count": int(
            (audit["hard_sample_type"] == "hard_negative_top_5pct").sum()
        ),
        "deleted_due_to_oof": 0,
        "fold_metrics": fold_rows,
    }
    return audit, summary


def clean_benchmark(
    input_path: Path,
    raw_wide_path: Path,
    split_path: Path,
    output_path: Path,
    *,
    folds: int = 5,
    lower_quantile: float = 0.005,
    upper_quantile: float = 0.995,
    rare_min_count: int = 20,
) -> None:
    benchmark = pd.read_csv(input_path, low_memory=False)
    raw = pd.read_csv(raw_wide_path, low_memory=False)
    if "Target_Penalty" not in benchmark.columns:
        raise ValueError("Benchmark does not contain Target_Penalty.")

    alignment_checks = _validate_row_alignment(benchmark, raw)
    benchmark_target = pd.to_numeric(
        benchmark["Target_Penalty"], errors="raise"
    ).astype("int8")
    if "Fine Amount" in raw.columns:
        fine = pd.to_numeric(raw["Fine Amount"], errors="coerce").fillna(0.0)
        verified_target = (fine > TARGET_THRESHOLD).astype("int8")
        target_verification = "direct row-level recomputation from Fine Amount"
    elif "Target_Penalty" in raw.columns:
        verified_target = pd.to_numeric(
            raw["Target_Penalty"], errors="raise"
        ).astype("int8")
        target_verification = (
            "row-level equality with the exact benchmark source table; "
            "source target provenance is Fine Amount > 170734.80"
        )
    else:
        raise ValueError(
            "Target source must contain Fine Amount or Target_Penalty."
        )
    target_mismatches = int(
        (
            benchmark_target.to_numpy()
            != verified_target.to_numpy()
        ).sum()
    )
    if target_mismatches:
        raise ValueError(
            f"Benchmark target disagrees with Fine Amount threshold in "
            f"{target_mismatches} rows."
        )

    split = _load_and_validate_split(split_path, verified_target)
    development_ids = split.loc[
        split["split"].eq("development"), "sample_id"
    ].to_numpy(dtype=int)

    exclusion_rows = []
    for column in benchmark.columns:
        if column == "Target_Penalty":
            continue
        reason = _forbidden_predictor_reason(column)
        if reason is not None:
            exclusion_rows.append({"column": column, "reason": reason})
    excluded_columns = {row["column"] for row in exclusion_rows}
    predictor_columns = [
        column
        for column in benchmark.columns
        if column != "Target_Penalty"
        and column not in excluded_columns
    ]
    predictors = benchmark[predictor_columns].copy()
    cleaned_predictors, preprocessing_audit = _fit_development_preprocessor(
        predictors,
        development_ids,
        lower_quantile=lower_quantile,
        upper_quantile=upper_quantile,
        rare_min_count=rare_min_count,
    )
    cleaned_predictors, mechanism_audit, mechanism_summary = (
        _add_multimechanism_scores(
            cleaned_predictors,
            verified_target,
            split,
        )
    )
    cleaned = pd.concat(
        [verified_target.rename("Target_Penalty"), cleaned_predictors], axis=1
    )

    forbidden = [
        column
        for column in cleaned.columns
        if column != "Target_Penalty"
        and _forbidden_predictor_reason(column) is not None
    ]
    if forbidden:
        raise RuntimeError(f"Leakage fields survived cleaning: {forbidden}")
    if len(cleaned) != len(benchmark):
        raise RuntimeError("Cleaning unexpectedly deleted rows.")
    if not cleaned["Target_Penalty"].equals(verified_target):
        raise RuntimeError("Verified target changed during cleaning.")

    oof_audit, oof_summary = _build_development_oof_audit(
        cleaned_predictors,
        verified_target,
        development_ids,
        folds=folds,
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    cleaned.to_csv(output_path, index=False, encoding="utf-8-sig")
    output_split_path = output_path.with_name(
        f"{output_path.stem}_split_manifest.csv"
    )
    split.to_csv(output_split_path, index=False, encoding="utf-8-sig")
    hard_path = output_path.with_name(
        f"{output_path.stem}_development_oof_hard_sample_audit.csv"
    )
    oof_audit.to_csv(hard_path, index=False, encoding="utf-8-sig")
    mechanism_path = output_path.with_name(
        f"{output_path.stem}_hidden_mechanism_audit_DO_NOT_MODEL.csv"
    )
    mechanism_audit.to_csv(
        mechanism_path, index=False, encoding="utf-8-sig"
    )
    exclusion_path = output_path.with_name(
        f"{output_path.stem}_excluded_field_audit.csv"
    )
    pd.DataFrame(
        exclusion_rows,
        columns=["column", "reason"],
    ).to_csv(exclusion_path, index=False, encoding="utf-8-sig")
    protocol_path = output_path.with_name(
        f"{output_path.stem}_resampling_experiment_protocol.csv"
    )
    protocol_rows = [
        {
            "policy_id": "P1",
            "model_or_stage": "source dataset",
            "applicable_split": "all original rows",
            "resampling_method": "none",
            "allowed": False,
            "requirement": "Preserve natural 5% positive prevalence",
            "implementation": (
                "No label changes, synthetic row addition, undersampling, or "
                "oversampling in the exported dataset"
            ),
        },
        {
            "policy_id": "P2",
            "model_or_stage": "pre-split processing",
            "applicable_split": "before fixed split",
            "resampling_method": "SMOTE",
            "allowed": False,
            "requirement": "Never apply SMOTE before splitting",
            "implementation": "Fixed manifest is loaded before preprocessing",
        },
        {
            "policy_id": "P3",
            "model_or_stage": "focal_lgbm",
            "applicable_split": "development training data",
            "resampling_method": "SMOTE",
            "allowed": False,
            "requirement": "Focal model must not use SMOTE",
            "implementation": "Use original imbalanced development samples",
        },
        {
            "policy_id": "P4",
            "model_or_stage": "smote_lgbm",
            "applicable_split": "training partition inside development only",
            "resampling_method": "SMOTE",
            "allowed": True,
            "requirement": "SMOTE-LightGBM is an independent control model",
            "implementation": (
                "fit_resample is permitted only after split and train-fitted "
                "transformation"
            ),
        },
        {
            "policy_id": "P5",
            "model_or_stage": "all models",
            "applicable_split": "calibration / threshold / test",
            "resampling_method": "any",
            "allowed": False,
            "requirement": "Never resample evaluation partitions",
            "implementation": "Evaluate every model on untouched original rows",
        },
    ]
    pd.DataFrame(protocol_rows).to_csv(
        protocol_path, index=False, encoding="utf-8-sig"
    )

    feature_rows = []
    for column in cleaned.columns:
        if column == "Target_Penalty":
            role = "target"
            source = f"Fine Amount > {TARGET_THRESHOLD:.2f}; Fine Amount excluded"
        elif column.endswith("_Score"):
            role = "semi-synthetic overlapping mechanism score"
            source = (
                "prespecified simulation; hidden mechanism ID excluded from model"
            )
        elif column.startswith("Missing__"):
            role = "development-fitted missingness indicator"
            source = "derived without labels; retained for prediction"
        elif column in predictor_columns:
            role = "cleaned predictor"
            source = "source benchmark; preprocessing fitted on development only"
        else:
            role = "derived predictor"
            source = "development-fitted preprocessing"
        feature_rows.append(
            {
                "column": column,
                "role": role,
                "source_or_rule": source,
                "uses_Fine_Amount_as_predictor": False,
                "uses_OOF_hard_flag_as_predictor": False,
            }
        )
    feature_path = output_path.with_name(
        f"{output_path.stem}_feature_manifest.csv"
    )
    pd.DataFrame(feature_rows).to_csv(
        feature_path, index=False, encoding="utf-8-sig"
    )

    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input_path": str(input_path),
        "input_sha256": sha256(input_path),
        "target_source_path": str(raw_wide_path),
        "target_source_sha256": sha256(raw_wide_path),
        "split_path": str(split_path),
        "split_sha256": sha256(split_path),
        "output_path": str(output_path),
        "rows_before": int(len(benchmark)),
        "rows_after": int(len(cleaned)),
        "rows_deleted": 0,
        "positive_count": int(verified_target.sum()),
        "positive_prevalence": float(verified_target.mean()),
        "target_definition": f"Fine Amount > {TARGET_THRESHOLD:.2f}",
        "target_verification_method": target_verification,
        "target_mismatches_against_raw_wide": target_mismatches,
        "Fine_Amount_in_predictors": False,
        "Fine_Amount_transform_in_predictors": False,
        "preprocessing_statistics_scope": "development split only",
        "split_counts": {
            str(key): int(value)
            for key, value in split["split"].value_counts().items()
        },
        "split_positive_counts": {
            str(key): int(value)
            for key, value in split.groupby("split")["y_true"].sum().items()
        },
        "row_alignment_context_mismatches": alignment_checks,
        "preprocessing": preprocessing_audit,
        "prespecified_excluded_fields": exclusion_rows,
        "confirmed_data_entry_errors_found": 0,
        "rows_deleted_as_confirmed_data_entry_errors": 0,
        "multimechanism_simulation": mechanism_summary,
        "class_imbalance_and_resampling_contract": {
            "natural_positive_count": int(verified_target.sum()),
            "natural_negative_count": int((verified_target == 0).sum()),
            "natural_positive_prevalence": float(verified_target.mean()),
            "pre_split_SMOTE": False,
            "focal_lgbm_uses_SMOTE": False,
            "test_set_resampled": False,
            "calibration_set_resampled": False,
            "threshold_set_resampled": False,
            "smote_lgbm_role": "independent comparison model",
            "smote_lgbm_allowed_scope": (
                "training partition inside development only"
            ),
        },
        "oof_hard_sample_audit": oof_summary,
        "hard_samples_deleted": 0,
        "boundary_samples_deleted": 0,
        "class_overlap_samples_deleted": 0,
        "warning": (
            "The source benchmark remains a semi-synthetic oracle dataset: its "
            "three core predictors were originally generated conditional on the "
            "target, and the five added mechanism scores are also explicitly "
            "target-conditional simulation variables. Cleaning removes direct "
            "Fine Amount leakage and enforces split-safe preprocessing, but "
            "cannot turn the benchmark into an observational real-world dataset."
        ),
    }
    metadata["output_sha256"] = sha256(output_path)
    metadata_path = output_path.with_name(
        f"{output_path.stem}_cleaning_metadata.json"
    )
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"Cleaned dataset: {output_path}")
    print(f"Rows retained  : {len(cleaned):,}/{len(benchmark):,}")
    print(
        f"Verified target: positives={int(verified_target.sum()):,} "
        f"({verified_target.mean():.2%}); mismatches={target_mismatches}"
    )
    print(f"Feature manifest: {feature_path}")
    print(f"Split manifest  : {output_split_path}")
    print(f"OOF hard audit  : {hard_path}")
    print(f"Mechanism audit : {mechanism_path} (DO NOT MODEL)")
    print(f"Excluded fields : {exclusion_path}")
    print(f"Sampling policy : {protocol_path}")
    print(f"Metadata        : {metadata_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Clean the Focal benchmark with development-only statistics."
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument(
        "--target-source",
        "--raw-wide",
        dest="raw_wide",
        type=Path,
        default=DEFAULT_RAW_WIDE,
        help=(
            "Exact row-aligned source table used to create the benchmark; "
            "--raw-wide is retained as a backward-compatible alias."
        ),
    )
    parser.add_argument("--split", type=Path, default=DEFAULT_SPLIT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--lower-quantile", type=float, default=0.005)
    parser.add_argument("--upper-quantile", type=float, default=0.995)
    parser.add_argument("--rare-min-count", type=int, default=20)
    args = parser.parse_args()
    if args.folds < 2:
        parser.error("--folds must be at least 2")
    if not 0 <= args.lower_quantile < args.upper_quantile <= 1:
        parser.error("quantiles must satisfy 0 <= lower < upper <= 1")
    if args.rare_min_count < 1:
        parser.error("--rare-min-count must be positive")
    return args


if __name__ == "__main__":
    cli = parse_args()
    clean_benchmark(
        cli.input,
        cli.raw_wide,
        cli.split,
        cli.output,
        folds=cli.folds,
        lower_quantile=cli.lower_quantile,
        upper_quantile=cli.upper_quantile,
        rare_min_count=cli.rare_min_count,
    )
