"""Shared, model-agnostic exports for later SCI figure aggregation."""

import json
import os

import numpy as np
import pandas as pd


SCHEMA_VERSION = "1.0"
LOCKED_THRESHOLD = 0.20


def apply_platt_calibrator(calibrator, raw_probabilities):
    """Apply the project's probability-to-logit Platt mapping."""
    epsilon = 1e-6
    probabilities = np.clip(
        np.asarray(raw_probabilities, dtype="float64"),
        epsilon,
        1.0 - epsilon,
    )
    logits = np.log(probabilities / (1.0 - probabilities)).reshape(-1, 1)
    return calibrator.predict_proba(logits)[:, 1]


def _split_metadata(y_values):
    values = np.asarray(y_values, dtype=int)
    positive = int(values.sum())
    return {
        "n": int(len(values)),
        "positive": positive,
        "negative": int(len(values) - positive),
        "prevalence": float(values.mean()),
    }


def export_model_sci_artifacts(
    *,
    artifact_dir,
    model_key,
    model_name,
    data_file,
    X,
    y,
    X_train,
    y_train,
    X_validation,
    y_validation,
    X_test,
    y_test,
    y_prob_raw,
    y_prob_calibrated,
    calibration,
    preprocessing,
    resampling,
    model_parameters,
    split_strategy=None,
):
    """Write the minimal standardized package required for Figures 1, 2, 3 and 5.

    Figures 4, 6 and 7 are Focal-only and remain exported by the Focal model.
    Other models deliberately do not emit figures, confusion-matrix files,
    standalone metric tables or SHAP files.
    """
    os.makedirs(artifact_dir, exist_ok=True)
    y_true = np.asarray(y_test, dtype=int)
    raw = np.asarray(y_prob_raw, dtype=float)
    calibrated = np.asarray(y_prob_calibrated, dtype=float)
    if not (len(X_test) == len(y_true) == len(raw) == len(calibrated)):
        raise ValueError(f"{model_key}: test prediction lengths are inconsistent")

    predictions = pd.DataFrame(
        {
            "sample_id": X_test.index.astype(str),
            "model_key": model_key,
            "split": "test",
            "y_true": y_true,
            "raw_margin": np.full(len(y_true), np.nan),
            "y_prob_raw": raw,
            "y_prob_calibrated": calibrated,
        }
    )
    predictions["y_pred_locked_0_20"] = (
        predictions["y_prob_calibrated"] >= LOCKED_THRESHOLD
    ).astype(int)
    predictions.to_csv(
        os.path.join(artifact_dir, "test_predictions.csv"),
        index=False,
        encoding="utf-8-sig",
    )

    categorical_features = [
        str(column)
        for column in X.columns
        if isinstance(X[column].dtype, pd.CategoricalDtype)
    ]
    metadata = {
        "schema_version": SCHEMA_VERSION,
        "model_key": model_key,
        "model_name": model_name,
        "data_file": os.path.abspath(data_file) if data_file else None,
        "label_column": "Target_Penalty",
        "label_rule": "Fine Amount > 170734.80",
        "sample_id_rule": "zero-based original CSV row index",
        "total_samples": int(len(y)),
        "positive_samples": int(np.asarray(y, dtype=int).sum()),
        "prevalence": float(np.asarray(y, dtype=int).mean()),
        "feature_count": int(X.shape[1]),
        "categorical_feature_count": int(len(categorical_features)),
        "categorical_features": categorical_features,
        "split_strategy": split_strategy
        or {
            "test": "stratified 10%, random_state=42",
            "train": "77.78% of remaining 90%, stratified, random_state=42",
            "validation": "22.22% of remaining 90%",
        },
        "splits": {
            "train": _split_metadata(y_train),
            "validation": _split_metadata(y_validation),
            "test": _split_metadata(y_test),
        },
        "preprocessing": preprocessing,
        "resampling": resampling,
        "calibration": calibration,
        "threshold_policy": "prespecified locked threshold",
        "locked_threshold": LOCKED_THRESHOLD,
        "model_parameters": model_parameters,
        "test_usage": "locked final evaluation only",
        "figure_inputs": {
            "figure_1": ["experiment_metadata.json"],
            "figure_2": ["test_predictions.csv:y_true,y_prob_raw"],
            "figure_3": ["test_predictions.csv:y_true,y_prob_calibrated"],
            "figure_5": [
                "test_predictions.csv:y_true,y_prob_raw,y_prob_calibrated"
            ],
        },
    }
    with open(
        os.path.join(artifact_dir, "experiment_metadata.json"),
        "w",
        encoding="utf-8",
    ) as stream:
        json.dump(metadata, stream, ensure_ascii=False, indent=2)

    manifest = {
        "schema_version": SCHEMA_VERSION,
        "model_key": model_key,
        "artifact_dir": os.path.abspath(artifact_dir),
        "files": {
            "metadata": "experiment_metadata.json",
            "test_predictions": "test_predictions.csv",
        },
    }
    with open(
        os.path.join(artifact_dir, "artifact_manifest.json"),
        "w",
        encoding="utf-8",
    ) as stream:
        json.dump(manifest, stream, ensure_ascii=False, indent=2)
    print(f"[SCI绘图数据] {model_key}: {artifact_dir}")
    return manifest
