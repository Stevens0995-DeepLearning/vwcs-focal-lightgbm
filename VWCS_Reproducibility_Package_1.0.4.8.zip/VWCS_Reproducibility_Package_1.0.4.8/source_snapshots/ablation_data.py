"""Shared, locked data protocol for the component-ablation experiment.

The feature preparation and four-way split are executed from the *unchanged*
Focal and LightGBM-baseline source files, respectively.  Source functions are
loaded through the Python AST so importing the legacy scripts cannot start an
experiment or write into their usual log directories.
"""

from __future__ import annotations

import ast
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_DATA = Path(
    r"C:\ASQ备考\博士论文\西藏项目\资料准备\数据\实验数据\NH_ProviderInfo_Combine.csv"
)
FOCAL_SOURCE = PROJECT_DIR / "LightGBM + Focal Loss Final.py"
BASELINE_SOURCE = PROJECT_DIR / "LightGBM baseline.py"


def source_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_unchanged_function(path: Path, name: str, namespace: dict):
    """Compile exactly one function definition from an existing model file."""
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    matches = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == name
    ]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one {name} definition in {path}")
    module = ast.fix_missing_locations(ast.Module(body=matches, type_ignores=[]))
    scope = dict(namespace)
    exec(compile(module, str(path), "exec"), scope)
    return scope[name]


def load_data_and_splits(data_file: Path = DEFAULT_DATA):
    if not data_file.is_file():
        raise FileNotFoundError(data_file)
    # The supplied CSV has a prepared binary target but no Fine Amount field.
    # Reject any later version that would silently feed outcome proxies to X.
    columns = pd.read_csv(data_file, nrows=0).columns.tolist()
    if columns.count("Target_Penalty") != 1:
        raise ValueError("Expected exactly one Target_Penalty column")
    prohibited = [
        c for c in columns if c != "Target_Penalty" and
        ("fine amount" in c.casefold() or "fine_amount" in c.casefold())
    ]
    if prohibited:
        raise ValueError(f"Outcome-derived predictors are not allowed: {prohibited}")

    prepare_data = load_unchanged_function(
        FOCAL_SOURCE, "prepare_data", {"pd": pd, "np": np}
    )
    split_data = load_unchanged_function(
        BASELINE_SOURCE,
        "split_data",
        {"train_test_split": train_test_split},
    )
    X, y = prepare_data(str(data_file))
    y = pd.to_numeric(y, errors="raise").astype(int)
    if set(y.unique()) != {0, 1}:
        raise ValueError("Target_Penalty must contain both 0 and 1 only")
    if not X.index.is_unique or not y.index.equals(X.index):
        raise ValueError("Original CSV row indices must be unique and aligned")
    parts = split_data(X, y)
    names = ("train", "tune", "calibration", "test")
    splits = {name: (parts[2 * i], parts[2 * i + 1]) for i, name in enumerate(names)}
    ids = [set(frame.index) for frame, _ in splits.values()]
    if sum(map(len, ids)) != len(y) or len(set.union(*ids)) != len(y):
        raise RuntimeError("The four partitions do not isolate all source rows")
    if any(target.nunique() != 2 for _, target in splits.values()):
        raise RuntimeError("Every partition must contain both classes")
    return X, y, splits


def split_manifest(splits: dict) -> dict:
    return {
        name: {
            "n": int(len(y)),
            "positive": int(y.sum()),
            "negative": int(len(y) - y.sum()),
            "sample_id_sha256": hashlib.sha256(
                np.asarray(X.index, dtype=np.int64).tobytes()
            ).hexdigest(),
        }
        for name, (X, y) in splits.items()
    }
