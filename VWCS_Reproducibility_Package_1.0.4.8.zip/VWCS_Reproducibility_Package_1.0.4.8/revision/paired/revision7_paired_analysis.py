"""Read-only postprocessing of archived predictions; no fitting or source changes."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score,roc_auc_score,brier_score_loss,recall_score,precision_score,fbeta_score,confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator,FormatStrFormatter

ROOT=Path(r'C:/ASQ备考/博士论文/西藏项目/Main coding')
LOG=ROOT/'logs'
OUT=LOG/'Revision7_Paired_Analysis_20261113'
OUT.mkdir(exist_ok=True)
NBOOT=2000; SEED=20261110
METRICS=['AP','ROC-AUC','Brier','Recall','Precision','FPR','F2']
RUNS=[('VWCS','focal_lgbm','20260802_194022','VWCS-Focal-LightGBM'),('LGBM','lgbm_baseline','20260802_185042','LightGBM'),('SVM','svm','20260802_191232','SVM'),('CAT','catboost','20260802_185720','CatBoost'),('XGB','xgboost','20260802_185005','XGBoost'),('SMOTE','smote_lgbm','20260802_185014','SMOTE-LightGBM'),('EE','easy_ensemble','20260802_185357','EasyEnsemble'),('RF','random_forest','20260802_184958','Random Forest'),('LR','lr','20260802_184933','Logistic Regression')]
models={}; sources={};audit=[];index=None;labels=None
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original_code={str(p):sha(p) for p in ROOT.glob('*.py')}
for key,folder,run,name in RUNS:
    path=LOG/'sci_model_outputs'/folder/run/'test_predictions.csv'
    z=pd.read_csv(path,float_precision='round_trip').set_index('sample_id')
    assert z.index.is_unique and len(z)==1470
    if index is None:index=z.index;labels=z.y_true.to_numpy(dtype=int)
    assert set(z.index)==set(index)
    z=z.loc[index];assert np.array_equal(labels,z.y_true)
    raw=z.y_prob_raw.to_numpy();q=z.y_prob_calibrated.to_numpy()
    assert np.isfinite(raw).all() and np.isfinite(q).all() and ((q>=0)&(q<=1)).all()
    models[key]=dict(raw=raw,q=q,name=name,panel='Historical')
    sources[str(path)]=sha(path)
    audit.append(dict(model=key,n=len(z),positive=int(labels.sum()),duplicate_ids=0,missing_predictions=0,labels_match=True))
path=LOG/'Revision4_Mechanisms/predictions.csv'
z=pd.read_csv(path,float_precision='round_trip',dtype={'ccn':str}).set_index('Unnamed: 0')
assert z.index.is_unique and set(z.index)==set(index)
z=z.loc[index];assert np.array_equal(labels,z.y_true)
for key,name in [('M0','Matched BCE'),('M1','Cost-sensitive BCE'),('M2','Class-neutral focal'),('M3','Cost-sensitive focal'),('M4','Linear vulnerability-weighted focal'),('M5','Mass-matched uniform focal')]:
    raw=z[key+'_raw'].to_numpy();q=z[key+'_q'].to_numpy()
    assert np.isfinite(raw).all() and np.isfinite(q).all() and ((q>=0)&(q<=1)).all()
    models[key]=dict(raw=raw,q=q,name=name,panel='Mechanism')
    audit.append(dict(model=key,n=len(z),positive=int(labels.sum()),duplicate_ids=0,missing_predictions=0,labels_match=True))
sources[str(path)]=sha(path)
assert labels.sum()==73
keys=list(models);n=len(index);pos=np.flatnonzero(labels);neg=np.flatnonzero(1-labels)
prepared=[]
for key in keys:
    m=models[key];o=np.argsort(-m['raw'],kind='stable');ends=np.r_[np.flatnonzero(np.diff(m['raw'][o])),n-1]
    prepared.append((o,ends,m['q']>=.2,(m['q']-labels)**2))

def calculate(c):
    P=c@labels;N=c@(1-labels);res=[]
    for o,ends,pred,sq in prepared:
        total=np.cumsum(c[o])[ends];tp_rank=np.cumsum(c[o]*labels[o])[ends];fp_rank=total-tp_rank
        ap=np.sum(np.diff(np.r_[0,tp_rank])*tp_rank/np.maximum(total,1))/P
        auc=np.sum(np.diff(np.r_[0,fp_rank])*(tp_rank+np.r_[0,tp_rank[:-1]])*.5)/(P*N)
        tp=c@(labels*pred);fp=c@((1-labels)*pred)
        res.append([ap,auc,c@sq/(P+N),tp/P,tp/(tp+fp) if tp+fp else 0,fp/N,5*tp/(4*P+tp+fp)])
    return np.array(res)

point=calculate(np.ones(n,int))
# Independent verification using expanded samples, including repeated ranks/ties.
checkrng=np.random.default_rng(17)
for j in range(4):
    sample=np.arange(n) if j==0 else np.r_[checkrng.choice(pos,len(pos)),checkrng.choice(neg,len(neg))]
    actual=calculate(np.bincount(sample,minlength=n));t=labels[sample]
    for k,key in enumerate(keys):
        r=models[key]['raw'][sample];q=models[key]['q'][sample];d=q>=.2;tn,fp,fn,tp=confusion_matrix(t,d,labels=[0,1]).ravel()
        expected=[average_precision_score(t,r),roc_auc_score(t,r),brier_score_loss(t,q),recall_score(t,d),precision_score(t,d,zero_division=0),fp/(fp+tn),fbeta_score(t,d,beta=2)]
        assert np.allclose(actual[k],expected,atol=2e-14,rtol=0),(key,j,actual[k],expected)
rng=np.random.default_rng(SEED);draws=np.empty((NBOOT,len(keys),7))
for b in range(NBOOT):
    sample=np.r_[rng.choice(pos,len(pos)),rng.choice(neg,len(neg))]
    draws[b]=calculate(np.bincount(sample,minlength=n))
    if b%500==0:print('Bootstrap',b,flush=True)
lo,hi=np.quantile(draws,[.025,.975],axis=0)
single=[]
for i,key in enumerate(keys):
    for j,metric in enumerate(METRICS):single.append(dict(panel=models[key]['panel'],model=key,name=models[key]['name'],metric=metric,estimate=point[i,j],lower=lo[i,j],upper=hi[i,j]))
single=pd.DataFrame(single);single.to_csv(OUT/'Single_Model_95CI.csv',index=False)
pairs=[('Historical','VWCS',k) for k in keys[1:9]]+[('Mechanism',a,b) for a,b in [('M4','M0'),('M4','M3'),('M4','M2'),('M4','M5'),('M3','M1'),('M1','M0'),('M2','M0'),('M3','M2')]]
paired=[]
for panel,a,b in pairs:
    ia=keys.index(a);ib=keys.index(b);delta=point[ia]-point[ib];lower,upper=np.quantile(draws[:,ia]-draws[:,ib],[.025,.975],axis=0)
    for j,metric in enumerate(METRICS):paired.append(dict(panel=panel,model=a,reference=b,metric=metric,delta=delta[j],lower=lower[j],upper=upper[j]))
paired=pd.DataFrame(paired);paired.to_csv(OUT/'Paired_Differences_95CI.csv',index=False)
pd.DataFrame(audit).to_csv(OUT/'Sample_Alignment_Audit.csv',index=False)
points=pd.DataFrame(point,index=keys,columns=METRICS);points.index.name='model';points.to_csv(OUT/'Recomputed_Point_Metrics.csv')
# Existing mechanism intervals must be reproduced, not silently replaced.
oldpath=LOG/'Revision4_Mechanisms/paired_ci.csv';sources[str(oldpath)]=sha(oldpath)
old=pd.read_csv(oldpath)
for _,r in old.iterrows():
    row=paired.query('model==@r.arm and reference==@r.ref and metric==@r.metric').iloc[0]
    assert np.allclose([row.delta,row.lower,row.upper],[r.delta,r.lo,r.hi],rtol=0,atol=2e-12)
np.savez_compressed(OUT/'Bootstrap_Metric_Draws.npz',draws=draws,models=np.array(keys),metrics=np.array(METRICS))
manifest=dict(seed=SEED,replicates=NBOOT,threshold=.2,n=n,positive=len(pos),negative=len(neg),interval='percentile, class-stratified paired facility bootstrap',difference='target minus reference',uncertainty='conditional on fitted models and recorded prediction/noise realizations',multiplicity='pointwise unadjusted intervals; no family-wise significance claims',sources=sources,original_code_sha256=original_code)
(OUT/'Analysis_Protocol.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')

plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'xtick.labelsize':8,'ytick.labelsize':9,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
selected=[('VWCS','LGBM'),('VWCS','SMOTE'),('M4','M0'),('M4','M3'),('M4','M2'),('M4','M5'),('M3','M1')]
ys=np.array([7.5,6.5,4.5,3.5,2.5,1.5,.5])
labels_plot=['VWCS − LightGBM','VWCS − SMOTE-LightGBM','M4 − M0: full vs BCE','M4 − M3: add vulnerability','M4 − M2: full vs neutral focal','M4 − M5: mass-matched','M3 − M1: add focal']
fig,axs=plt.subplots(1,3,figsize=(6.4,4.3),sharey=True)
fig.subplots_adjust(left=.335,right=.99,bottom=.17,top=.90,wspace=.35)
for j,metric in enumerate(['AP','Brier','F2']):
    ax=axs[j];ax.axvline(0,color='#707070',ls='--',lw=.8,zorder=0)
    for k,((a,b),y) in enumerate(zip(selected,ys)):
        r=paired.query('model==@a and reference==@b and metric==@metric').iloc[0];color='#236a8d' if k<2 else '#955719';marker='o' if k<2 else 's'
        ax.errorbar(r.delta,y,xerr=[[r.delta-r.lower],[r.upper-r.delta]],fmt=marker,color=color,ms=4.5,elinewidth=1.1,capsize=2.5)
    ax.set_title(['(a) AP','(b) Brier','(c) F₂'][j]);ax.set_xlabel('Difference\n'+('Lower is better' if metric=='Brier' else 'Higher is better'))
    ax.set_ylim(-.1,9);ax.set_yticks(ys);ax.set_yticklabels(labels_plot);ax.tick_params(axis='y',length=0,pad=6)
    ax.spines['left'].set_visible(False);ax.grid(axis='x',alpha=.2,lw=.5);ax.xaxis.set_major_locator(MaxNLocator(3));ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f' if metric=='Brier' else '%.2f'))
axs[0].text(-.01,8.45,'A  Historical configurations',transform=axs[0].get_yaxis_transform(),ha='right',fontweight='bold',fontsize=9)
axs[0].text(-.01,5.45,'B  Matched mechanisms',transform=axs[0].get_yaxis_transform(),ha='right',fontweight='bold',fontsize=9)
for ext in ['png','pdf','svg']:fig.savefig(OUT/f'Figure7_Paired_Differences_95CI.{ext}',dpi=600,facecolor='white')
plt.close(fig)
for p,h in sources.items():assert sha(Path(p))==h
for p,h in original_code.items():assert sha(Path(p))==h
(OUT/'revision7_paired_analysis.py').write_bytes(Path(__file__).read_bytes())
print(points.to_string());print(paired[paired.metric.eq('AP')].to_string(index=False));print('Saved to',OUT)
