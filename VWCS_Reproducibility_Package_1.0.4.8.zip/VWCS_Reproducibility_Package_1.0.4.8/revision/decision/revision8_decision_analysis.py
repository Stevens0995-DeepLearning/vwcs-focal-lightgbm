"""Frozen-prediction threshold/budget/cost evaluation. No model/data mutation."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(r'C:/ASQ备考/博士论文/西藏项目/Main coding')
OUT=ROOT/'logs/Revision8_Decision_Analysis_20261113';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((ROOT/'logs/Revision7_Paired_Analysis_20261113/Analysis_Protocol.json').read_text(encoding='utf8'))
for group in ['sources','original_code_sha256']:
    for p,h in old[group].items():assert sha(p)==h,p
models={};ids=None;y=None
keys=['VWCS','LGBM','SVM','CAT','XGB','SMOTE','EE','RF','LR']
for key,path in zip(keys,list(old['sources'])[:9]):
    d=pd.read_csv(path,float_precision='round_trip').set_index('sample_id')
    if ids is None:ids=d.index.to_numpy();y=d.y_true.to_numpy(dtype=int)
    assert d.index.is_unique and set(ids)==set(d.index)
    d=d.loc[ids];assert np.array_equal(y,d.y_true)
    models[key]=d.y_prob_calibrated.to_numpy()
z=pd.read_csv(ROOT/'logs/Revision4_Mechanisms/predictions.csv',float_precision='round_trip').set_index('Unnamed: 0').loc[ids]
assert np.array_equal(y,z.y_true)
high=z.high_V.to_numpy(dtype=bool);assert (y*high).sum()==38
for k in range(6):models[f'M{k}']=z[f'M{k}_q'].to_numpy()
N=len(y);P=int(y.sum());H=int((y*high).sum());assert (N,P)==(1470,73)
for q in models.values():assert np.isfinite(q).all() and ((q>=0)&(q<=1)).all()

def counts(y,p,h):
    tp=int(np.sum(p*y));fp=int(np.sum(p*(1-y)));fn=int(y.sum()-tp);tn=len(y)-tp-fp-fn
    ht=int(np.sum(p*y*h));hp=int(np.sum(y*h));k=tp+fp
    return dict(TP=tp,FN=fn,FP=fp,TN=tn,K=k,workload=k/len(y),Recall=tp/y.sum(),Precision=tp/k if k else np.nan,FPR=fp/(len(y)-y.sum()),F2=5*tp/(4*y.sum()+k),high_TP=ht,high_FN=hp-ht,high_recall=ht/hp if hp else np.nan)

def top(q,ident,k):
    o=np.lexsort((ident,-q));p=np.zeros(len(q),bool);p[o[:k]]=True;return p

thresholds=[];budget=[];costs=[]
for key,q in models.items():
    for t in np.round(np.arange(.01,1,.01),2):thresholds.append(dict(model=key,threshold=t,**counts(y,q>=t,high)))
    for k in sorted(set([67]+[int(np.floor(N*b/100)) for b in range(1,21)])):
        budget.append(dict(model=key,**counts(y,top(q,ids,k),high)))
    for r in [1,2,4,8,16,32]:
        for rule,p,t in [('t020',q>=.2,.2),('cost_threshold',q>=1/(1+r),1/(1+r)),('top67',top(q,ids,67),np.nan),('top5pct',top(q,ids,73),np.nan),('all',np.ones(N,bool),np.nan),('none',np.zeros(N,bool),np.nan)]:
            c=counts(y,p,high);costs.append(dict(model=key,r=r,rule=rule,threshold=t,cost_per_1000=1000*(c['FP']+r*c['FN'])/N,**c))
thresholds=pd.DataFrame(thresholds);budget=pd.DataFrame(budget);costs=pd.DataFrame(costs)
thresholds.to_csv(OUT/'Threshold_Scan_All_Models.csv',index=False)
budget.to_csv(OUT/'Budget_Scan_All_Models.csv',index=False)
costs.to_csv(OUT/'Cost_Scenarios_All_Models.csv',index=False)
arch=pd.read_csv(ROOT/'logs/sci_model_outputs/focal_lgbm/20260802_194022/threshold_metrics_test.csv')
t=thresholds.query('model=="VWCS"').reset_index(drop=True)
for a,b in [('recall','Recall'),('precision','Precision'),('f2','F2'),('tp','TP'),('fp','FP'),('fn','FN')]:assert np.allclose(arch[a],t[b],equal_nan=True)

# Focused paired comparisons. Each bootstrap rebuilds both top-K lists.
pairs=[('VWCS','LGBM'),('VWCS','SMOTE'),('M4','M3'),('M4','M5')]
spec=[]
for a,b in pairs:
    for k in [67,73]:
        for metric in ['TP','Recall','Precision','F2','high_TP','high_recall']:
            spec.append((a,b,'budget',k,metric))
    for r in [4,16]:
        for rule in ['t020','cost_threshold']:spec.append((a,b,rule,r,'cost_per_1000'))
def evaluate(sample):
    ys=y[sample];hs=high[sample];cache={}
    for a,b,rule,value,metric in spec:
        for key in [a,b]:
            tag=(key,rule,value)
            if tag in cache:continue
            qs=models[key][sample]
            p=top(qs,ids[sample],value) if rule=='budget' else qs >= (.2 if rule=='t020' else 1/(1+value))
            c=counts(ys,p,hs)
            if rule!='budget':c['cost_per_1000']=1000*(c['FP']+value*c['FN'])/len(ys)
            cache[tag]=c
    return np.array([cache[a,rule,value][metric]-cache[b,rule,value][metric] for a,b,rule,value,metric in spec])
point=evaluate(np.arange(N));draws=[];rng=np.random.default_rng(20261110)
pos=np.flatnonzero(y);neg=np.flatnonzero(1-y)
for i in range(2000):
    sample=np.r_[rng.choice(pos,len(pos)),rng.choice(neg,len(neg))]
    draws.append(evaluate(sample))
    if i%500==0:print('Paired decision bootstrap',i,flush=True)
lo,hi=np.quantile(draws,[.025,.975],axis=0)
ci=pd.DataFrame([dict(model=a,reference=b,rule=rule,value=v,metric=m,delta=point[j],lower=lo[j],upper=hi[j]) for j,(a,b,rule,v,m) in enumerate(spec)])
ci.to_csv(OUT/'Paired_Decision_Differences_95CI.csv',index=False)
np.savez_compressed(OUT/'Decision_Bootstrap_Draws.npz',draws=np.array(draws))

plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
colors=['#0072B2','#D55E00','#009E73'];styles=['-','--',':'];markers=['o','s','^']
fig,axs=plt.subplots(2,2,figsize=(6.6,5.3));fig.subplots_adjust(left=.10,right=.98,top=.94,bottom=.10,hspace=.50,wspace=.35)
v=thresholds.query('model=="VWCS" and threshold>=.05 and threshold<=.50')
ax=axs[0,0]
for metric,c,ls,mk in zip(['Recall','Precision','F2'],colors,styles,markers):ax.plot(v.threshold,v[metric],c=c,ls=ls,marker=mk,markevery=10,ms=3,label=metric)
ax.set(ylabel='Metric value',ylim=(0,1.03),title='(a) Threshold-dependent performance');ax.legend(loc='lower right',frameon=False)
axs[0,1].step(v.threshold,100*v.workload,where='post',c=colors[0]);axs[0,1].set(ylabel='Review workload (%)',ylim=(0,7.5),title='(b) Review workload')
axs[0,1].plot(.2,100*67/N,'o',c=colors[1],ms=4);axs[0,1].annotate('67 reviews (4.56%)',(.2,100*67/N),xytext=(.23,6.4),arrowprops=dict(arrowstyle='-',color='#555555'),fontsize=9)
axs[1,0].step(v.threshold,v.FN,where='post',c=colors[0]);axs[1,0].set(ylabel='Missed positives (count)',ylim=(0,18),title='(c) Missed positive facilities')
for ax in [axs[0,0],axs[0,1],axs[1,0]]:ax.axvline(.2,c='#777777',ls='--',lw=.8);ax.set_xlabel('Probability threshold');ax.set_xlim(.05,.5);ax.grid(alpha=.2)
ax=axs[1,1]
for rule,label,c,ls,mk in zip(['t020','cost_threshold','top5pct'],['Fixed t = 0.20','Cost rule t = 1/(1+r)','Top 5%'],colors,styles,markers):
    b=costs.query('model=="VWCS" and rule==@rule');ax.plot(b.r,b.cost_per_1000,c=c,ls=ls,marker=mk,ms=3,label=label)
ax.set_xscale('log',base=2);ax.set_xticks([1,2,4,8,16,32],labels=['1','2','4','8','16','32']);ax.set(xlabel='Assumed FN:FP cost ratio (r)',ylabel='Cost units per 1,000 facilities',ylim=(0,None),title='(d) Decision-cost sensitivity');ax.legend(frameon=False,loc='upper left',fontsize=9);ax.grid(alpha=.2)
for ext in ['png','pdf','svg']:fig.savefig(OUT/f'Figure8_Threshold_Cost_Sensitivity.{ext}',dpi=600)
plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(6.6,3.5));fig.subplots_adjust(left=.10,right=.98,bottom=.18,top=.87,wspace=.30)
for ax,modelkeys,metric,title in [(axs[0],['VWCS','LGBM','SMOTE'],'Recall','(a) Historical configurations'),(axs[1],['M3','M4','M5'],'high_recall','(b) Matched mechanisms')]:
    for key,c,ls,mk in zip(modelkeys,colors,styles,markers):
        b=budget.query('model==@key');lab={'VWCS':'VWCS','LGBM':'LightGBM','SMOTE':'SMOTE-LightGBM','M3':'M3: no vulnerability','M4':'M4: vulnerability','M5':'M5: mass matched'}[key]
        ax.plot(100*b.workload,b[metric],c=c,ls=ls,marker=mk,markevery=3,ms=3,label=lab)
    ax.axvline(5,c='#777777',lw=.8,ls='--');ax.set(xlabel='Review budget (% of cohort)',ylabel='Overall recall' if metric=='Recall' else 'High-vulnerability recall',ylim=(0,1.03),xlim=(0,20),title=title);ax.legend(frameon=False,loc='lower right',fontsize=9);ax.grid(alpha=.2)
for ext in ['png','pdf','svg']:fig.savefig(OUT/f'Figure9_Capacity_Matched_Detection.{ext}',dpi=600)
plt.close(fig)
manifest=dict(n=N,positive=P,high_vulnerability_positive=H,thresholds='0.01:0.01:0.99',budget='floor(N*b); b=1%-20%, plus exact K=67',rank='descending final probability, then ascending numeric sample_id',cost_ratios=[1,2,4,8,16,32],seed=20261110,replicates=2000,bootstrap='class-stratified paired facility bootstrap; rebuild top-K lists per replicate',sources=old['sources'],original_code_sha256=old['original_code_sha256'])
for group in ['sources','original_code_sha256']:
    for p,h in old[group].items():assert sha(p)==h,p
(OUT/'Analysis_Protocol.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
print(budget.query('model in ["VWCS","LGBM","SMOTE","M3","M4","M5"] and K in [67,73]').to_string(index=False))
print(costs.query('model in ["VWCS","LGBM","SMOTE","M3","M4","M5"] and r in [4,16] and rule in ["t020","cost_threshold"]').to_string(index=False))
print(ci.query('metric in ["Recall","high_recall","cost_per_1000"]').to_string(index=False))
