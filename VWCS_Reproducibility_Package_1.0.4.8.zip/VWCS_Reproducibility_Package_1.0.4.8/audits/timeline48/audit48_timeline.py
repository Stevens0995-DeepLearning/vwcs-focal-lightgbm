"""Read-only provenance/configuration audit for manuscript revision 1.0.4.8.

No source data, manuscript, training code or model is changed or executed.
Outputs are limited to audit48_* artifacts beside this script.
"""
from pathlib import Path
from collections import Counter
from decimal import Decimal
import hashlib
import json
import pandas as pd

HERE = Path(__file__).resolve().parent
PROJECT = Path(r'C:\ASQ备考\博士论文\西藏项目')
CODE = PROJECT / 'Main coding'
LOG = CODE / 'logs'
DATA = PROJECT / '资料准备/数据/实验数据'
RAW2 = PROJECT.parent / '西藏项目2/数据集/原始数据'
CC = 'CMS Certification Number (CCN)'
SOURCES = {}

def read_csv(p, **kwargs):
    p = Path(p)
    SOURCES[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    return pd.read_csv(p, low_memory=False, **kwargs)

def read_json(p):
    p = Path(p)
    SOURCES[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text(encoding='utf-8-sig'))

def keyframe(d):
    """No event ID exists: retain multiplicity in CCN/date/amount/type keys."""
    return list(zip(d[CC], pd.to_datetime(d['Penalty Date']).dt.strftime('%Y-%m-%d'),
                    d['Fine Amount'].map(lambda x: str(Decimal(str(x)).quantize(Decimal('.01')))),
                    d['Penalty Type']))

def subset_info(d, ids):
    z = d[d[CC].isin(ids)]
    return {'event_rows': len(z), 'unique_event_keys': len(set(keyframe(z))),
            'institutions': int(z[CC].nunique()), 'total_fines_usd': float(z['Fine Amount'].sum())}

meta = read_json(LOG / 'sci_model_outputs/focal_lgbm/20260802_194022/experiment_metadata.json')
rev = LOG / 'Revision2_Vi_20261110'
rp = read_json(rev / 'protocol.json')
aux = read_csv(rev / 'vulnerability_auxiliary.csv', dtype={'ccn': str})
wa = read_csv(rev / 'weight_audit.csv')
rm = read_csv(rev / 'test_metrics.csv')
sel = read_json(LOG / 'Revision2_Vi_dev_screen/selection.json')
cv = read_csv(LOG / 'Revision2_Vi_dev_screen/cv.csv')
details = read_csv(LOG / 'Revision2_Vi_dev_screen/details.csv')
td = LOG / 'Revision2_Vi_CMS_time_20261110'
tp = read_json(td / 'protocol.json')
tr = read_csv(td / 'train.csv', dtype={CC: str})
te = read_csv(td / 'validation.csv', dtype={CC: str})
tm = read_csv(td / 'metrics.csv')
tboot = read_json(td / 'paired_bootstrap.json')
em = read_csv(LOG / 'Revision2_Vi_temporal_extension/metrics.csv')
eci = read_csv(LOG / 'Revision2_Vi_temporal_extension/paired_differences.csv')

p26 = DATA / 'others/NH_Penalties_May2026.csv'
p25 = RAW2 / 'nursing-homes_annual_2025/NH_Penalties_May2025.csv'
f26 = read_csv(p26, dtype={CC: str})
f25 = read_csv(p25, dtype={CC: str})
for d in (f26, f25):
    d['Fine Amount'] = pd.to_numeric(d['Fine Amount'], errors='coerce')
assert aux['ccn'].is_unique and tr[CC].is_unique and te[CC].is_unique
bench = set(aux.ccn)
dev = set(aux.loc[aux.split.isin(['train', 'tune']), 'ccn'])
train_only = set(aux.loc[aux.split.eq('train'), 'ccn'])
tune_only = set(aux.loc[aux.split.eq('tune'), 'ccn'])
fine26 = f26[f26['Penalty Type'].eq('Fine') & f26['Fine Amount'].notna()].copy()
fine25 = f25[f25['Penalty Type'].eq('Fine') & f25['Fine Amount'].notna()].copy()
all_cumulative = f26.groupby(CC)['Fine Amount'].sum().reindex(aux.ccn).fillna(0)
assert (all_cumulative.gt(170734.8).to_numpy() == aux.y_true.to_numpy()).all()
assert abs(all_cumulative.quantile(.95) - 170734.8) < .000001

def window(d, origin, end):
    dates = pd.to_datetime(d['Penalty Date'])
    return d[(dates > pd.Timestamp(origin)) & (dates <= pd.Timestamp(end))].copy()

windows = []
counter26 = Counter(keyframe(fine26))
for name, source, cohort, origin, end in [
    ('temporal_training', fine25, tr, '2024-05-29', '2025-02-23'),
    ('temporal_validation', fine26, te, '2025-05-28', '2026-02-22')]:
    events_all = window(source, origin, end)
    events = events_all[events_all[CC].isin(cohort[CC])].copy()
    tally = events.groupby(CC)['Fine Amount'].sum().reindex(cohort[CC]).fillna(0)
    assert (tally.gt(170734.8).to_numpy() == cohort.y.to_numpy()).all()
    counter = Counter(keyframe(events))
    matched = counter & counter26
    matched_roster_events = sum(n for key, n in matched.items() if key[0] in bench)
    matched_dev_events = sum(n for key, n in matched.items() if key[0] in dev)
    joined = cohort[[CC, 'y']].merge(aux[['ccn', 'y_true', 'split']], left_on=CC, right_on='ccn', how='inner')
    tab = pd.crosstab(joined.y, joined.y_true).reindex(index=[0,1], columns=[0,1], fill_value=0)
    windows.append({
        'analysis': name, 'origin': origin, 'outcome_end_inclusive': end,
        'window_days': (pd.Timestamp(end)-pd.Timestamp(origin)).days,
        'cohort_size': len(cohort), 'outcome_positive': int(cohort.y.sum()),
        'fine_rows_in_window_before_roster_restriction': len(events_all),
        'fine_events_in_cohort': subset_info(events, set(cohort[CC])),
        'matched_event_rows_in_May2026_penalty_file': sum(matched.values()),
        'matched_unique_event_keys_in_May2026_penalty_file': len(matched),
        'matched_event_rows_contributing_to_benchmark_roster_cumulative_labels': matched_roster_events,
        'matched_event_rows_contributing_to_benchmark_development_labels': matched_dev_events,
        'fine_events_at_benchmark_roster_institutions': subset_info(events, bench),
        'fine_events_at_benchmark_development_institutions': subset_info(events, dev),
        'fine_events_at_benchmark_CV_training_institutions': subset_info(events, train_only),
        'fine_events_at_benchmark_secondary_tune_institutions': subset_info(events, tune_only),
        'cohort_overlap_with_benchmark': len(set(cohort[CC]) & bench),
        'cohort_overlap_with_benchmark_development': len(set(cohort[CC]) & dev),
        'cohort_overlap_with_benchmark_CV_training': len(set(cohort[CC]) & train_only),
        'cohort_overlap_with_benchmark_secondary_tune': len(set(cohort[CC]) & tune_only),
        'temporal_positive_with_benchmark_positive': int(tab.loc[1,1]),
        'temporal_positive_with_benchmark_negative': int(tab.loc[1,0]),
        'temporal_positive_without_benchmark_record': int(cohort.y.sum()-tab.loc[1].sum()),
        'label_cross_tab_rows_temporal_0_1_columns_benchmark_0_1': tab.values.tolist(),
    })

obs_sources=[]
for yr in [2024, 2025, 2026]:
    base = DATA/'others' if yr == 2026 else RAW2/f'nursing-homes_annual_{yr}'
    for stem in ['NH_ProviderInfo', 'NH_QualityMsr_MDS']:
        file=base/f'{stem}_May{yr}.csv'
        d=read_csv(file, dtype={CC: str})
        periods = sorted(d['Measure Period'].dropna().astype(str).unique()) if 'Measure Period' in d else []
        proc = sorted(d['Processing Date'].dropna().astype(str).unique()) if 'Processing Date' in d else []
        obs_sources.append({'filename':file.name,'path':str(file),'rows':len(d),
                            'processing_dates':proc,'measure_periods':periods,
                            'download_date':'Not established by CSV processing date or file name'})

parameter_rows = [
    {'analysis':'Archived headline Focal run (20260802_194022)', 'alpha':'0.90', 'gamma':'0.25',
     'vulnerability_definition':'Not recorded in run metadata', 'beta':'Not recorded',
     'cost_multipliers':'C_FN and C_FP not recorded', 'positive_weights':'Per-institution vector not archived in inspected metadata',
     'curvature':'Metadata: bce_proxy; current local objective: max[p(1-p), 1e-5]',
     'rounds':'931 selected; train+tune refit', 'evaluation':'Calibration-only Platt; t=0.20',
     'evidence_status':'Historical metadata documents alpha/gamma/iterations; current local source is not proof of the unavailable historical server implementation.'},
    {'analysis':'Revision A: cost-sensitive Focal without V', 'alpha':'0.90','gamma':'0.25',
     'vulnerability_definition':'Equal-weight training empirical ranks; lower staffing, higher ADL decline and more cycle-1 deficiencies',
     'beta':'0','cost_multipliers':'C_FN=C_FP=1; class ratio 9:1 is supplied by alpha',
     'positive_weights':'0.9; negative weight 0.1','curvature':'max[w_i p_i(1-p_i),1e-5]',
     'rounds':'277; train+tune refit','evaluation':'Calibration-only Platt; t=0.20','evidence_status':'Executable code and per-institution weights saved'},
    {'analysis':'Revision B: linear instance weighting', 'alpha':'0.90','gamma':'0.25',
     'vulnerability_definition':'Same fixed three-component index as A/C; omega=(1/3,1/3,1/3)',
     'beta':'1','cost_multipliers':'C_FN=C_FP=1','positive_weights':'0.9(1+V_i); negative weight 0.1',
     'curvature':'max[w_i p_i(1-p_i),1e-5]','rounds':'250; train+tune refit',
     'evaluation':'Calibration-only Platt; t=0.20','evidence_status':'Weights and outcomes verified from revision artifacts'},
    {'analysis':'Revision C: positive-mass-matched uniform weighting', 'alpha':'0.90','gamma':'0.25',
     'vulnerability_definition':'Same index used only to define mean positive multiplier',
     'beta':'No instance variation','cost_multipliers':'C_FN=C_FP=1',
     'positive_weights':'0.9(1+mean(V_positive)); separately matched within selection/refit',
     'curvature':'max[w_i p_i(1-p_i),1e-5]','rounds':'291; train+tune refit',
     'evaluation':'Calibration-only Platt; t=0.20','evidence_status':'Total positive weight equals B, not A'},
    {'analysis':'Temporal uniform / upper100', 'alpha':'0.90','gamma':'0.25',
     'vulnerability_definition':'Three ranks fitted on 2024 cohort; q75=0.6325546558; omega=(1/3,1/3,1/3)',
     'beta':'0 / 1','cost_multipliers':'No extra cost multiplier',
     'positive_weights':'0.9 m_i/mean(m_positive), m_i=1+beta max(V_i-q75,0)/(1-q75); negative=0.1',
     'curvature':'max[w_i p_i(1-p_i),1e-5]','rounds':'300 fixed; no early stopping/refit search',
     'evaluation':'Raw-margin top 5% ranking; K=738; no probability calibration used for this budget analysis',
     'evidence_status':'The localized weighting rule is transported; the original 16-predictor benchmark model is not transported'},
]

timeline_rows=[
    {'stage':'Benchmark construction and A/B/C development',
     'predictor_snapshot':'May 2026 provider snapshot; ADL measure 2025Q1-2025Q4',
     'outcome_window':'All available fines in NH_Penalties_May2026.csv, aggregated per facility',
     'sample':'14,700 facilities; 735 benchmark positives',
     'role':'Benchmark fitting, index construction and mechanism comparison'},
    {'stage':'Localized-rule development screen',
     'predictor_snapshot':'Same May 2026 benchmark development records',
     'outcome_window':'Same cumulative benchmark label',
     'sample':'10,290 train; 1,470 tune; test/calibration excluded by selection script',
     'role':'Three-fold train CV selects upper100 for high-V detections at 5% budget subject to AP loss <=0.002; tune is a secondary check'},
    {'stage':'Temporal model fitting', 'predictor_snapshot':'2024-05-29 origin; ADL 2022Q4-2023Q3',
     'outcome_window':'(2024-05-29, 2025-02-23], 270 days; May2025 penalties source',
     'sample':'14,858 facilities; 180 positives','role':'Fit the five-observed-predictor models and rank-based index; 300 fixed rounds'},
    {'stage':'Temporal transport evaluation', 'predictor_snapshot':'2025-05-28 origin; ADL 2024Q1-2024Q4',
     'outcome_window':'(2025-05-28, 2026-02-22], 270 days; May2026 penalties source',
     'sample':'14,759 facilities; 89 positives; 738 review slots',
     'role':'Evaluate the previously selected localized weighting rule; source/outcome independence must be qualified by the event audit'},
    {'stage':'Temporal feature extension', 'predictor_snapshot':'Same 2024/2025 cohorts; add V_i and/or pre-origin log(1+prior fines)',
     'outcome_window':'Same 270-day training/evaluation windows',
     'sample':'Same 14,858/14,759 facilities','role':'Exploratory eight-cell feature/weight comparison on the already used evaluation cohort; not a further independent cohort'},
]

for name in ['screen_vi_weights_dev.py','run_revision2_vulnerability.py','validate_vi_cms_time.py',
             'audit_vi_temporal_budget.py','extend_vi_temporal.py','LightGBM + Focal Loss Final.py',
             'ablation_models.py','ablation_data.py','run_ablation.py']:
    p=CODE/name; SOURCES[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()

v=windows[1]
manuscript_paragraph=(
    'The upper100 rule was selected by three-fold cross-validation in the benchmark training partition, '
    'using high-vulnerability detections at a 5% review budget as the primary criterion and allowing at '
    'most a 0.002 decrease in mean AP; the tuning partition provided a secondary check. The temporal '
    'script then fixed this rule and 300 boosting rounds before evaluating the 2025 cohort. This is a '
    'retrospective temporal transport assessment of the weighting rule. '
    f'Of {v["cohort_size"]:,} evaluation facilities, {v["cohort_overlap_with_benchmark"]:,} also occurred in '
    f'the benchmark and {v["cohort_overlap_with_benchmark_development"]:,} in its development partitions. '
    f'The evaluation included {v["fine_events_in_cohort"]["event_rows"]:,} fine records in the 270-day '
    f'outcome window; {v["matched_event_rows_contributing_to_benchmark_roster_cumulative_labels"]:,} '
    'also contributed to the benchmark cumulative-penalty labels. Consequently, this analysis demonstrates '
    'transport across predictor snapshots and outcome windows, rather than evaluation on outcome records '
    'entirely untouched during earlier benchmark development.'
)

result={'audit_scope':'Read-only; deterministic record linkage/configuration inspection; no models trained',
        'historical_run_metadata':meta, 'historical_missing_fields':['omega','beta','C_FN','C_FP','per-institution V_i and weights'],
        'current_local_original_objective':'Gradient depends on alpha/gamma; bce_proxy returns max[p(1-p),1e-5] without instance weight. This is evidence about current local code only.',
        'revision_protocol':rp,'revision_weight_audit':wa.to_dict('records'),'revision_metrics':rm.to_dict('records'),
        'development_rule_selection':sel,'development_cv':cv.to_dict('records'),'development_details':details.to_dict('records'),
        'temporal_protocol':tp,'temporal_metrics':tm.to_dict('records'),'temporal_paired_bootstrap':tboot,
        'temporal_extension_metrics':em.to_dict('records'),'temporal_extension_ci':eci.to_dict('records'),
        'penalty_source':{'columns':list(f26.columns),'event_id_available':False,'May2026_all_rows':len(f26),
                          'May2026_Fine_rows':len(fine26),'May2026_duplicate_event_keys':len(fine26)-len(set(keyframe(fine26))),
                          'processing_dates':sorted(f26['Processing Date'].astype(str).unique()),
                          'penalty_date_min':str(pd.to_datetime(f26['Penalty Date']).min().date()),
                          'penalty_date_max':str(pd.to_datetime(f26['Penalty Date']).max().date()),
                          'benchmark_quantile95':float(all_cumulative.quantile(.95)),
                          'benchmark_labels_reconstructed_exactly':True},
        'event_linkage_method':'CCN as zero-preserving text + ISO Penalty Date + Fine Amount rounded to cents + Penalty Type; compare Counter intersections to preserve duplicate-row multiplicity; no event ID exists in source.',
        'windows':windows,'observed_source_metadata':obs_sources,'parameter_rows':parameter_rows,
        'timeline_rows':timeline_rows,'suggested_manuscript_paragraph':manuscript_paragraph,
        'freeze_interpretation':'Execution-level selection is demonstrable from selection.json and assert checks. Wall-clock/prospective preregistration is not established. The May2026 cumulative labels reuse later evaluation outcome records; the 2025 model itself is not fitted on its evaluation cohort.',
        'source_sha256':SOURCES}
(HERE/'audit48_timeline.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
pd.DataFrame(parameter_rows).to_csv(HERE/'audit48_parameters_S18.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(timeline_rows).to_csv(HERE/'audit48_timeline_S19.csv',index=False,encoding='utf-8-sig')
(HERE/'audit48_timeline_paragraph.txt').write_text(manuscript_paragraph,encoding='utf-8')
print(json.dumps({'windows':windows,'penalty_source':result['penalty_source'],'paragraph':manuscript_paragraph},ensure_ascii=False,indent=2))
