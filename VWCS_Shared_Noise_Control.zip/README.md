# VWCS shared-noise control: protocol, results and replay

This stand-alone supplement reports a three-model, shared-input measurement-error experiment conducted on 18 November 2026. It is not the historical nine-configuration comparison and is not the no-additional-perturbation sensitivity analysis in Supplementary Table S17. S17 compares standard LightGBM, SMOTE-LightGBM and linear VWCS; the three arms **here** are standard LightGBM, cost-sensitive Focal-LightGBM without facility-specific weighting, and VWCS-Focal-LightGBM with linear facility-specific weighting. The outcomes are benchmark penalty labels, not emergency events. No new model training is needed to check the reported results.

## Design

- One fixed four-way split of the same 14,700-facility benchmark: 10,290 training, 1,470 tuning, 1,470 calibration, 1,470 locked test. There were 73 positives and 1,397 negatives on the test set, including 38 high-vulnerability positives. The vulnerability register and its training-derived high-vulnerability cutoff were frozen. Vulnerability was used in the VWCS loss and for subgroup evaluation, not as a predictor.
- The control used one no-added-noise reference (labelled seed 0) and three independent noise draws (42, 43, 44); tree seed 42 was fixed throughout. Two numeric fields were perturbed across all four splits: `Masked_Admin_Redundancy` and `Reported Total Nurse Staffing Hours per Resident per Day`. Each received independent zero-mean Gaussian error of SD 0.3 times its own original training SD (noise SDs 0.442179 and 0.271296, respectively). Missing values remained missing at this step. No extra coarsening or clipping was applied. Within each draw, all three arms used **the same row-by-column perturbations and model input matrix**.
- The models used the same 13 numeric and three nominal inputs. Medians, means/scales and one-hot categories were fitted on the training partition only. Each arm selected among (leaves, depth) = (7, 3), (15, 5), (31, 6) by tuning AP, allowing 1,000 rounds and 100 rounds of early-stopping patience. Trees were refitted on training plus tuning at the selected iteration count. Each fitted model received a separate Platt calibration using only the calibration partition.
- The two focal arms used alpha = 0.90, gamma = 0.25 and unit explicit error-cost constants. The positive weight was 0.90 in the no-vulnerability focal arm and 0.90 × (1 + V_i) in linear VWCS; both used negative weight 0.10 and the weighted BCE curvature surrogate. The change therefore need not preserve total positive weight; this is not the weight-matched ablation. Measured predictors were perturbed, but the vulnerability register was not recomputed after perturbation.
- AP and ROC-AUC used raw margins. Brier scores used final probabilities; threshold metrics used the locked cutoff t = 0.20. For the nominal 5% review budget, K = floor(0.05 × 1,470) = 73. Facilities were sorted by descending calibrated probability, with ties broken by ascending numeric sample ID.

## Results

Means across noise seeds 42, 43 and 44 (sample SD in parentheses in the AP column). These are not sampling confidence intervals. High-V TP is the count of high-vulnerability positives found in the 73-slot review list in **each** noise realization.

| Arm | AP (SD) | ROC-AUC | Brier | Recall | Precision | FPR | F2 | High-V TP |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| LightGBM | 0.895092 (0.000398) | 0.976613 | 0.010413 | 0.831050 | 0.867001 | 0.006681 | 0.837929 | 30/38 |
| Cost-sensitive focal, no V_i | 0.886727 (0.004261) | 0.974126 | 0.010687 | 0.821918 | 0.870663 | 0.006442 | 0.831063 | 30/38 |
| Linear VWCS | 0.886850 (0.003228) | 0.974508 | 0.010808 | 0.821918 | 0.870435 | 0.006442 | 0.831055 | 30/38 |

Without added noise, AP was 0.898500, 0.885346 and 0.887309, respectively. In the three noisy runs, linear VWCS minus no-V_i focal AP was +0.002119, −0.005194 and +0.003443 (mean +0.000122 using unrounded values). Linear weighting did not yield a consistent AP gain or increase high-vulnerability detections at this budget. This experiment addresses one measurement-error magnitude on a fixed test cohort; it does not test the localized upper-tail rule used in the temporal CMS evaluation.

## How to check the files

From the extracted archive directory, run `python verify_results.py` (Python 3.9+; standard library only). The check validates the SHA-256 manifest; aligns sample IDs, outcomes and vulnerability labels; checks common input fingerprints and noise-draw hashes; recomputes AP, ROC-AUC, Brier, threshold confusion counts and derived scores, and reconstructs the 73-slot review lists from archived probabilities in all 12 fits. It does not refit any model or change any input.

| File or group | What it contains |
|---|---|
| `original/run_shared_noise_review48.py` | Byte-for-byte snapshot of the training and evaluation driver. |
| `results/protocol.json` | Preset split, predictor list, preprocessing, noise scales, curvature and hyperparameters, software versions, completed-run markers, source and input hashes. The purpose field records the experiment's status on the run date. |
| `results/shared_noise_mean_sd.csv`, `test_metrics.csv`, `paired_seed_differences.csv` | Noisy-seed summaries; per-fit metrics, calibration and selected parameters; within-seed differences (not paired bootstrap intervals). |
| `results/test_predictions_long.csv` | 17,640 records = 4 input matrices × 3 model arms × 1,470 test facilities. Includes facility/sample ID, outcome, vulnerability, raw margin/probability, calibrated probability, cutoff decision and budget inclusion indicator. |
| `results/split_manifest.csv`, `noise_draws_*.csv`, `weight_audit.csv`, `tuning_candidates.csv` | Cohort partitions, actual generated perturbations, weight totals, and all tuning candidates. Noise-draw files store all draws, including those for rows where the corresponding observed input is missing. |
| `results/model_*.txt` (12), `execution_log.txt` | All fitted LightGBM tree ensembles and console log; fitted Platt slopes/intercepts are in `test_metrics.csv`. |
| `results/run_notes_zh.txt` | Original Chinese run notes; file contents retained verbatim under an English filename. |
| `SHA256SUMS.txt` | SHA-256 fingerprints of every other archive member, including this README and the replay checker. |

### Optional model retraining

The archive is self-contained for **prediction-level verification**, not for retraining. The original driver imports project modules and loads the CMS-derived input matrix and vulnerability-audit files. Use the companion main reproducibility materials for these inputs and code; check the exact file fingerprints listed under `source_hashes` in the archived protocol. A missing file or mismatched fingerprint must not be silently substituted.

The driver resolves the original code root as two parent directories above its script folder. Recreate its historical placement **under the code root** as `logs/Revision48_SharedNoise_20261118/run_shared_noise_review48.py`; place `protocol.json` and `vulnerability_auxiliary.csv` from the earlier index audit in `logs/Revision2_Vi_20261110/`. The code root must also contain the imported source modules and files recorded in `source_hashes`. Original Windows paths in the protocol, defaults, and upstream provenance dictionaries are retained as run records, not working paths on other machines. Outside the original directory layout, use a separate working copy, update the dataset path resolver and map the original provenance dictionary's dataset key to the relocated file **while preserving the original byte-hash check**. Do not edit this archive's protocol or overwrite archived results.

From that reconstituted code root, using the versions recorded in `results/protocol.json`, run:

```text
python logs/Revision48_SharedNoise_20261118/run_shared_noise_review48.py --out new_shared_noise_results --noise-seeds 42 43 44 --max-rounds 1000 --patience 100 --threads 2
```

Choose a new output directory that does not yet exist. Original paths in the preserved output and log are for provenance only.
