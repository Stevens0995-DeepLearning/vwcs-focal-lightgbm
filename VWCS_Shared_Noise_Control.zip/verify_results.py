"""Read-only replay of shared-noise predictions; no third-party dependencies."""
import csv
import hashlib
import io
import itertools
import json
import math
import sys
from collections import defaultdict
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


def verify(read, members):
    manifest = {}
    for line in read("SHA256SUMS.txt").decode("ascii").splitlines():
        sha, filename = line.split("  ", 1)
        require(filename not in manifest, "Duplicate manifest entry: " + filename)
        manifest[filename] = sha
    require(set(members) == set(manifest) | {"SHA256SUMS.txt"}, "Manifest inventory mismatch")
    for name, sha in manifest.items():
        require(hashlib.sha256(read(name)).hexdigest() == sha, "SHA-256 mismatch: " + name)
    def rows(name):
        return list(csv.DictReader(io.StringIO(read("results/" + name).decode("utf-8-sig"))))
    protocol = json.loads(read("results/protocol.json"))
    require(protocol["completed"] and protocol["original_sources_unchanged"], "Incomplete original run")
    test = {int(r["sample_id"]): int(r["y_true"]) for r in rows("split_manifest.csv") if r["split"] == "test"}
    require(len(test) == 1470 and sum(test.values()) == 73, "Unexpected test cohort")
    matrices = {}
    for scenario in protocol["scenario_runs"]:
        sc, seed = scenario["scenario"], int(scenario["noise_seed"])
        matrices[sc, seed] = scenario["input_sha256"]
        nd = read(f"results/noise_draws_{sc}_{seed}.csv")
        require(hashlib.sha256(nd).hexdigest() == scenario["noise_draws_sha256"], "Noise-draw hash mismatch")
    expect = {("no_added_noise", 0)} | {("shared_noise_0.3sd", s) for s in [42, 43, 44]}
    require(set(matrices) == expect, "Unexpected scenarios")
    def key(r):
        return r["scenario"], int(r["noise_seed"]), r["arm"]
    metrics = {key(r): r for r in rows("test_metrics.csv")}
    obs = defaultdict(list)
    for r in rows("test_predictions_long.csv"):
        obs[key(r)].append(r)
    require(set(obs) == set(metrics) == {(s, n, a) for s, n in expect for a in ("baseline", "cost_focal", "vwcs")}, "Missing or extra arms")
    reference_v = None
    for (sc, seed, arm), records in obs.items():
        m = metrics[sc, seed, arm]
        require(m["input_sha256"] == matrices[sc, seed], f"Input mismatch: {sc}/{seed}/{arm}")
        labels = {int(r["sample_id"]): int(r["y_true"]) for r in records}
        require(len(records) == len(test) and labels == test, "Test IDs or labels do not match")
        reg = {int(r["sample_id"]): (r["ccn"], r["V_i"], int(r["high_V"])) for r in records}
        if reference_v is None:
            reference_v = reg
        require(reference_v == reg, "Facility or vulnerability register changed")
        score = lambda r: float(r["raw_margin"])
        prob = lambda r: float(r["calibrated_probability"])
        ranked = sorted(records, key=score, reverse=True)
        k = 73
        selected = {int(r["sample_id"]) for r in sorted(records, key=lambda r: (-prob(r), int(r["sample_id"])))[:k]}
        tp = fp = positives_seen = items_seen = budget_tp = high_n = high_budget_tp = high_t_tp = 0
        ap = neg_seen = auc_losses = sq = 0.
        pos = sum(test.values())
        neg = len(test) - pos
        for _, group in itertools.groupby(ranked, key=score):
            block = list(group)
            bp = sum(int(r["y_true"]) for r in block)
            bn = len(block) - bp
            items_seen += len(block)
            positives_seen += bp
            ap += (bp / pos) * (positives_seen / items_seen)
            auc_losses += bp * (neg_seen + 0.5 * bn)
            neg_seen += bn
        for r in records:
            p, y, h = prob(r), int(r["y_true"]), int(r["high_V"])
            d = int(p >= .2)
            b = int(int(r["sample_id"]) in selected)
            require(0 <= p <= 1 and d == int(r["decision_t020"]) and b == int(r["selected_budget5"]), "Invalid decisions")
            tp += d * y
            fp += d * (1-y)
            budget_tp += b * y
            high_n += h * y
            high_budget_tp += b * h * y
            high_t_tp += d * h * y
            sq += (p-y)**2
        fn = pos-tp
        require(high_n == 38, "Unexpected subgroup")
        vals = dict(pr_auc=ap, roc_auc=1-auc_losses/(pos*neg), brier=sq/len(test),
                    recall=tp/pos, precision=tp/(tp+fp), fpr=fp/neg, f2=5*tp/(5*tp+4*fn+fp),
                    tp=tp, fn=fn, fp=fp, tn=neg-fp, alerts_t020=tp+fp, high_V_positive=high_n,
                    high_V_tp_t020=high_t_tp, budget_K=k, budget_tp=budget_tp, budget_fp=k-budget_tp,
                    budget_precision=budget_tp/k, budget_recall=budget_tp/pos,
                    budget_high_V_tp=high_budget_tp, budget_high_V_fn=high_n-high_budget_tp,
                    budget_high_V_recall=high_budget_tp/high_n)
        for name, val in vals.items():
            require(math.isclose(val, float(m[name]), rel_tol=1e-11, abs_tol=1e-12), f"{sc}/{seed}/{arm}/{name} mismatch")
    return f"PASS: {len(manifest)} SHA-256 entries; 12 fits; 17,640 row-level predictions; threshold and budget results reproduced."


if __name__ == "__main__":
    import zipfile
    if len(sys.argv) == 2:
        with zipfile.ZipFile(sys.argv[1]) as archive:
            require(archive.testzip() is None, "ZIP CRC mismatch")
            require(len(archive.namelist()) == len(set(archive.namelist())), "Duplicate ZIP member")
            print(verify(archive.read, archive.namelist()))
    elif len(sys.argv) == 1:
        root = Path(__file__).resolve().parent
        expected_names = [line.split("  ",1)[1] for line in (root / "SHA256SUMS.txt").read_text("ascii").splitlines()] + ["SHA256SUMS.txt"]
        print(verify(lambda name: (root/name).read_bytes(), expected_names))
    else:
        raise SystemExit("Usage: python verify_results.py [archive.zip]")
