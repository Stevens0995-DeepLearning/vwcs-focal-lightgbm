"""Shared-noise review experiment; never writes original code, data, or manuscript.

Run with the existing LHLenv Python. Each model receives the same noisy matrix
within a seed. This is a new matched-protocol sensitivity experiment, not a
reconstruction of the historical model-specific friction pipelines.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import json
import platform
import sys
import time
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler

CODE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(CODE))
from ablation_data import DEFAULT_DATA, load_data_and_splits, split_manifest
from ablation_models import FOCAL, FOCAL_BASE_KWARGS
from run_ablation import score_predictions

NOISE_COLUMNS = [
    'Masked_Admin_Redundancy',
    'Reported Total Nurse Staffing Hours per Resident per Day',
]
MODEL_NAMES = {
    'baseline': 'LightGBM',
    'cost_focal': 'Cost-sensitive Focal-LightGBM (no Vi)',
    'vwcs': 'VWCS-Focal-LightGBM (linear Vi)',
}
METRICS = ['pr_auc', 'roc_auc', 'brier', 'recall', 'precision', 'fpr', 'f2']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def frame_sha(frame):
    return hashlib.sha256(pd.util.hash_pandas_object(frame, index=True).values.tobytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=Path(__file__).parent / 'results')
    parser.add_argument('--noise-seeds', type=int, nargs='+', default=[42, 43, 44])
    parser.add_argument('--max-rounds', type=int, default=1000)
    parser.add_argument('--patience', type=int, default=100)
    parser.add_argument('--threads', type=int, default=2)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    logfile = (out / 'execution_log.txt').open('w', encoding='utf-8')

    def log(message):
        print(message, flush=True)
        logfile.write(str(message) + '\n')
        logfile.flush()

    def csv(data, name):
        pd.DataFrame(data).to_csv(out / name, index=False, encoding='utf-8-sig')

    revision2 = CODE / 'logs/Revision2_Vi_20261110'
    prior = json.loads((revision2 / 'protocol.json').read_text('utf-8'))
    assert sha(DEFAULT_DATA) == prior['dataset_sha256'][str(DEFAULT_DATA)]
    X, y, splits = load_data_and_splits()
    assert split_manifest(splits) == prior['splits']
    assert X.shape == (14700, 16) and y.sum() == 735
    tr, tu, ca, te = [splits[k][0].index for k in ('train', 'tune', 'calibration', 'test')]
    refit = np.r_[tr, tu]
    auxfile = revision2 / 'vulnerability_auxiliary.csv'
    v = pd.read_csv(auxfile, float_precision='round_trip').set_index('sample_id')
    assert v.index.equals(y.index) and np.array_equal(v.y_true, y)
    catcols = X.select_dtypes('category').columns.tolist()
    numcols = X.columns.difference(catcols, sort=False).tolist()
    assert len(catcols) == 3 and len(numcols) == 13
    assert set(NOISE_COLUMNS).issubset(numcols)
    source_files = [DEFAULT_DATA, auxfile, revision2 / 'protocol.json', Path(__file__)]
    source_files += [CODE / name for name in [
        'ablation_data.py', 'ablation_models.py', 'run_ablation.py',
        'LightGBM + Focal Loss Final.py', 'LightGBM baseline.py',
        'Logistic Regression (LR).py', 'revision6_matched.py',
    ]]
    source_hashes = {str(p): sha(p) for p in source_files}
    noise_sd = X.loc[tr, NOISE_COLUMNS].astype('float64').std(ddof=1) * .3
    protocol = {
        'purpose': 'Small matched shared-Gaussian-noise comparison; not inserted into manuscript',
        'source_hashes': source_hashes,
        'splits': split_manifest(splits),
        'input_features': list(X.columns), 'categorical_features': catcols,
        'noise_columns': NOISE_COLUMNS,
        'noise_sd': noise_sd.to_dict(), 'noise_seeds': args.noise_seeds,
        'noise_definition': 'Independent zero-mean Gaussian measurement error, SD=0.3 times ORIGINAL TRAINING SD, added to observed values of two historical noisy fields; identical row-column draws for all models. Missing values retained; no clipping or coarsening. Independent columns (not the historical reseeding of the same stream for each column).',
        'zero_noise_reference': 'One seed-independent run; tree seed fixed at 42 in every scenario',
        'vulnerability': 'Frozen equal-weight train-CDF index and training q75 high-V cutoff from Revision2 audit; not recomputed after predictor perturbation. It enters training instance weights only, never X. Thus this experiment perturbs predictor measurements conditional on a fixed vulnerability register, not the vulnerability register itself.',
        'vulnerability_source_protocol': prior,
        'preprocess': 'Training-only median imputation and StandardScaler for numeric values; training-only OneHotEncoder for three nominal fields (unknown ignored); frozen during final refit. Same transformed matrix object in every arm.',
        'tree_grid': [{'num_leaves': n, 'max_depth': d} for n, d in [(7, 3), (15, 5), (31, 6)]],
        'max_rounds': args.max_rounds, 'early_stopping_patience': args.patience,
        'selection': 'Highest tuning-set AP; deterministic first-grid tie break; never use test scores for selection',
        'refit': 'Train+tune at selected iteration count, no early stopping during refit',
        'calibration': 'All arms: Platt logistic regression (C=1e6) on independent calibration margins only',
        'alpha': .9, 'gamma': .25, 'beta': {'baseline': 0., 'cost_focal': 0., 'vwcs': 1.},
        'C_FN': 1., 'C_FP': 1.,
        'focal_curvature': 'Full instance-weighted BCE positive surrogate max(W*p*(1-p), 1e-5), consistent with Eq.9 revised implementation',
        'gradient': 'Unchanged original focal gradient via AST, multiplied by 1+V for positive samples only in VWCS',
        'threshold': .2, 'budget': 'K=floor(0.05*N_test)=73; sort calibrated probability descending, ties sample_id ascending',
        'ranking_scores': 'Raw margins (AP/ROC-AUC); calibrated probabilities (Brier, threshold, budget)',
        'summary': 'Mean and sample SD across three noise realizations; not a confidence interval',
        'python': sys.version, 'platform': platform.platform(), 'threads': args.threads,
        'versions': {x: metadata.version(x) for x in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'lightgbm', 'imbalanced-learn']},
        'scenario_runs': [],
    }
    manifest = pd.DataFrame({'sample_id': y.index, 'y_true': y})
    for name, (xx, _) in splits.items():
        manifest.loc[xx.index, 'split'] = name
    csv(manifest, 'split_manifest.csv')
    common = {**FOCAL_BASE_KWARGS, 'metric': 'None', 'n_jobs': args.threads,
              'verbosity': -1, 'random_state': 42, 'boost_from_average': False}
    common.pop('verbose', None)
    protocol['common_model_parameters'] = common
    (out / 'protocol.json').write_text(json.dumps(protocol, ensure_ascii=False, indent=2), 'utf-8')
    log('Protocol frozen before fitting: ' + str(out / 'protocol.json'))
    legacy = FOCAL['focal_loss_custom'](.9, .25, 'bce_proxy')
    results, candidates, prediction_frames, weight_rows = [], [], [], []
    scenarios = [('no_added_noise', 0)] + [('shared_noise_0.3sd', seed) for seed in args.noise_seeds]
    for scenario, seed in scenarios:
        noisy = X.copy()
        deltas = pd.DataFrame({'sample_id': X.index})
        rng = np.random.default_rng(seed)
        for col in NOISE_COLUMNS:
            eps = rng.normal(0., float(noise_sd[col]), len(X)) if seed else np.zeros(len(X))
            noisy[col] = noisy[col].astype('float64') + eps
            deltas[col] = eps
        csv(deltas, f'noise_draws_{scenario}_{seed}.csv')
        med = noisy.loc[tr, numcols].median()
        scaler = StandardScaler().fit(noisy.loc[tr, numcols].fillna(med))
        categorical = noisy[catcols].astype(object).fillna('__missing__')
        encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False).fit(categorical.loc[tr])
        Z = pd.DataFrame(np.column_stack([
            scaler.transform(noisy[numcols].fillna(med)),
            encoder.transform(categorical),
        ]).astype('float32'), index=y.index)
        input_hash = frame_sha(Z)
        prep = {'scenario': scenario, 'noise_seed': seed, 'input_sha256': input_hash,
                'noise_draws_sha256': sha(out / f'noise_draws_{scenario}_{seed}.csv'),
                'training_medians': med.to_dict(), 'scaler_mean': scaler.mean_.tolist(),
                'scaler_scale': scaler.scale_.tolist(),
                'onehot_categories': [z.tolist() for z in encoder.categories_]}
        protocol['scenario_runs'].append(prep)
        for arm, name in MODEL_NAMES.items():
            begin = time.perf_counter()
            def make_model(idx, leaves, depth, rounds):
                yy = y.loc[idx].to_numpy()
                if arm == 'baseline':
                    objective = 'binary'
                else:
                    mult = 1 + v.loc[idx, 'V_i'].to_numpy() if arm == 'vwcs' else np.ones(len(idx))
                    w = np.where(yy == 1, .9 * mult, .1)
                    def objective(labels, margin):
                        assert np.array_equal(labels, yy)
                        p = np.clip(expit(margin), 1e-6, 1 - 1e-6)
                        gradient = legacy(labels, margin)[0] * w / np.where(labels == 1, .9, .1)
                        return gradient, np.maximum(w * p * (1 - p), 1e-5)
                return lgb.LGBMClassifier(**{**common, 'objective': objective,
                    'num_leaves': leaves, 'max_depth': depth, 'n_estimators': int(rounds)})

            best = None
            for leaves, depth in [(7, 3), (15, 5), (31, 6)]:
                model = make_model(tr, leaves, depth, args.max_rounds)
                model.fit(Z.loc[tr], y.loc[tr], eval_set=[(Z.loc[tu], y.loc[tu])],
                    eval_metric=lambda lab, s: ('AP', average_precision_score(lab, s), True),
                    callbacks=[lgb.early_stopping(args.patience, first_metric_only=True, verbose=False)])
                iterations = int(model.best_iteration_ or args.max_rounds)
                margin = model.booster_.predict(Z.loc[tu], raw_score=True, num_threads=args.threads)
                ap = float(average_precision_score(y.loc[tu], margin))
                row = dict(scenario=scenario, noise_seed=seed, arm=arm, num_leaves=leaves,
                           max_depth=depth, iterations=iterations, tune_ap=ap)
                candidates.append(row)
                if best is None or ap > best['tune_ap']:
                    best = row
            final = make_model(refit, best['num_leaves'], best['max_depth'], best['iterations'])
            final.fit(Z.loc[refit], y.loc[refit])
            cal_margin = final.booster_.predict(Z.loc[ca], raw_score=True, num_threads=args.threads)
            calibration = LogisticRegression(C=1e6, solver='lbfgs', max_iter=2000, random_state=42)
            calibration.fit(cal_margin[:, None], y.loc[ca])
            assert calibration.coef_[0, 0] > 0, 'Platt slope reversed ranking'
            margin = final.booster_.predict(Z.loc[te], raw_score=True, num_threads=args.threads)
            probability = calibration.predict_proba(margin[:, None])[:, 1]
            scores = score_predictions(y.loc[te], margin, probability, threshold=.2)
            pred = v.loc[te, ['ccn', 'y_true', 'V_i', 'high_V']].copy().rename_axis('sample_id').reset_index()
            pred['raw_margin'] = margin
            pred['raw_probability'] = expit(margin)
            pred['calibrated_probability'] = probability
            pred['decision_t020'] = (probability >= .2).astype(int)
            k = int(np.floor(.05 * len(te)))
            order = pred.sort_values(['calibrated_probability', 'sample_id'], ascending=[False, True]).index[:k]
            pred['selected_budget5'] = 0
            pred.loc[order, 'selected_budget5'] = 1
            high_positive = pred.high_V.eq(1) & pred.y_true.eq(1)
            high_n = int(high_positive.sum())
            htp = int(pred.loc[high_positive, 'selected_budget5'].sum())
            btp = int(pred.loc[order, 'y_true'].sum())
            pred.insert(0, 'scenario', scenario)
            pred.insert(1, 'noise_seed', seed)
            pred.insert(2, 'arm', arm)
            prediction_frames.append(pred)
            summary = {**best, 'model': name, 'input_sha256': input_hash, **scores,
                'alerts_t020': int((probability >= .2).sum()),
                'high_V_positive': high_n, 'high_V_tp_t020': int(pred.loc[high_positive, 'decision_t020'].sum()),
                'budget_K': k, 'budget_tp': btp, 'budget_fp': k - btp,
                'budget_recall': btp / int(y.loc[te].sum()), 'budget_precision': btp / k,
                'budget_high_V_tp': htp, 'budget_high_V_fn': high_n - htp,
                'budget_high_V_recall': htp / high_n,
                'platt_slope': float(calibration.coef_[0, 0]),
                'platt_intercept': float(calibration.intercept_[0]),
                'elapsed_seconds': time.perf_counter() - begin}
            results.append(summary)
            for phase, idx in [('training', tr), ('refit', refit)]:
                yp = y.loc[idx].to_numpy() == 1
                multiplier = 1 + v.loc[idx, 'V_i'].to_numpy() if arm == 'vwcs' else np.ones(len(idx))
                ww = np.ones(len(idx)) if arm == 'baseline' else np.where(yp, .9 * multiplier, .1)
                weight_rows.append(dict(scenario=scenario, noise_seed=seed, arm=arm, phase=phase,
                    positive_weight_sum=float(ww[yp].sum()), negative_weight_sum=float(ww[~yp].sum())))
            # C++ file output does not reliably handle Windows Unicode paths.
            (out / f'model_{scenario}_{seed}_{arm}.txt').write_text(final.booster_.model_to_string(), encoding='utf-8')
            csv(results, 'test_metrics.csv')
            csv(candidates, 'tuning_candidates.csv')
            log(f'{scenario} seed={seed} {arm}: AP={scores["pr_auc"]:.6f}, F2={scores["f2"]:.6f}, budget TP={btp}, high-V TP={htp}/{high_n}; {summary["elapsed_seconds"]:.1f}s')
        assert frame_sha(Z) == input_hash
    all_predictions = pd.concat(prediction_frames, ignore_index=True)
    csv(all_predictions, 'test_predictions_long.csv')
    csv(weight_rows, 'weight_audit.csv')
    metrics = pd.DataFrame(results)
    noisy_metrics = metrics[metrics.scenario.eq('shared_noise_0.3sd')]
    summary_columns = METRICS + ['tp', 'fn', 'fp', 'tn', 'alerts_t020', 'budget_tp',
        'budget_fp', 'budget_recall', 'budget_precision', 'budget_high_V_tp', 'budget_high_V_fn', 'budget_high_V_recall']
    summary = noisy_metrics.groupby(['arm', 'model'], sort=False)[summary_columns].agg(['mean', 'std'])
    summary.columns = ['_'.join(col) for col in summary.columns]
    csv(summary.reset_index(), 'shared_noise_mean_sd.csv')
    differences = []
    for scenario, group in metrics.groupby('scenario', sort=False):
        for seed, rows in group.groupby('noise_seed', sort=False):
            indexed = rows.set_index('arm')
            for comparator in ['baseline', 'cost_focal']:
                differences.append(dict(scenario=scenario, noise_seed=seed,
                    comparison='vwcs-minus-' + comparator,
                    **{m: indexed.loc['vwcs', m] - indexed.loc[comparator, m]
                       for m in METRICS + ['budget_tp', 'budget_high_V_tp']}))
    csv(differences, 'paired_seed_differences.csv')
    protocol['elapsed_seconds'] = time.perf_counter() - started
    protocol['original_sources_unchanged'] = all(sha(p) == digest for p, digest in source_hashes.items())
    assert protocol['original_sources_unchanged']
    protocol['completed'] = True
    (out / 'protocol.json').write_text(json.dumps(protocol, ensure_ascii=False, indent=2), 'utf-8')
    log('\nALL INDIVIDUAL RUNS\n' + metrics[['scenario', 'noise_seed', 'arm', *METRICS,
        'tp', 'fn', 'fp', 'tn', 'budget_tp', 'budget_high_V_tp']].to_string(index=False))
    log('\nSHARED NOISE MEAN AND SAMPLE SD\n' + summary.to_string())
    log(f'Completed in {protocol["elapsed_seconds"]:.1f}s. Original sources unchanged. Output: {out}')
    logfile.close()


if __name__ == '__main__':
    main()
